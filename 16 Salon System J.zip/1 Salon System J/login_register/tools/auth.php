<?php


if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Send headers that prevent caching of protected content.
 */
function no_cache_headers(): void
{
    // Prevent caching in modern browsers and proxies
    header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
    // Additional directives for legacy/proxy behavior
    header("Cache-Control: post-check=0, pre-check=0", false);
    header("Pragma: no-cache");
    header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");
}

/**
 * Enforce an active authenticated session.
 * If there's no valid session, redirect to the login page.
 */
function require_login(): void
{
    no_cache_headers();

    $hasEmail = !empty($_SESSION['email']);
    $hasUserId = !empty($_SESSION['user_id']);

    if (!$hasEmail || !$hasUserId) {
        // No active session; redirect to login
        header("Location: /login_register/login.php");
        exit;
    }
}

/**
 * Fully destroy the session and its cookie, and send no-store headers.
 */
function logout_and_destroy(): void
{
    no_cache_headers();

    if (session_status() !== PHP_SESSION_ACTIVE) {
        @session_start();
    }

    // Unset session data
    $_SESSION = [];

    // Invalidate the session cookie
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'] ?? '/',
            $params['domain'] ?? '',
            $params['secure'] ?? false,
            $params['httponly'] ?? true
        );
    }

    // Destroy the session
    @session_destroy();
}