/<?php
require_once __DIR__ . '/tools/auth.php';

// Destroy session and prevent caching
logout_and_destroy();

// Optional: regenerate a fresh session ID for the next visitor to this browser tab
if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}
@session_regenerate_id(true);

// Redirect to login page
header("Location: /login_register/login.php");
exit;
?>
