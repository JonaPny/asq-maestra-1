<?php
// Get transaction data from POST or set defaults for testing
$customer_name = isset($_POST['customer_name']) ? $_POST['customer_name'] : 'Jane Doe';
$services = isset($_POST['services']) ? $_POST['services'] : [
    ['name' => 'Haircut', 'price' => 25.0],
    ['name' => 'Shampoo', 'price' => 10.0]
];
$total_amount = isset($_POST['total_amount']) ? $_POST['total_amount'] : 35.0;
$payment_method = isset($_POST['payment_method']) ? $_POST['payment_method'] : 'Cash';
$date = date('Y-m-d H:i:s');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Salon Receipt</title>
    <style>
        /* ...existing code... */
        body { font-family: Arial, sans-serif; }
        .receipt-container {
            width: 350px;
            margin: 40px auto;
            border: 1px solid #ccc;
            padding: 20px;
            background: #fafafa;
        }
        .receipt-header, .receipt-footer {
            text-align: center;
            font-weight: bold;
        }
        .receipt-details {
            margin: 15px 0;
        }
        .receipt-details table {
            width: 100%;
            border-collapse: collapse;
        }
        .receipt-details th, .receipt-details td {
            text-align: left;
            padding: 4px 0;
        }
        .total-row {
            border-top: 1px solid #ccc;
            font-weight: bold;
        }
        .print-btn {
            margin-top: 15px;
            width: 100%;
            padding: 8px;
            background: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
        }
        @media print {
            .print-btn { display: none; }
        }
        /* ...existing code... */
    </style>
</head>
<body>
    <div class="receipt-container">
        <div class="receipt-header">=== Salon Receipt ===</div>
        <div>Date: <?php echo $date; ?></div>
        <div>Customer: <?php echo htmlspecialchars($customer_name); ?></div>
        <div class="receipt-details">
            <table>
                <thead>
                    <tr>
                        <th>Service</th>
                        <th style="text-align:right;">Price</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($services as $service): ?>
                    <tr>
                        <td><?php echo htmlspecialchars(is_array($service) ? $service['name'] : $service); ?></td>
                        <td style="text-align:right;">$<?php echo number_format(is_array($service) ? $service['price'] : 0, 2); ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <tr class="total-row">
                        <td>Total</td>
                        <td style="text-align:right;">$<?php echo number_format($total_amount, 2); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div>Payment Method: <?php echo htmlspecialchars($payment_method); ?></div>
        <div class="receipt-footer">=====================</div>
        <button class="print-btn" onclick="window.print()">Print Receipt</button>
    </div>
    <!-- ...existing code... -->
</body>
</html>