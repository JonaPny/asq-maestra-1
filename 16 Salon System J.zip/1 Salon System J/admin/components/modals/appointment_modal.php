<!-- Appointment Details Modal -->
<div class="modal fade" id="appointmentModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-pink text-white">
                <h5 class="modal-title">Appointment Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                    aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-4 text-center">
                        <img src="https://via.placeholder.com/150" alt="Customer"
                            class="rounded-circle customer-image mb-3">
                        <h5 id="customer-name" class="text-pink">Customer Name</h5>
                        <p id="customer-contact">Phone: +639123456789</p>
                        <p id="customer-email">Email: customer@example.com</p>
                    </div>
                    <div class="col-md-8">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <h6>Appointment Details</h6>
                                <p id="appointment-date">Date: </p>
                                <p id="appointment-time">Time: </p>
                                <p id="appointment-type">Type: </p>
                            </div>
                            <div class="col-md-6">
                                <h6>Services</h6>
                                <ul id="service-list" class="list-unstyled">
                                    <!-- Services will be loaded by JavaScript -->
                                </ul>
                            </div>
                        </div>
                        <div class="mb-3">
                            <h6>Notes</h6>
                            <textarea class="form-control" id="appointment-notes" rows="5"></textarea>
                        </div>
                        <div class="mb-3">
                            <h6>Status</h6>
                            <select class="form-select" id="appointment-status">
                                <option value="pending">Pending</option>
                                <option value="confirmed">Confirmed</option>
                                <option value="completed">Completed</option>
                                <option value="cancelled">Cancelled</option>
                                <option value="rescheduled">Rescheduled</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-success" id="notify-customer">Notify Customer</button>
                <button type="button" class="btn btn-warning" id="add-to-queue">Add to Queue</button>
                <button type="button" class="btn btn-pink" id="save-appointment">Save Changes</button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Get the save button and status select
    const saveButton = document.getElementById('save-appointment');
    const statusSelect = document.getElementById('appointment-status');
    const addToQueueButton = document.getElementById('add-to-queue');
    
    // Store the original status when the modal opens
    let originalStatus = '';
    
    // When the modal is shown, store the original status
    document.getElementById('appointmentModal').addEventListener('show.bs.modal', function() {
        originalStatus = statusSelect.value;
        
        // Show/hide Add to Queue button based on status
        // Only show for confirmed appointments
        if (statusSelect.value === 'confirmed') {
            addToQueueButton.classList.remove('d-none');
        } else {
            addToQueueButton.classList.add('d-none');
        }
    });
    
    // Update Add to Queue button visibility when status changes
    statusSelect.addEventListener('change', function() {
        if (this.value === 'confirmed') {
            addToQueueButton.classList.remove('d-none');
        } else {
            addToQueueButton.classList.add('d-none');
        }
    });
    
    // Add to Queue button functionality
    addToQueueButton.addEventListener('click', function() {
        const appointmentId = saveButton.getAttribute('data-appointment-id');
        
        // Get customer details from the modal
        const customerName = document.getElementById('customer-name').textContent;
        const customerPhone = document.getElementById('customer-contact').textContent.replace('Phone: ', '');
        const customerEmail = document.getElementById('customer-email').textContent.replace('Email: ', '');
        const serviceType = document.getElementById('appointment-type').textContent.includes('Salon') ? 'salon' : 'home';
        
        // Get services from the list
        const services = [];
        const serviceItems = document.getElementById('service-list').querySelectorAll('li');
        serviceItems.forEach(item => {
            services.push(item.textContent.replace(/^[\s\u25CF\u2022\u2023\u25E6\u2043\u2219\u2981\u2022\u25CF\u25CB\u25AA\u2023\u2043]+/, '').trim());
        });
        
        // Create form for adding to queue
        const queueForm = document.createElement('form');
        queueForm.method = 'POST';
        queueForm.action = 'queue.php';
        queueForm.style.display = 'none';
        
        const queueActionInput = document.createElement('input');
        queueActionInput.name = 'action';
        queueActionInput.value = 'add';
        queueForm.appendChild(queueActionInput);
        
        const nameInput = document.createElement('input');
        nameInput.name = 'customer_name';
        nameInput.value = customerName;
        queueForm.appendChild(nameInput);
        
        const phoneInput = document.createElement('input');
        phoneInput.name = 'phone';
        phoneInput.value = customerPhone;
        queueForm.appendChild(phoneInput);
        
        const serviceInput = document.createElement('input');
        serviceInput.name = 'service';
        serviceInput.value = services.join(', ');
        queueForm.appendChild(serviceInput);
        
        const dateInput = document.createElement('input');
        dateInput.name = 'queue_date';
        dateInput.value = 'today';
        queueForm.appendChild(dateInput);
        
        const appointmentIdInput = document.createElement('input');
        appointmentIdInput.name = 'appointment_id';
        appointmentIdInput.value = appointmentId;
        queueForm.appendChild(appointmentIdInput);
        
        // Add a flag to indicate this is from an appointment
        const fromAppointmentInput = document.createElement('input');
        fromAppointmentInput.name = 'from_appointment';
        fromAppointmentInput.value = '1';
        queueForm.appendChild(fromAppointmentInput);
        
        document.body.appendChild(queueForm);
        queueForm.submit();
    });
    
    // Add event listener to the save button
    saveButton.addEventListener('click', function() {
        const appointmentId = this.getAttribute('data-appointment-id');
        const newStatus = statusSelect.value;
        
        // Create form for updating appointment status
        const form = document.createElement('form');
        form.method = 'POST';
        form.style.display = 'none';
        
        const actionInput = document.createElement('input');
        actionInput.name = 'action';
        actionInput.value = 'update_status';
        form.appendChild(actionInput);
        
        const idInput = document.createElement('input');
        idInput.name = 'appointment_id';
        idInput.value = appointmentId;
        form.appendChild(idInput);
        
        const statusInput = document.createElement('input');
        statusInput.name = 'status';
        statusInput.value = newStatus;
        form.appendChild(statusInput);
        
        const notesInput = document.createElement('input');
        notesInput.name = 'notes';
        notesInput.value = document.getElementById('appointment-notes').value;
        form.appendChild(notesInput);
        
        document.body.appendChild(form);
        form.submit();
    });
});
</script>
