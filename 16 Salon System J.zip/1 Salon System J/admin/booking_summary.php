<?php
$page_title = "Booking Summary - Salon Admin";
include 'components/header.php';
include 'components/sidebar.php';
include 'components/navbar.php';

// Include database connection
include '../login_register/tools/salondb.php';
$conn = getDatabaseConnection();

// Get current date information
$today = date('Y-m-d');
$current_week_start = date('Y-m-d', strtotime('monday this week'));
$current_week_end = date('Y-m-d', strtotime('sunday this week'));
$current_month_start = date('Y-m-01');
$current_month_end = date('Y-m-t');

// Get active tab from URL parameter, default to 'today'
$active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'today';

// Function to get appointments for a date range
function getAppointments($conn, $start_date, $end_date) {
    $appointments = [];
    $sql = "SELECT a.*, u.first_name, u.last_name, u.phone, u.email 
            FROM appointments a 
            LEFT JOIN users u ON a.user_id = u.id
            WHERE a.appointment_date BETWEEN ? AND ?
            ORDER BY a.appointment_date, a.appointment_time";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $start_date, $end_date);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $appointments[] = $row;
        }
    }
    
    $stmt->close();
    return $appointments;
}

// Get appointments for each time period
$today_appointments = getAppointments($conn, $today, $today);
$week_appointments = getAppointments($conn, $current_week_start, $current_week_end);
$month_appointments = getAppointments($conn, $current_month_start, $current_month_end);

// Close database connection
$conn->close();
?>

<div class="p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Booking Summary</h2>
        <button class="btn btn-sm btn-outline-pink" id="refresh-btn">
            <i class="bi bi-arrow-clockwise me-1"></i> Refresh
        </button>
    </div>

    <!-- Tab navigation -->
    <ul class="nav nav-tabs mb-4">
        <li class="nav-item">
            <a class="nav-link <?php echo $active_tab === 'today' ? 'active' : ''; ?>" href="?tab=today">
                Today
                <span class="badge bg-pink ms-1"><?php echo count($today_appointments); ?></span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo $active_tab === 'week' ? 'active' : ''; ?>" href="?tab=week">
                This Week
                <span class="badge bg-pink ms-1"><?php echo count($week_appointments); ?></span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?php echo $active_tab === 'month' ? 'active' : ''; ?>" href="?tab=month">
                This Month
                <span class="badge bg-pink ms-1"><?php echo count($month_appointments); ?></span>
            </a>
        </li>
    </ul>

    <!-- Tab content -->
    <div class="tab-content">
        <!-- Today's Appointments -->
        <div class="tab-pane fade <?php echo $active_tab === 'today' ? 'show active' : ''; ?>" id="today">
            <div class="card">
                <div class="card-header bg-light">
                    <h5 class="mb-0">Today's Appointments (<?php echo date('F d, Y'); ?>)</h5>
                </div>
                <div class="card-body">
                    <?php if (count($today_appointments) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>Time</th>
                                        <th>Customer</th>
                                        <th>Service Type</th>
                                        <th>Services</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($today_appointments as $appointment): ?>
                                        <tr>
                                            <td><?php echo date('h:i A', strtotime($appointment['appointment_time'])); ?></td>
                                            <td>
                                                <?php echo $appointment['first_name'] . ' ' . $appointment['last_name']; ?>
                                                <div class="small text-muted"><?php echo $appointment['phone']; ?></div>
                                            </td>
                                            <td><?php echo ucfirst($appointment['service_type']); ?></td>
                                            <td><?php echo $appointment['services']; ?></td>
                                            <td>
                                                <span class="badge <?php 
                                                    echo $appointment['status'] === 'confirmed' ? 'bg-primary' : 
                                                        ($appointment['status'] === 'completed' ? 'bg-success' : 
                                                        ($appointment['status'] === 'cancelled' ? 'bg-danger' : 
                                                        ($appointment['status'] === 'rescheduled' ? 'bg-warning' : 'bg-secondary'))); 
                                                ?>">
                                                    <?php echo ucfirst($appointment['status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-outline-secondary rounded-circle view-appointment" 
                                                        data-appointment-id="<?php echo $appointment['id']; ?>">
                                                    <i class="bi bi-eye"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle me-2"></i> No appointments scheduled for today.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- This Week's Appointments -->
        <div class="tab-pane fade <?php echo $active_tab === 'week' ? 'show active' : ''; ?>" id="week">
            <div class="card">
                <div class="card-header bg-light">
                    <h5 class="mb-0">This Week's Appointments (<?php echo date('M d', strtotime($current_week_start)); ?> - <?php echo date('M d, Y', strtotime($current_week_end)); ?>)</h5>
                </div>
                <div class="card-body">
                    <?php if (count($week_appointments) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Customer</th>
                                        <th>Service Type</th>
                                        <th>Services</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($week_appointments as $appointment): ?>
                                        <tr class="<?php echo $appointment['appointment_date'] === $today ? 'table-active' : ''; ?>">
                                            <td><?php echo date('D, M d', strtotime($appointment['appointment_date'])); ?></td>
                                            <td><?php echo date('h:i A', strtotime($appointment['appointment_time'])); ?></td>
                                            <td>
                                                <?php echo $appointment['first_name'] . ' ' . $appointment['last_name']; ?>
                                                <div class="small text-muted"><?php echo $appointment['phone']; ?></div>
                                            </td>
                                            <td><?php echo ucfirst($appointment['service_type']); ?></td>
                                            <td><?php echo $appointment['services']; ?></td>
                                            <td>
                                                <span class="badge <?php 
                                                    echo $appointment['status'] === 'confirmed' ? 'bg-primary' : 
                                                        ($appointment['status'] === 'completed' ? 'bg-success' : 
                                                        ($appointment['status'] === 'cancelled' ? 'bg-danger' : 
                                                        ($appointment['status'] === 'rescheduled' ? 'bg-warning' : 'bg-secondary'))); 
                                                ?>">
                                                    <?php echo ucfirst($appointment['status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-outline-secondary rounded-circle view-appointment" 
                                                        data-appointment-id="<?php echo $appointment['id']; ?>">
                                                    <i class="bi bi-eye"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle me-2"></i> No appointments scheduled for this week.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- This Month's Appointments -->
        <div class="tab-pane fade <?php echo $active_tab === 'month' ? 'show active' : ''; ?>" id="month">
            <div class="card">
                <div class="card-header bg-light">
                    <h5 class="mb-0">This Month's Appointments (<?php echo date('F Y'); ?>)</h5>
                </div>
                <div class="card-body">
                    <?php if (count($month_appointments) > 0): ?>
                        <!-- Summary statistics -->
                        <div class="row mb-4">
                            <div class="col-md-3">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <h3 class="mb-0"><?php echo count($month_appointments); ?></h3>
                                        <p class="text-muted mb-0">Total Appointments</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <?php 
                                        $completed = array_filter($month_appointments, function($a) {
                                            return $a['status'] === 'completed';
                                        });
                                        ?>
                                        <h3 class="mb-0"><?php echo count($completed); ?></h3>
                                        <p class="text-muted mb-0">Completed</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <?php 
                                        $pending = array_filter($month_appointments, function($a) {
                                            return $a['status'] === 'pending' || $a['status'] === 'confirmed';
                                        });
                                        ?>
                                        <h3 class="mb-0"><?php echo count($pending); ?></h3>
                                        <p class="text-muted mb-0">Pending/Confirmed</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <?php 
                                        $cancelled = array_filter($month_appointments, function($a) {
                                            return $a['status'] === 'cancelled';
                                        });
                                        ?>
                                        <h3 class="mb-0"><?php echo count($cancelled); ?></h3>
                                        <p class="text-muted mb-0">Cancelled</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Customer</th>
                                        <th>Service Type</th>
                                        <th>Services</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($month_appointments as $appointment): ?>
                                        <tr class="<?php echo $appointment['appointment_date'] === $today ? 'table-active' : ''; ?>">
                                            <td><?php echo date('M d (D)', strtotime($appointment['appointment_date'])); ?></td>
                                            <td><?php echo date('h:i A', strtotime($appointment['appointment_time'])); ?></td>
                                            <td>
                                                <?php echo $appointment['first_name'] . ' ' . $appointment['last_name']; ?>
                                                <div class="small text-muted"><?php echo $appointment['phone']; ?></div>
                                            </td>
                                            <td><?php echo ucfirst($appointment['service_type']); ?></td>
                                            <td><?php echo $appointment['services']; ?></td>
                                            <td>
                                                <span class="badge <?php 
                                                    echo $appointment['status'] === 'confirmed' ? 'bg-primary' : 
                                                        ($appointment['status'] === 'completed' ? 'bg-success' : 
                                                        ($appointment['status'] === 'cancelled' ? 'bg-danger' : 
                                                        ($appointment['status'] === 'rescheduled' ? 'bg-warning' : 'bg-secondary'))); 
                                                ?>">
                                                    <?php echo ucfirst($appointment['status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-outline-secondary rounded-circle view-appointment" 
                                                        data-appointment-id="<?php echo $appointment['id']; ?>">
                                                    <i class="bi bi-eye"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle me-2"></i> No appointments scheduled for this month.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'components/modals/appointment_modal.php'; ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Sample appointment data for when database is empty
        let appointmentsData = <?php echo json_encode($active_tab === 'today' ? $today_appointments : 
                                                    ($active_tab === 'week' ? $week_appointments : $month_appointments)); ?>;
        
        if (appointmentsData.length === 0) {
            // Sample data for demonstration
            if ('<?php echo $active_tab; ?>' === 'today') {
                appointmentsData = [
                    {
                        id: 1,
                        first_name: 'Jennie',
                        last_name: 'Kim',
                        phone: '+639123456789',
                        email: 'jennie@example.com',
                        appointment_date: '<?php echo $today; ?>',
                        appointment_time: '10:30:00',
                        service_type: 'salon',
                        status: 'confirmed',
                        services: 'Hair Cut & Style, Hot Oil Treatment',
                        notes: 'First-time customer'
                    },
                    {
                        id: 2,
                        first_name: 'Lisa',
                        last_name: 'Manoban',
                        phone: '+639123456782',
                        email: 'lisa@example.com',
                        appointment_date: '<?php echo $today; ?>',
                        appointment_time: '14:00:00',
                        service_type: 'home',
                        status: 'pending',
                        services: 'Manicure & Pedicure',
                        notes: 'Address: Makati City'
                    }
                ];
            }
        }

        // Refresh button
        document.getElementById('refresh-btn').addEventListener('click', function () {
            location.reload();
        });

        // Appointment modal
        const appointmentModal = new bootstrap.Modal(document.getElementById('appointmentModal'));

        // View appointment buttons
        document.querySelectorAll('.view-appointment').forEach(button => {
            button.addEventListener('click', function () {
                const appointmentId = this.getAttribute('data-appointment-id');
                openAppointmentModal(appointmentId);
            });
        });

        function openAppointmentModal(appointmentId) {
            // Find appointment data
            const appointment = appointmentsData.find(app => app.id == appointmentId);
            if (!appointment) return;

            // Format date for display
            const dateObj = new Date(appointment.appointment_date);
            const formattedDate = `${String(dateObj.getMonth() + 1).padStart(2, '0')}-${String(dateObj.getDate()).padStart(2, '0')}-${dateObj.getFullYear()}`;

            // Format time for display
            const timeObj = new Date(`2000-01-01T${appointment.appointment_time}`);
            const formattedTime = timeObj.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});

            // Populate modal
            document.getElementById('customer-name').textContent = appointment.first_name + ' ' + appointment.last_name;
            document.getElementById('customer-contact').textContent = `Phone: ${appointment.phone}`;
            document.getElementById('customer-email').textContent = `Email: ${appointment.email}`;
            document.getElementById('appointment-date').textContent = `Date: ${formattedDate}`;
            document.getElementById('appointment-time').textContent = `Time: ${formattedTime}`;
            document.getElementById('appointment-type').textContent = `Type: ${appointment.service_type === 'salon' ? 'Salon Service' : 'Home Service'}`;
            document.getElementById('appointment-notes').value = appointment.notes || '';
            document.getElementById('appointment-status').value = appointment.status;

            // Populate services
            const serviceList = document.getElementById('service-list');
            serviceList.innerHTML = '';
            
            if (appointment.services) {
                const services = appointment.services.split(',');
                services.forEach(service => {
                    const li = document.createElement('li');
                    li.innerHTML = `<i class="bi bi-circle-fill me-2 small"></i> ${service.trim()}`;
                    serviceList.appendChild(li);
                });
            }

            // Set data attribute for save button
            document.getElementById('save-appointment').setAttribute('data-appointment-id', appointmentId);
            document.getElementById('notify-customer').setAttribute('data-appointment-id', appointmentId);

            // Show modal
            appointmentModal.show();
        }

        // Save appointment changes
        document.getElementById('save-appointment').addEventListener('click', function () {
            const appointmentId = this.getAttribute('data-appointment-id');
            const status = document.getElementById('appointment-status').value;
            const notes = document.getElementById('appointment-notes').value;
            
            // Create form for submission
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'appointments.php'; // Submit to appointments.php
            form.style.display = 'none';
            
            const actionInput = document.createElement('input');
            actionInput.name = 'action';
            actionInput.value = 'update_status';
            form.appendChild(actionInput);
            
            const idInput = document.createElement('input');
            idInput.name = 'appointment_id';
            idInput.value = appointmentId;
            form.appendChild(idInput);
            
            const statusInput = document.createElement('input');
            statusInput.name = 'status';
            statusInput.value = status;
            form.appendChild(statusInput);
            
            const notesInput = document.createElement('input');
            notesInput.name = 'notes';
            notesInput.value = notes;
            form.appendChild(notesInput);
            
            // Add redirect back to booking summary with current tab
            const redirectInput = document.createElement('input');
            redirectInput.name = 'redirect';
            redirectInput.value = 'booking_summary.php?tab=<?php echo $active_tab; ?>';
            form.appendChild(redirectInput);
            
            document.body.appendChild(form);
            form.submit();
        });

        // Notify customer
        document.getElementById('notify-customer').addEventListener('click', function () {
            const appointmentId = this.getAttribute('data-appointment-id');
            
            // Create form for submission
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'appointments.php'; // Submit to appointments.php
            form.style.display = 'none';
            
            const actionInput = document.createElement('input');
            actionInput.name = 'action';
            actionInput.value = 'notify';
            form.appendChild(actionInput);
            
            const idInput = document.createElement('input');
            idInput.name = 'appointment_id';
            idInput.value = appointmentId;
            form.appendChild(idInput);
            
            // Add redirect back to booking summary with current tab
            const redirectInput = document.createElement('input');
            redirectInput.name = 'redirect';
            redirectInput.value = 'booking_summary.php?tab=<?php echo $active_tab; ?>';
            form.appendChild(redirectInput);
            
            document.body.appendChild(form);
            form.submit();
        });
    });
</script>

<?php include 'components/footer.php'; ?>
