<!-- Main Content -->
<div class="col-md-10 main-content">
    <div class="p-3 border-bottom d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center">
            <div class="admin-icon me-2">
                <i class="bi bi-person-circle fs-3"></i>
            </div>
            <span class="fw-bold">Admin</span>
        </div>
        <div>
            <a href="#" class="salon-profile-link">
                <img src="/PHOTOS/logo.png" alt="Salon Profile" height="70px" width="70ps" class="rounded-circle">
            </a>
        </div>
    </div>
