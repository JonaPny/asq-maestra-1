document.addEventListener("DOMContentLoaded", () => {
  // Highlight today's date
  function highlightToday() {
    // First, remove the "today" class from any cell that might have it
    document.querySelectorAll(".calendar-table td.today").forEach((cell) => {
      cell.classList.remove("today")
      // Also remove the "TODAY" text that's added via CSS ::after
    })

    // Get the current date
    const today = new Date()
    const todayStr =
      today.getFullYear() +
      "-" +
      String(today.getMonth() + 1).padStart(2, "0") +
      "-" +
      String(today.getDate()).padStart(2, "0")

    // Find today's cell and add the today class
    const todayCell = document.querySelector(`.calendar-table td[data-date="${todayStr}"]`)
    if (todayCell) {
      todayCell.classList.add("today")
      console.log("Today highlighted:", todayStr)
    } else {
      console.log("Today's cell not found in current view:", todayStr)
    }
  }

  // Call the function when the page loads
  highlightToday()

  // Day edit modal
  const dayEditModalElement = document.getElementById("dayEditModal")
  const dayEditModal = new bootstrap.Modal(dayEditModalElement)

  // Calendar cell click event
  document.querySelectorAll(".calendar-table td[data-date]").forEach((cell) => {
    cell.addEventListener("click", function () {
      const dateStr = this.getAttribute("data-date")

      if (document.getElementById("edit-mode").checked) {
        openDayEditModal(dateStr)
      } else {
        viewDayAppointments(dateStr)
      }
    })
  })

  // Function to store the original cell class when opening the modal
  function openDayEditModal(dateStr) {
    document.getElementById("selected-date").value = dateStr

    // Set current status
    let status = "default" // Default to default (no status)
    const cell = document.querySelector(`.calendar-table td[data-date="${dateStr}"]`)

    // Store the original cell class for cancellation
    cell.setAttribute("data-original-class", cell.className)

    if (cell.classList.contains("full-sched")) {
      status = "full"
    } else if (cell.classList.contains("salon-service")) {
      status = "salon"
    } else if (cell.classList.contains("day-off")) {
      // Check if it's Sunday (day 0)
      const dayOfWeek = Number.parseInt(cell.getAttribute("data-day"))
      if (dayOfWeek !== 0) {
        // Only set as day-off if it's not Sunday (since Sundays are day-off by default)
        status = "day-off"
      }
    } else if (cell.classList.contains("home-service")) {
      status = "home"
    }

    // Find and check the appropriate radio button
    const radioButton = document.querySelector(`input[name="dayStatus"][value="${status}"]`)
    if (radioButton) {
      radioButton.checked = true
    }

    // Show modal
    dayEditModal.show()
  }

  // Save day status function
  document.getElementById("saveDayStatus").addEventListener("click", () => {
    const dateStr = document.getElementById("selected-date").value
    const status = document.querySelector('input[name="dayStatus"]:checked').value
    const notes = document.getElementById("dayNotes").value

    // Update the cell appearance immediately
    const cell = document.querySelector(`.calendar-table td[data-date="${dateStr}"]`)

    // Remove all status classes but keep the today class if present
    const isToday = cell.classList.contains("today")
    cell.className = isToday ? "today" : ""

    // Add the appropriate class based on the selected status
    if (status === "default") {
      // For default, just leave it with no class (or just 'today' if it's today)
      // Check if it's Sunday and add day-off class if it is
      const dayOfWeek = Number.parseInt(cell.getAttribute("data-day"))
      if (dayOfWeek === 0) {
        cell.classList.add("day-off")
      }
    } else if (status === "full") {
      cell.classList.add("full-sched")
    } else if (status === "salon") {
      cell.classList.add("salon-service")
    } else if (status === "day-off") {
      cell.classList.add("day-off")
    } else if (status === "home") {
      cell.classList.add("home-service")
    }

    // Create form data for AJAX submission
    const formData = new FormData()
    formData.append("action", "update_day")
    formData.append("date", dateStr)
    formData.append("status", status)
    formData.append("notes", notes)

    // Send AJAX request to update the database
    fetch("dashboard.php", {
      method: "POST",
      body: formData,
      headers: {
        "X-Requested-With": "XMLHttpRequest",
      },
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error("Network response was not ok")
        }
        return response.json()
      })
      .then((data) => {
        // Show success message
        const calendarMessage = document.getElementById("calendar-message")
        calendarMessage.textContent = data.message || "Day status updated successfully!"
        calendarMessage.classList.remove("d-none")
        calendarMessage.classList.remove("alert-danger")
        calendarMessage.classList.add("alert-success")

        // Hide the message after 3 seconds
        setTimeout(() => {
          calendarMessage.classList.add("d-none")
        }, 3000)

        // Log the status to console for debugging
        console.log("Updated status:", status)
      })
      .catch((error) => {
        console.error("Error:", error)

        // Show error message in the UI
        const calendarMessage = document.getElementById("calendar-message")
        calendarMessage.textContent = "Error updating day status. Please try again."
        calendarMessage.classList.remove("d-none")
        calendarMessage.classList.remove("alert-success")
        calendarMessage.classList.add("alert-danger")

        // Hide the message after 3 seconds
        setTimeout(() => {
          calendarMessage.classList.add("d-none")
        }, 3000)
      })

    // Close the modal
    dayEditModal.hide()
  })

  // Cancel button functionality
  document.getElementById("cancelDayEdit").addEventListener("click", () => {
    const dateStr = document.getElementById("selected-date").value
    const cell = document.querySelector(`.calendar-table td[data-date="${dateStr}"]`)

    // Restore the original class if it was stored
    if (cell.hasAttribute("data-original-class")) {
      cell.className = cell.getAttribute("data-original-class")
    }

    // Close the modal
    dayEditModal.hide()
  })

  // View day appointments
  function viewDayAppointments(dateStr) {
    window.location.href = `appointments.php?date=${dateStr}`
  }
})
