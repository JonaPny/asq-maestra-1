<?php include('header.php'); ?>

<section class="header">
  <div class="header-content">
    <h1>INDULGE IN BEAUTY,<br>RELAX IN LUXURY.</h1>
    <p>We Are Your Destination for<br>Beauty & Confidence</p>
    <a href="appointment.php" class="cta-button">SET AN APPOINTMENT NOW!</a>
    <p class="phone">CALL US 639-000-0000-00</p>
  </div>
</section>


<div>
  <!-- Optional: add more homepage content here -->
</div>

<?php include('footer.php'); ?>
