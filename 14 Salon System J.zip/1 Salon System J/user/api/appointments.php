<?php
// Set headers for JSON response
header('Content-Type: application/json');

// Include database connection
include "../../login_register/tools/salondb.php";
$pdo = getDatabaseConnection('pdo');

// Get action from request
$action = isset($_GET['action']) ? $_GET['action'] : '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
}

// Handle different actions
switch ($action) {
    case 'create_appointment':
        createAppointment();
        break;
    case 'get_user_appointments':
        $userId = isset($_GET['user_id']) ? $_GET['user_id'] : '';
        getUserAppointments($userId);
        break;
    case 'cancel_appointment':
        $id = isset($_POST['appointment_id']) ? $_POST['appointment_id'] : '';
        cancelAppointment($id);
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
        break;
}

// Create a new appointment
function createAppointment() {
    global $pdo;
    
    // Start session if not already started
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'User not logged in']);
        return;
    }
    
    $userId = $_SESSION['user_id'];
    
    try {
        // Get form data
        $appointmentDate = $_POST['appointment_date'];
        $appointmentTime = $_POST['appointment_time'];
        $serviceType = $_POST['service_type'];
        $notes = $_POST['notes'] ?? '';
        $servicesJson = $_POST['services_json'] ?? '[]';
        $services = json_decode($servicesJson, true);
        
        // Format services as comma-separated string
        $serviceNames = [];
        foreach ($services as $service) {
            $serviceNames[] = $service['name'];
        }
        $servicesString = implode(', ', $serviceNames);
        
        // Get the first service ID as the main service_id
        $serviceId = !empty($services) ? $services[0]['id'] : null;
        
        // Additional fields for home service
        $address = '';
        $locationArea = '';
        $transportationFee = 0;
        
        if ($serviceType === 'home') {
            $address = $_POST['address'] ?? '';
            $locationArea = $_POST['location_area'] ?? '';
            $transportationFee = $_POST['transportation_fee'] ?? 0;
            
            // Add location details to notes
            $notes .= "\n\nLocation Area: " . $locationArea;
            $notes .= "\nAddress: " . $address;
            $notes .= "\nTransportation Fee: ₱" . number_format($transportationFee, 2);
        }
        
        // Payment details
        $paymentMethod = $_POST['payment_method'] ?? 'cash';
        $paymentStatus = $_POST['payment_status'] ?? 'full';
        
        // Add payment details to notes
        $notes .= "\n\nPayment Method: " . ucfirst($paymentMethod);
        $notes .= "\nPayment Status: " . ($paymentStatus === 'full' ? 'Paid in Full' : '50% Deposit');
        
        // Insert appointment into database
        $stmt = $pdo->prepare("
            INSERT INTO appointments (
                user_id, 
                service_id, 
                appointment_date, 
                appointment_time, 
                service_type, 
                status, 
                services, 
                notes, 
                created_at, 
                updated_at
            ) VALUES (
                :user_id, 
                :service_id, 
                :appointment_date, 
                :appointment_time, 
                :service_type, 
                'pending', 
                :services, 
                :notes, 
                NOW(), 
                NOW()
            )
        ");
        
        $stmt->bindParam(':user_id', $userId);
        $stmt->bindParam(':service_id', $serviceId);
        $stmt->bindParam(':appointment_date', $appointmentDate);
        $stmt->bindParam(':appointment_time', $appointmentTime);
        $stmt->bindParam(':service_type', $serviceType);
        $stmt->bindParam(':services', $servicesString);
        $stmt->bindParam(':notes', $notes);
        
        $stmt->execute();
        
        $appointmentId = $pdo->lastInsertId();
        
        echo json_encode([
            'success' => true, 
            'message' => 'Appointment created successfully',
            'appointment_id' => $appointmentId
        ]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error creating appointment: ' . $e->getMessage()]);
    }
}

// Get user appointments
function getUserAppointments($userId) {
    global $pdo;
    
    if (!$userId) {
        // If no user ID provided, try to get from session
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        if (isset($_SESSION['user_id'])) {
            $userId = $_SESSION['user_id'];
        } else {
            echo json_encode(['success' => false, 'message' => 'User not logged in']);
            return;
        }
    }
    
    try {
        $stmt = $pdo->prepare("
            SELECT * FROM appointments 
            WHERE user_id = :user_id 
            ORDER BY appointment_date DESC, appointment_time DESC
        ");
        $stmt->bindParam(':user_id', $userId);
        $stmt->execute();
        
        $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'appointments' => $appointments
        ]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error fetching appointments: ' . $e->getMessage()]);
    }
}

// Cancel appointment
function cancelAppointment($id) {
    global $pdo;
    
    if (!$id) {
        echo json_encode(['success' => false, 'message' => 'No appointment ID provided']);
        return;
    }
    
    // Start session if not already started
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'User not logged in']);
        return;
    }
    
    $userId = $_SESSION['user_id'];
    
    try {
        // First check if the appointment belongs to the user
        $stmt = $pdo->prepare("SELECT user_id FROM appointments WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        
        $appointment = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$appointment) {
            echo json_encode(['success' => false, 'message' => 'Appointment not found']);
            return;
        }
        
        if ($appointment['user_id'] != $userId) {
            echo json_encode(['success' => false, 'message' => 'You do not have permission to cancel this appointment']);
            return;
        }
        
        // Update appointment status to cancelled
        $stmt = $pdo->prepare("
            UPDATE appointments 
            SET status = 'cancelled', updated_at = NOW() 
            WHERE id = :id
        ");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        
        echo json_encode(['success' => true, 'message' => 'Appointment cancelled successfully']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error cancelling appointment: ' . $e->getMessage()]);
    }
}
?>
