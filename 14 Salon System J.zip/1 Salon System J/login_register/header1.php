<?php
session_start();
$authenticated = false;

if (isset($_SESSION["email"])) {
    $authenticated = true;
}
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>A.S.Q MAESTRA SALON</title>
    <link rel="icon" href="/PHOTOS/logo.png">
    <link rel="stylesheet" href="/CSS/nav-bar.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Poppins:wght@300;400;500;600&display=swap"/>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
  </head>
  <body>
    
  <nav class="navbar">
    <div class="nav-container">
      <a class="navbar-brand" href="/login_register/index.php">
        <img src="/PHOTOS/logo.png" width="70" height="auto" alt="Salon Logo">
        <span class="brand-text">Jose Maestra Barbera Salon</span>
      </a>
      
      <div class="menu-toggle" id="mobile-menu">
        <span class="bar"></span>
        <span class="bar"></span>
        <span class="bar"></span>
      </div>

      <div class="navbar-menu" id="navMenu">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="/login_register/index.php">HOME</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/gallery.php">GALLERY</a>
          </li>  
          <li class="nav-item">
            <a class="nav-link" href="/login_register/about-us.php">ABOUT US</a>
          </li>

          <?php if ($authenticated) { ?>
            <li class="nav-item">
              <a href="/user/customer.php" class="nav-link">MY ACCOUNT</a>
            </li>
          <?php } else { ?>
            <li class="nav-item">
              <a href="/login_register/login.php" class="signup-btn">SIGN UP</a>
            </li>
          <?php } ?>
        </ul>
      </div>
    </div>
  </nav>

  <script src="/JAVASCRIPT/navbar.js"></script>
