<?php 
date_default_timezone_set('Asia/Manila');
include('header1.php');

// Include the consolidated database connection
include "tools/salondb.php";
$dbConnection = getDatabaseConnection();

$email = $_GET['email'] ?? ''; // Autofill if redirected
$password = "";
$email_error = $password_error = "";
$error = false;

// Unified login processing for both customers and admins
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $email_error = "Invalid email format";
        $error = true;
    }

    if (empty($password)) {
        $password_error = "Password is required";
        $error = true;
    }

    if (!$error) {
        // Query to get user data including role
        $statement = $dbConnection->prepare("SELECT id, first_name, last_name, email, password, role, status FROM users WHERE email = ?");
        $statement->bind_param("s", $email);
        $statement->execute();
        $statement->store_result();

        if ($statement->num_rows == 1) {
            $statement->bind_result($user_id, $first_name, $last_name, $user_email, $hashed_password, $role, $status);
            $statement->fetch();

            // Check if account is active
            if ($status !== 'active') {
                $email_error = "Your account is inactive. Please contact support.";
            } else if (password_verify($password, $hashed_password)) {
                // Set common session variables
                $_SESSION['email'] = $user_email;
                $_SESSION['user_id'] = $user_id;
                $_SESSION['name'] = $first_name . ' ' . $last_name;
                $_SESSION['role'] = $role;
                
                // Redirect based on role
                if ($role === 'admin') {
                    // Set admin-specific session variables for backward compatibility
                    $_SESSION['admin_logged_in'] = true;
                    $_SESSION['admin_username'] = $first_name . ' ' . $last_name;
                    $_SESSION['admin_id'] = $user_id;
                    
                    // Redirect to admin dashboard
                    header("Location: ../admin/dashboard.php");
                    exit;
                } else {
                    // Redirect to customer page for 'client' or 'user' roles
                    header("Location: ../user/customer.php");
                    exit;
                }
            } else {
                $password_error = "Incorrect password";
            }
        } else {
            $email_error = "Email not found";
        }

        $statement->close();
    }
}
?>

<link rel="stylesheet" href="/CSS/login.css">

<!-- Unified Login Form -->
<div class="container">
    <div class="form-container single-form">
        <h2 class="form-title">Login</h2>
        <p class="form-subtitle">Welcome back! Please sign in to your account.</p>
        <hr />

        <form method="post">
            <div class="form-row">
                <label class="form-label">Email</label>
                <div class="form-input-container">
                    <input class="form-input" name="email" type="email" value="<?= htmlspecialchars($email); ?>" placeholder="Enter your email address">
                    <span class="error-text"><?= $email_error ?></span>
                </div>
            </div>
            
            <div class="form-row">
                <label class="form-label">Password</label>
                <div class="form-input-container">
                    <input class="form-input" name="password" type="password" placeholder="Enter your password">
                    <span class="error-text"><?= $password_error ?></span>
                </div>
            </div>
            
            <div class="form-row button-row">
                <button type="submit" name="login" class="submit-btn">Login</button>
                <a href="/login_register/index.php" class="cancel-btn">Cancel</a>
            </div>
        </form>

        <p class="register-link">Don't have an account? <a href="register.php">Register here</a></p>
    </div>
</div>

<style>
/* Additional styles for the unified login form */
.single-form {
    max-width: 500px;
    margin: 2rem auto;
}

.form-subtitle {
    text-align: center;
    color: #666;
    margin-bottom: 1rem;
    font-size: 0.95rem;
}

.form-input {
    width: 100%;
    padding: 12px 15px;
    border: 2px solid #e1e5e9;
    border-radius: 8px;
    font-size: 16px;
    transition: border-color 0.3s ease;
}

.form-input:focus {
    outline: none;
    border-color: #e91e63;
    box-shadow: 0 0 0 3px rgba(233, 30, 99, 0.1);
}

.submit-btn {
    background: linear-gradient(135deg, #e91e63, #ad1457);
    color: white;
    border: none;
    padding: 12px 30px;
    border-radius: 8px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    width: 100%;
    margin-bottom: 10px;
}

.submit-btn:hover {
    background: linear-gradient(135deg, #ad1457, #880e4f);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(233, 30, 99, 0.3);
}

.cancel-btn {
    display: inline-block;
    text-align: center;
    padding: 12px 30px;
    color: #666;
    text-decoration: none;
    border: 2px solid #e1e5e9;
    border-radius: 8px;
    font-weight: 500;
    transition: all 0.3s ease;
    width: 100%;
    box-sizing: border-box;
}

.cancel-btn:hover {
    background-color: #f8f9fa;
    border-color: #d1d5db;
    color: #374151;
}

.register-link {
    text-align: center;
    margin-top: 1.5rem;
    color: #666;
}

.register-link a {
    color: #e91e63;
    text-decoration: none;
    font-weight: 500;
}

.register-link a:hover {
    text-decoration: underline;
}
</style>

<?php include('footer1.php'); ?>
