<footer class="py-3" style="background-color:#333;">
        <div class="container">
            <div class="row">
                <div class="col text-center">
                    <img class="mb-2" src="/PHOTOS/logo.png" alt="" width="30" height="30">
                    <small class="d-block" style="color: white;">&copy; 2025 ASQ-Maestra Salon. All Rights Reserved.</small>
                </div>
            </div>
        </div>
    </footer>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous"></script>
  </body>
</html>
