<?php include('header1.php'); ?>



<link rel="stylesheet" href="/CSS/homepage.css">


<div class="hero-section">
  <!-- Overlay -->
  <div class="hero-overlay"></div>

  <!-- Content -->
  <div class="hero-container">
    <div class="hero-content">
      <h1 class="hero-title">
        <strong>INDULGE IN BEAUTY, RELAX IN LUXURY.</strong>
      </h1>
      <p class="hero-subtitle">
        We Are Your Destination for <br>
        Beauty & Confidence
      </p>
      <a href="book.php" class="hero-btn">
        SET AN APPOINTMENT NOW!
      </a>
    </div>
  </div>
</div>


  <section class="services-section">
    <div class="container">
      <div class="section-header">
        <h2 class="section-title">Our Services</h2>
        <div class="title-underline"></div>
        <p class="section-description">
          Discover our comprehensive range of beauty services tailored to enhance your natural beauty and boost your confidence.
        </p>
      </div>

      <!-- Category Navigation -->
      <div class="category-nav">
        <button class="category-btn active" data-category="haircut">
          <i class="fas fa-cut"></i> Hair Cut
        </button>
        <button class="category-btn" data-category="haircolor">
          <i class="fas fa-palette"></i> Hair Color
        </button>
        <button class="category-btn" data-category="rebonding">
          <i class="fas fa-magic"></i> Rebonding
        </button>
        <button class="category-btn" data-category="hairtreatment">
          <i class="fas fa-pump-soap"></i> Hair Treatment
        </button>
        <button class="category-btn" data-category="nails">
          <i class="fas fa-hand-sparkles"></i> Nails
        </button>
        <button class="category-btn" data-category="braiding">
          <i class="fas fa-stream"></i> Braiding
        </button>
        <button class="category-btn" data-category="formen">
          <i class="fas fa-male"></i> For Men
        </button>
        <button class="category-btn" data-category="forwomen">
          <i class="fas fa-female"></i> For Women
        </button>
      </div>

      <!-- Services Display -->
      <div class="services-container">
        <!-- Haircut Services -->
        <div class="service-category active" id="haircut">
          <div class="services-grid">
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Women's Haircut</h3>
                  <span class="service-price">₱450</span>
                </div>
                <p class="service-description">Includes consultation, shampoo, and style</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 30-60 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Men's Haircut</h3>
                  <span class="service-price">₱350</span>
                </div>
                <p class="service-description">Includes consultation and styling</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 30-45 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Kids Haircut (Under 12)</h3>
                  <span class="service-price">₱250</span>
                </div>
                <p class="service-description">Gentle cut for children</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 20-30 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Bangs Trim</h3>
                  <span class="service-price">₱150</span>
                </div>
                <p class="service-description">Quick fringe maintenance</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 15 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Layered Cut</h3>
                  <span class="service-price">₱550</span>
                </div>
                <p class="service-description">Adds volume and movement</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 45-60 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Pixie Cut</h3>
                  <span class="service-price">₱500</span>
                </div>
                <p class="service-description">Short, stylish cut</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 30-45 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Hair Color Services -->
        <div class="service-category" id="haircolor">
          <div class="services-grid">
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Root Touch-Up</h3>
                  <span class="service-price">₱1,200</span>
                </div>
                <p class="service-description">Color application on regrowth</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 60-90 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Full Color</h3>
                  <span class="service-price">₱2,500</span>
                </div>
                <p class="service-description">Single process all-over color</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 90-120 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Highlights</h3>
                  <span class="service-price">₱3,500</span>
                </div>
                <p class="service-description">Partial or full foil highlights</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 120-180 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Balayage</h3>
                  <span class="service-price">₱4,500</span>
                </div>
                <p class="service-description">Hand-painted highlights for natural look</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 150-210 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Ombre</h3>
                  <span class="service-price">₱4,000</span>
                </div>
                <p class="service-description">Gradual color transition</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 120-180 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Fashion Colors</h3>
                  <span class="service-price">₱3,800</span>
                </div>
                <p class="service-description">Vibrant, non-traditional colors</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 120-240 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Rebonding Services -->
        <div class="service-category" id="rebonding">
          <div class="services-grid">
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Hair Rebonding</h3>
                  <span class="service-price">₱4,500</span>
                </div>
                <p class="service-description">Straightening for all hair lengths</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 180-240 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Japanese Straightening</h3>
                  <span class="service-price">₱6,000</span>
                </div>
                <p class="service-description">Premium straightening treatment</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 240-300 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Brazilian Blowout</h3>
                  <span class="service-price">₱5,500</span>
                </div>
                <p class="service-description">Smoothing treatment</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 120-180 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Digital Perm</h3>
                  <span class="service-price">₱4,800</span>
                </div>
                <p class="service-description">Creates natural-looking waves</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 180-240 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Cold Perm</h3>
                  <span class="service-price">₱3,500</span>
                </div>
                <p class="service-description">Traditional curling method</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 150-210 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Root Rebonding</h3>
                  <span class="service-price">₱2,500</span>
                </div>
                <p class="service-description">Touch-up for new growth</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 120-150 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Hair Treatment Services -->
        <div class="service-category" id="hairtreatment">
          <div class="services-grid">
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Deep Conditioning</h3>
                  <span class="service-price">₱800</span>
                </div>
                <p class="service-description">Intensive moisture treatment</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 30-45 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Keratin Treatment</h3>
                  <span class="service-price">₱3,500</span>
                </div>
                <p class="service-description">Anti-frizz smoothing</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 120-180 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Hair Spa</h3>
                  <span class="service-price">₱1,200</span>
                </div>
                <p class="service-description">Scalp and hair therapy</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 60-90 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Hot Oil Treatment</h3>
                  <span class="service-price">₱950</span>
                </div>
                <p class="service-description">Nourishing oil therapy</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 45-60 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Scalp Treatment</h3>
                  <span class="service-price">₱1,100</span>
                </div>
                <p class="service-description">For dandruff and scalp issues</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 45-60 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Hair Botox</h3>
                  <span class="service-price">₱4,000</span>
                </div>
                <p class="service-description">Reconstructive fiber treatment</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 90-120 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Nails Services -->
        <div class="service-category" id="nails">
          <div class="services-grid">
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Manicure</h3>
                  <span class="service-price">₱350</span>
                </div>
                <p class="service-description">Classic nail care for hands</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 30-45 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Pedicure</h3>
                  <span class="service-price">₱450</span>
                </div>
                <p class="service-description">Classic nail care for feet</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 45-60 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Gel Polish</h3>
                  <span class="service-price">₱650</span>
                </div>
                <p class="service-description">Long-lasting color application</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 45-60 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Nail Art</h3>
                  <span class="service-price">₱800</span>
                </div>
                <p class="service-description">Custom designs per nail</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 60-90 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Nail Extensions</h3>
                  <span class="service-price">₱1,200</span>
                </div>
                <p class="service-description">Acrylic or gel extensions</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 90-120 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Paraffin Treatment</h3>
                  <span class="service-price">₱500</span>
                </div>
                <p class="service-description">Moisturizing wax therapy</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 30-45 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Braiding Services -->
        <div class="service-category" id="braiding">
          <div class="services-grid">
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Basic Braids</h3>
                  <span class="service-price">₱500</span>
                </div>
                <p class="service-description">Simple braided styles</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 30-45 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Box Braids</h3>
                  <span class="service-price">₱3,500</span>
                </div>
                <p class="service-description">Traditional protective style</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 240-360 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Cornrows</h3>
                  <span class="service-price">₱2,000</span>
                </div>
                <p class="service-description">Scalp braids in patterns</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 120-180 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Dutch Braids</h3>
                  <span class="service-price">₱800</span>
                </div>
                <p class="service-description">Inverted French braids</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 45-60 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Fishtail Braid</h3>
                  <span class="service-price">₱700</span>
                </div>
                <p class="service-description">Elegant woven pattern</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 30-45 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Braided Updo</h3>
                  <span class="service-price">₱1,500</span>
                </div>
                <p class="service-description">Formal braided style</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 60-90 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- For Men Services -->
        <div class="service-category" id="formen">
          <div class="services-grid">
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Executive Cut</h3>
                  <span class="service-price">₱400</span>
                </div>
                <p class="service-description">Professional style haircut</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 30-45 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Beard Trim</h3>
                  <span class="service-price">₱250</span>
                </div>
                <p class="service-description">Shaping and maintenance</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 15-30 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Hot Towel Shave</h3>
                  <span class="service-price">₱500</span>
                </div>
                <p class="service-description">Traditional straight razor shave</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 30-45 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Hair & Beard Color</h3>
                  <span class="service-price">₱1,200</span>
                </div>
                <p class="service-description">Gray coverage for hair and beard</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 60-90 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Men's Facial</h3>
                  <span class="service-price">₱950</span>
                </div>
                <p class="service-description">Skincare treatment for men</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 45-60 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Scalp Treatment</h3>
                  <span class="service-price">₱800</span>
                </div>
                <p class="service-description">For thinning hair and dandruff</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 30-45 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- For Women Services -->
        <div class="service-category" id="forwomen">
          <div class="services-grid">
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Blowout & Styling</h3>
                  <span class="service-price">₱650</span>
                </div>
                <p class="service-description">Wash and professional styling</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 45-60 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Special Occasion Style</h3>
                  <span class="service-price">₱1,500</span>
                </div>
                <p class="service-description">Formal or event styling</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 60-90 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Bridal Trial</h3>
                  <span class="service-price">₱2,000</span>
                </div>
                <p class="service-description">Test run for wedding hair</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 90-120 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Bridal Hair</h3>
                  <span class="service-price">₱3,500</span>
                </div>
                <p class="service-description">Wedding day styling</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 90-120 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Hair Extensions</h3>
                  <span class="service-price">₱5,000</span>
                </div>
                <p class="service-description">Clip-in or permanent</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 120-240 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
            <div class="service-card">
              <div class="service-content">
                <div class="service-header">
                  <h3 class="service-title">Hair Accessories</h3>
                  <span class="service-price">₱500</span>
                </div>
                <p class="service-description">Application of decorative pieces</p>
                <div class="service-footer">
                  <span class="service-duration">Duration: 30-45 mins</span>
                  <button class="book-btn">Book Now</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
  </section>

<?php include('footer1.php'); ?>

<script src="/JAVASCRIPT/services.js"></script>
