<footer class="footer">
  <div class="footer-container">
    <div class="footer-content">
      <img class="footer-logo" src="/PHOTOS/logo.png" alt="Salon Logo">
      <small class="footer-copyright">&copy; 2025 ASQ-Maestra Salon. All Rights Reserved.</small>
    </div>
  </div>
</footer>

<style>
  .footer {
    background-color: #333;
    padding: 2rem 0;
  }
  
  .footer-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 1rem;
  }
  
  .footer-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
  }
  
  .footer-logo {
    width: 30px;
    height: 30px;
    margin-bottom: 0.5rem;
  }
  
  .footer-copyright {
    color: white;
    font-size: 0.875rem;
  }
</style>

</body>
</html>
