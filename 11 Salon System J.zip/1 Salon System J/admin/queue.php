<?php

// Then at the top of the page, check for status message
if (isset($_GET['status']) && $_GET['status'] === 'success') {
    $success_message = $_GET['message'] ?? "Operation completed successfully!";
}

$page_title = "Queue Manager - Salon Admin";
include 'components/header.php';
include 'components/sidebar.php';
include 'components/navbar.php';

// Include database connection
include '../login_register/tools/salondb.php';
$conn = getDatabaseConnection();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        // Add to queue
        if ($_POST['action'] === 'add') {
            $customer_name = $_POST['customer_name'];
            $phone = $_POST['phone'];
            $service = $_POST['service'];
            $queue_date = $_POST['queue_date'];
            $queue_time = $_POST['queue_time'] ?? null;
            $status = 'waiting';

            
            // If it's for today, check current queue number
            if ($queue_date === 'today') {
                $today = date('Y-m-d');
                
                // Get max queue number for today
                $stmt = $conn->prepare("SELECT MAX(queue_number) as max_number FROM queue WHERE queue_date = ?");
                $stmt->bind_param("s", $today);
                $stmt->execute();
                $result = $stmt->get_result();
                $row = $result->fetch_assoc();
                $queue_number = ($row['max_number'] ?? 0) + 1;
                $stmt->close();
                
                // Insert into queue
                $stmt = $conn->prepare("INSERT INTO queue (customer_name, phone, service, queue_date, queue_number, status) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("ssssis", $customer_name, $phone, $service, $today, $queue_number, $status);
                $stmt->execute();
                $stmt->close();
            } 
            // If it's for tomorrow
            else {
                $tomorrow = date('Y-m-d', strtotime('+1 day'));
                
                // Get max queue number for tomorrow
                $stmt = $conn->prepare("SELECT MAX(queue_number) as max_number FROM queue WHERE queue_date = ?");
                $stmt->bind_param("s", $tomorrow);
                $stmt->execute();
                $result = $stmt->get_result();
                $row = $result->fetch_assoc();
                $queue_number = ($row['max_number'] ?? 0) + 1;
                $stmt->close();
                
                // Insert into queue with time
                $stmt = $conn->prepare("INSERT INTO queue (customer_name, phone, service, queue_date, queue_time, queue_number, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("sssssis", $customer_name, $phone, $service, $tomorrow, $queue_time, $queue_number, $status);
                $stmt->execute();
                $stmt->close();
            }

            $success_message = "Added to queue successfully!";
            /*
            header("Location: queue.php?status=success&message=Added+to+queue+successfully");
            exit; 
            */
        } 
        // Update queue status
        else if ($_POST['action'] === 'update_status') {
            $id = $_POST['queue_id'];
            $status = $_POST['status'];
            
            $stmt = $conn->prepare("UPDATE queue SET status = ? WHERE id = ?");
            $stmt->bind_param("si", $status, $id);
            $stmt->execute();
            $stmt->close();
            
            $success_message = "Queue status updated successfully!";
        }
        
        // Remove from queue
        else if ($_POST['action'] === 'remove') {
            $id = $_POST['queue_id'];
            
            $stmt = $conn->prepare("DELETE FROM queue WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();
            
            $success_message = "Removed from queue successfully!";
        }
        
        // Send notification
        else if ($_POST['action'] === 'notify') {
            $id = $_POST['queue_id'];
            $message = $_POST['message'];
            $send_sms = isset($_POST['send_sms']) ? 1 : 0;
            
            // In a real application, you would send an SMS here
            // For now, we'll just update a notification_sent field
            $stmt = $conn->prepare("UPDATE queue SET notification_sent = 1 WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();
            
            $success_message = "Notification sent successfully!";
        }
        
        // Next queue
        else if ($_POST['action'] === 'next') {
            // Get current serving queue
            $today = date('Y-m-d');
            $serving_status = 'serving';
            $waiting_status = 'waiting';
            
            $stmt = $conn->prepare("SELECT id FROM queue WHERE queue_date = ? AND status = ?");
            $stmt->bind_param("ss", $today, $serving_status);
            $stmt->execute();
            $result = $stmt->get_result();
            
            // If there's a current serving queue, mark it as served
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $current_id = $row['id'];
                
                $served_status = 'served';
                $update_stmt = $conn->prepare("UPDATE queue SET status = ? WHERE id = ?");
                $update_stmt->bind_param("si", $served_status, $current_id);
                $update_stmt->execute();
                $update_stmt->close();
            }
            $stmt->close();
            
            // Get next waiting queue
            $stmt = $conn->prepare("SELECT id FROM queue WHERE queue_date = ? AND status = ? ORDER BY queue_number LIMIT 1");
            $stmt->bind_param("ss", $today, $waiting_status);
            $stmt->execute();
            $result = $stmt->get_result();
            
            // If there's a waiting queue, mark it as serving
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $next_id = $row['id'];
                
                $update_stmt = $conn->prepare("UPDATE queue SET status = ? WHERE id = ?");
                $update_stmt->bind_param("si", $serving_status, $next_id);
                $update_stmt->execute();
                $update_stmt->close();
                
                $success_message = "Next customer is now serving!";
            } else {
                $success_message = "No more customers in queue.";
            }
            $stmt->close();
        }
        
        // Previous queue
        else if ($_POST['action'] === 'previous') {
            // Get current serving queue
            $today = date('Y-m-d');
            $serving_status = 'serving';
            
            $stmt = $conn->prepare("SELECT id, queue_number FROM queue WHERE queue_date = ? AND status = ?");
            $stmt->bind_param("ss", $today, $serving_status);
            $stmt->execute();
            $result = $stmt->get_result();
            
            // If there's a current serving queue
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $current_id = $row['id'];
                $current_number = $row['queue_number'];
                
                // Mark current as waiting
                $waiting_status = 'waiting';
                $update_stmt = $conn->prepare("UPDATE queue SET status = ? WHERE id = ?");
                $update_stmt->bind_param("si", $waiting_status, $current_id);
                $update_stmt->execute();
                $update_stmt->close();
                
                // Find previous served queue
                $served_status = 'served';
                $prev_stmt = $conn->prepare("SELECT id FROM queue WHERE queue_date = ? AND status = ? AND queue_number < ? ORDER BY queue_number DESC LIMIT 1");
                $prev_stmt->bind_param("ssi", $today, $served_status, $current_number);
                $prev_stmt->execute();
                $prev_result = $prev_stmt->get_result();
                
                // If there's a previous served queue, mark it as serving
                if ($prev_result->num_rows > 0) {
                    $prev_row = $prev_result->fetch_assoc();
                    $prev_id = $prev_row['id'];
                    
                    $update_stmt = $conn->prepare("UPDATE queue SET status = ? WHERE id = ?");
                    $update_stmt->bind_param("si", $serving_status, $prev_id);
                    $update_stmt->execute();
                    $update_stmt->close();
                    
                    $success_message = "Returned to previous customer!";
                } else {
                    $success_message = "No previous customer in queue.";
                }
                $prev_stmt->close();
            } else {
                $success_message = "No customer currently serving.";
            }
            $stmt->close();
        }
        header("Location: queue.php?status=success&message=" . urlencode($success_message));
        exit;
    } // End of if(isset($_POST['action']))
} // End of if ($_SERVER['REQUEST_METHOD'] === 'POST')


// Get today's queue
$today = date('Y-m-d');
$today_queue = [];
$stmt = $conn->prepare("SELECT * FROM queue WHERE queue_date = ? ORDER BY queue_number");
$stmt->bind_param("s", $today);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $today_queue[] = $row;
}
$stmt->close();

// Get tomorrow's queue
$tomorrow = date('Y-m-d', strtotime('+1 day'));
$tomorrow_queue = [];
$stmt = $conn->prepare("SELECT * FROM queue WHERE queue_date = ? ORDER BY queue_number");
$stmt->bind_param("s", $tomorrow);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $tomorrow_queue[] = $row;
}
$stmt->close();

// Get current serving queue
$current_queue = null;
$serving_status = 'serving';
$stmt = $conn->prepare("SELECT * FROM queue WHERE queue_date = ? AND status = ?");
$stmt->bind_param("ss", $today, $serving_status);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $current_queue = $result->fetch_assoc();
}
$stmt->close();

// Count queue statistics
$waiting_count = 0;
$served_count = 0;
$total_count = count($today_queue);

foreach ($today_queue as $queue) {
    if ($queue['status'] === 'waiting') {
        $waiting_count++;
    } else if ($queue['status'] === 'served') {
        $served_count++;
    }
}

$conn->close();
?>

<div class="p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Queue Manager</h2>
        <div>
            <button class="btn btn-sm btn-outline-success me-2" id="add-queue-btn">
                <i class="bi bi-plus-circle me-1"></i> Add to Queue
            </button>
            <button class="btn btn-sm btn-outline-pink" id="notify-all-btn">
                <i class="bi bi-bell me-1"></i> Notify All
            </button>
        </div>
    </div>

    <?php if (isset($success_message)): ?>
    <div class="alert alert-success" id="queue-message"><?php echo $success_message; ?></div>
    <?php else: ?>
    <div class="alert alert-success d-none" id="queue-message"></div>
    <?php endif; ?>

    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-pink text-white">
                    <h5 class="mb-0">Today's Queue</h5>
                </div>
                <div class="card-body">
                    <div class="current-serving p-3 mb-3 bg-light text-center">
                        <h3 class="mb-0">Now Serving</h3>
                        <div class="display-1 text-pink fw-bold" id="current-number">
                            <?php echo $current_queue ? $current_queue['queue_number'] : '-'; ?>
                        </div>
                        <p class="mb-0" id="current-customer">
                            <?php echo $current_queue ? $current_queue['customer_name'] : 'No one currently serving'; ?>
                        </p>
                    </div>

                    <div class="d-flex justify-content-center mb-3">
                        <form method="post" class="me-2">
                            <input type="hidden" name="action" value="previous">
                            <button type="submit" class="btn btn-outline-secondary" id="prev-queue">
                                <i class="bi bi-arrow-left"></i> Previous
                            </button>
                        </form>
                        <form method="post">
                            <input type="hidden" name="action" value="next">
                            <button type="submit" class="btn btn-outline-pink" id="next-queue">
                                Next <i class="bi bi-arrow-right"></i>
                            </button>
                        </form>
                    </div>

                    <div class="queue-stats d-flex justify-content-around text-center">
                        <div>
                            <h5>Waiting</h5>
                            <p class="mb-0 fs-4" id="waiting-count"><?php echo $waiting_count; ?></p>
                        </div>
                        <div>
                            <h5>Served</h5>
                            <p class="mb-0 fs-4" id="served-count"><?php echo $served_count; ?></p>
                        </div>
                        <div>
                            <h5>Total</h5>
                            <p class="mb-0 fs-4" id="total-count"><?php echo $total_count; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-pink text-white">
                    <h5 class="mb-0">Queue List</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table mb-0">
                            <thead>
                                <tr>
                                    <th>Queue #</th>
                                    <th>Customer</th>
                                    <th>Service</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="queue-table">
                                <?php if (count($today_queue) > 0): ?>
                                    <?php foreach ($today_queue as $queue): ?>
                                        <tr class="<?php 
                                            echo $queue['status'] === 'serving' ? 'table-primary' : 
                                                ($queue['status'] === 'served' ? 'table-success' : ''); 
                                        ?>">
                                            <td><?php echo $queue['queue_number']; ?></td>
                                            <td><?php echo $queue['customer_name']; ?></td>
                                            <td><?php echo $queue['service']; ?></td>
                                            <td>
                                                <span class="badge <?php 
                                                    echo $queue['status'] === 'serving' ? 'bg-primary' : 
                                                        ($queue['status'] === 'served' ? 'bg-success' : 'bg-secondary'); 
                                                ?>">
                                                    <?php echo ucfirst($queue['status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-outline-primary me-1 notify-btn" data-queue-id="<?php echo $queue['id']; ?>">
                                                    <i class="bi bi-bell"></i>
                                                </button>
                                                <form method="post" class="d-inline">
                                                    <input type="hidden" name="action" value="remove">
                                                    <input type="hidden" name="queue_id" value="<?php echo $queue['id']; ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-danger remove-btn" onclick="return confirm('Are you sure you want to remove this customer from the queue?')">
                                                        <i class="bi bi-x-circle"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="text-center">No customers in queue</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header bg-pink text-white">
            <h5 class="mb-0">Tomorrow's Queue</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Queue #</th>
                            <th>Customer</th>
                            <th>Service</th>
                            <th>Time</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="tomorrow-queue">
                        <?php if (count($tomorrow_queue) > 0): ?>
                            <?php foreach ($tomorrow_queue as $queue): ?>
                                <tr>
                                    <td><?php echo $queue['queue_number']; ?></td>
                                    <td><?php echo $queue['customer_name']; ?></td>
                                    <td><?php echo $queue['service']; ?></td>
                                    <td><?php echo $queue['queue_time'] ? date('h:i A', strtotime($queue['queue_time'])) : 'N/A'; ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-primary me-1 notify-btn" data-queue-id="<?php echo $queue['id']; ?>">
                                            <i class="bi bi-bell"></i>
                                        </button>
                                        <form method="post" class="d-inline">
                                            <input type="hidden" name="action" value="remove">
                                            <input type="hidden" name="queue_id" value="<?php echo $queue['id']; ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-danger remove-btn" onclick="return confirm('Are you sure you want to remove this customer from the queue?')">
                                                <i class="bi bi-x-circle"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center">No customers in tomorrow's queue</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include 'components/modals/queue_modal.php'; ?>
<?php include 'components/modals/notify_modal.php'; ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Add to queue modal
        const addQueueModal = new bootstrap.Modal(document.getElementById('addQueueModal'));
        
        document.getElementById('add-queue-btn').addEventListener('click', function () {
            // Reset form
            document.getElementById('addQueueForm').reset();
            
            // Show/hide time field based on date selection
            toggleTimeField();
            
            // Show modal
            addQueueModal.show();
        });
        
        // Toggle time field based on date selection
        document.getElementById('queueDate').addEventListener('change', toggleTimeField);
        
        function toggleTimeField() {
            const queueDate = document.getElementById('queueDate').value;
            const timeField = document.getElementById('timeField');
            
            if (queueDate === 'tomorrow') {
                timeField.style.display = 'block';
                document.getElementById('queueTime').required = true;
            } else {
                timeField.style.display = 'none';
                document.getElementById('queueTime').required = false;
            }
        }
        
        // Notify customer modal
        const notifyModal = new bootstrap.Modal(document.getElementById('notifyModal'));
        
        document.querySelectorAll('.notify-btn').forEach(button => {
            button.addEventListener('click', function () {
                const queueId = this.getAttribute('data-queue-id');
                openNotifyModal(queueId);
            });
        });
        
        function openNotifyModal(queueId) {
            // Set queue ID
            document.getElementById('notifyQueueId').value = queueId;
            
            // Set default message
            const defaultMessage = "Hi, this is a notification from Jose Maestra Barbera Salon.";
            document.getElementById('notifyMessage').value = defaultMessage;
            
            // Show modal
            notifyModal.show();
        }
        
        // Send notification
        document.getElementById('sendNotification').addEventListener('click', function () {
            const queueId = document.getElementById('notifyQueueId').value;
            const message = document.getElementById('notifyMessage').value;
            const sendSMS = document.getElementById('sendSMS').checked;
            
            // Create form for submission
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const actionInput = document.createElement('input');
            actionInput.name = 'action';
            actionInput.value = 'notify';
            form.appendChild(actionInput);
            
            const idInput = document.createElement('input');
            idInput.name = 'queue_id';
            idInput.value = queueId;
            form.appendChild(idInput);
            
            const messageInput = document.createElement('input');
            messageInput.name = 'message';
            messageInput.value = message;
            form.appendChild(messageInput);
            
            if (sendSMS) {
                const smsInput = document.createElement('input');
                smsInput.name = 'send_sms';
                smsInput.value = '1';
                form.appendChild(smsInput);
            }
            
            document.body.appendChild(form);
            form.submit();
        });
        
        // Notify all button
        document.getElementById('notify-all-btn').addEventListener('click', function () {
            if (confirm('Are you sure you want to notify all waiting customers?')) {
                // In a real application, you would send notifications to all waiting customers
                // For now, we'll just show a success message
                
                // Create form for submission
                const form = document.createElement('form');
                form.method = 'POST';
                form.style.display = 'none';
                
                const actionInput = document.createElement('input');
                actionInput.name = 'action';
                actionInput.value = 'notify_all';
                form.appendChild(actionInput);
                
                document.body.appendChild(form);
                form.submit();
            }
        });
        
        // Save queue
        document.getElementById('saveQueue').addEventListener('click', function () {
            const customerName = document.getElementById('customerName').value;
            const customerPhone = document.getElementById('customerPhone').value;
            const serviceType = document.getElementById('serviceType').value;
            const queueDate = document.getElementById('queueDate').value;
            const queueTime = document.getElementById('queueTime').value;
            
            // Validate form
            if (!customerName || !customerPhone || !serviceType) {
                alert('Please fill in all required fields');
                return;
            }
            
            if (queueDate === 'tomorrow' && !queueTime) {
                alert('Please select a time for tomorrow\'s appointment');
                return;
            }
            
            // Create form for submission
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const actionInput = document.createElement('input');
            actionInput.name = 'action';
            actionInput.value = 'add';
            form.appendChild(actionInput);
            
            const nameInput = document.createElement('input');
            nameInput.name = 'customer_name';
            nameInput.value = customerName;
            form.appendChild(nameInput);
            
            const phoneInput = document.createElement('input');
            phoneInput.name = 'phone';
            phoneInput.value = customerPhone;
            form.appendChild(phoneInput);
            
            const serviceInput = document.createElement('input');
            serviceInput.name = 'service';
            serviceInput.value = serviceType;
            form.appendChild(serviceInput);
            
            const dateInput = document.createElement('input');
            dateInput.name = 'queue_date';
            dateInput.value = queueDate;
            form.appendChild(dateInput);
            
            if (queueDate === 'tomorrow') {
                const timeInput = document.createElement('input');
                timeInput.name = 'queue_time';
                timeInput.value = queueTime;
                form.appendChild(timeInput);
            }
            
            document.body.appendChild(form);
            form.submit();
        });
    });
</script>

<?php include 'components/footer.php'; ?>
