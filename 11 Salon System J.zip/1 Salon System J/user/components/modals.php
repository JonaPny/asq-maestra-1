<!-- Checkout Modal -->
<div class="modal" id="checkout-modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Complete Your Booking</h2>
            <button class="close-modal">&times;</button>
        </div>
        <div class="modal-body">
            <div class="checkout-summary">
                <h3>Order Summary</h3>
                <div id="checkout-items">
                    <!-- Checkout items will be added here dynamically -->
                </div>
                <div class="summary-row">
                    <span>Subtotal:</span>
                    <span id="checkout-subtotal">₱0.00</span>
                </div>
                <div id="checkout-transportation-container" class="summary-row" style="display: none;">
                    <span>Transportation Fee:</span>
                    <span id="checkout-transportation">₱0.00</span>
                </div>
                <div class="summary-row total">
                    <span>Total:</span>
                    <span id="checkout-total">₱0.00</span>
                </div>
                <div id="checkout-deposit-info" class="hidden">
                    <div class="summary-row">
                        <span>Deposit Amount (50%):</span>
                        <span id="checkout-deposit">₱0.00</span>
                    </div>
                    <div class="summary-row">
                        <span>Balance Due at Appointment:</span>
                        <span id="checkout-balance">₱0.00</span>
                    </div>
                </div>
            </div>

            <div class="appointment-selection">
                <h3>Select Appointment Time</h3>
                <div class="form-group">
                    <label for="appointment-date">Date</label>
                    <input type="date" id="appointment-date" min="2025-05-06">
                </div>
                <div class="form-group">
                    <label for="appointment-time">Time</label>
                    <select id="appointment-time">
                        <option value="">Select a date first</option>
                    </select>
                </div>
            </div>
            
            <div id="checkout-location-container" style="display: none;">
                <h3>Service Location</h3>
                <div class="form-group">
                    <label for="checkout-service-type">Service Type:</label>
                    <select id="checkout-service-type" class="form-control">
                        <option value="salon">Salon Service</option>
                        <option value="home">Home Service</option>
                    </select>
                </div>
                
                <div id="checkout-location-details" style="display: none;">
                    <div class="form-group">
                        <label for="checkout-location-area">Location Area:</label>
                        <select id="checkout-location-area" class="form-control">
                            <option value="canlubang">Within Canlubang</option>
                            <option value="calamba">Within Calamba (outside Canlubang)</option>
                            <option value="outside">Outside Calamba</option>
                        </select>
                    </div>
                    <div id="checkout-custom-fee-container" style="display: none;">
                        <div class="form-group">
                            <label for="checkout-custom-fee">Custom Transportation Fee (₱):</label>
                            <input type="number" id="checkout-custom-fee" class="form-control" min="1000" step="100" value="1000">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="checkout-address">Complete Address:</label>
                        <textarea id="checkout-address" class="form-control" rows="3" placeholder="Please enter your complete address for home service"></textarea>
                    </div>
                </div>
            </div>

            <div class="payment-method">
                <h3>Payment Method</h3>
                <div class="payment-cards">
                    <div class="payment-card selected">
                        <i class="fas fa-credit-card"></i>
                        <span>Credit Card</span>
                    </div>
                    <div class="payment-card">
                        <i class="fas fa-mobile-alt"></i>
                        <span>GCash</span>
                    </div>
                    <div class="payment-card">
                        <i class="fas fa-wallet"></i>
                        <span>Maya</span>
                    </div>
                </div>

                <div id="credit-card-form" class="payment-form">
                    <div class="form-group">
                        <label for="card-number">Card Number</label>
                        <input type="text" id="card-number" placeholder="1234 5678 9012 3456">
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="expiry-date">Expiry Date</label>
                            <input type="text" id="expiry-date" placeholder="MM/YY">
                        </div>
                        <div class="form-group">
                            <label for="cvv">CVV</label>
                            <input type="text" id="cvv" placeholder="123">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="card-name">Name on Card</label>
                        <input type="text" id="card-name" placeholder="John Doe">
                    </div>
                </div>
                
                <div id="gcash-form" class="payment-form" style="display: none;">
                    <div class="form-group">
                        <label for="gcash-number">GCash Number</label>
                        <input type="text" id="gcash-number" placeholder="09XX XXX XXXX">
                    </div>
                    <div class="form-group">
                        <label for="gcash-name">Account Name</label>
                        <input type="text" id="gcash-name" placeholder="Juan Dela Cruz">
                    </div>
                </div>
                
                <div id="maya-form" class="payment-form" style="display: none;">
                    <div class="form-group">
                        <label for="maya-number">Maya Account Number</label>
                        <input type="text" id="maya-number" placeholder="09XX XXX XXXX">
                    </div>
                    <div class="form-group">
                        <label for="maya-name">Account Name</label>
                        <input type="text" id="maya-name" placeholder="Juan Dela Cruz">
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="cancel-btn">Cancel</button>
            <button class="confirm-btn" id="confirm-booking">Confirm Booking</button>
        </div>
    </div>
</div>

<!-- Booking Confirmation Modal -->
<div class="modal" id="confirmation-modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Booking Confirmed!</h2>
            <button class="close-modal">&times;</button>
        </div>
        <div class="modal-body">
            <div class="confirmation-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h3>Thank you for your booking</h3>
            <p>Your appointment has been confirmed for:</p>
            <div class="confirmation-details">
                <p><strong>Date:</strong> <span id="confirmed-date">May 10, 2025</span></p>
                <p><strong>Time:</strong> <span id="confirmed-time">2:00 PM</span></p>
                <p><strong>Services:</strong> <span id="confirmed-services">Hair Coloring, Women's Haircut</span></p>
                <p><strong>Service Type:</strong> <span id="confirmed-service-type">Salon Service</span></p>
                <div id="confirmed-location-container" style="display: none;">
                    <p><strong>Location:</strong> <span id="confirmed-location">Within Canlubang</span></p>
                    <p><strong>Address:</strong> <span id="confirmed-address">123 Main St, Canlubang</span></p>
                    <p><strong>Transportation Fee:</strong> <span id="confirmed-transportation">₱0.00</span></p>
                </div>
                <p><strong>Total:</strong> <span id="confirmed-total">₱140.00</span></p>
                <p><strong>Payment Method:</strong> <span id="confirmed-payment-method">Credit Card</span></p>
                <p><strong>Payment Status:</strong> <span id="confirmed-payment">Paid in Full</span></p>
            </div>
            <p>A confirmation email has been sent to your registered email address.</p>
            <p>You will receive a reminder notification 24 hours before your appointment.</p>
        </div>
        <div class="modal-footer">
            <button class="confirm-btn" id="close-confirmation">Done</button>
        </div>
    </div>
</div>
