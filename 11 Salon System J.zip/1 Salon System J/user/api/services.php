<?php
// Set headers for JSON response
header('Content-Type: application/json');

// Database connection
include "../../login_register/tools/salondb.php";
$pdo = getDatabaseConnection('pdo');

// Get action from request
$action = isset($_GET['action']) ? $_GET['action'] : '';

// Handle different actions
switch ($action) {
    case 'getAll':
        getAllServices();
        break;
    case 'getByCategory':
        $category = isset($_GET['category']) ? $_GET['category'] : '';
        getServicesByCategory($category);
        break;
    case 'add':
        addService();
        break;
    case 'update':
        updateService();
        break;
    case 'delete':
        $id = isset($_GET['id']) ? $_GET['id'] : '';
        deleteService($id);
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
        break;
}

// Get all services
function getAllServices() {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM services ORDER BY category, name");
        $stmt->execute();
        $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode($services);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error fetching services: ' . $e->getMessage()]);
    }
}

// Get services by category
function getServicesByCategory($category) {
    global $pdo;

    try {
        $stmt = $pdo->prepare("SELECT * FROM services WHERE category = :category ORDER BY name");
        $stmt->bindParam(':category', $category);
        $stmt->execute();
        $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode($services);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error fetching services: ' . $e->getMessage()]);
    }
}

// Add a new service
function addService() {
    global $pdo;
    
    // Get JSON data from request body
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!$data) {
        echo json_encode(['success' => false, 'message' => 'Invalid data']);
        return;
    }
    
    try {
        // Get the next category ID
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM services WHERE category = :category");
        $stmt->bindParam(':category', $data['category']);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $categoryCount = $result['count'] + 1;
        
        // Create a category_id
        $categoryId = $data['category'] . '_' . $categoryCount;
        
        $stmt = $pdo->prepare("
            INSERT INTO services (name, description, price, duration, category, subcategory, status, category_id) 
            VALUES (:name, :description, :price, :duration, :category, :subcategory, :status, :category_id)
        ");
        
        $stmt->bindParam(':name', $data['name']);
        $stmt->bindParam(':description', $data['description']);
        $stmt->bindParam(':price', $data['price']);
        $stmt->bindParam(':duration', $data['duration']);
        $stmt->bindParam(':category', $data['category']);
        $stmt->bindParam(':subcategory', $data['subcategory']);
        $stmt->bindParam(':status', $data['status']);
        $stmt->bindParam(':category_id', $categoryId);
        
        $stmt->execute();
        
        echo json_encode([
            'success' => true, 
            'message' => 'Service added successfully',
            'service_id' => $pdo->lastInsertId()
        ]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error adding service: ' . $e->getMessage()]);
    }
}

// Update an existing service
function updateService() {
    global $pdo;
    
    // Get JSON data from request body
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!$data || !isset($data['service_id'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid data or missing service ID']);
        return;
    }
    
    try {
        $stmt = $pdo->prepare("
            UPDATE services 
            SET name = :name, 
                description = :description, 
                price = :price, 
                duration = :duration, 
                category = :category, 
                subcategory = :subcategory, 
                status = :status 
            WHERE service_id = :service_id
        ");
        
        $stmt->bindParam(':name', $data['name']);
        $stmt->bindParam(':description', $data['description']);
        $stmt->bindParam(':price', $data['price']);
        $stmt->bindParam(':duration', $data['duration']);
        $stmt->bindParam(':category', $data['category']);
        $stmt->bindParam(':subcategory', $data['subcategory']);
        $stmt->bindParam(':status', $data['status']);
        $stmt->bindParam(':service_id', $data['service_id']);
        
        $stmt->execute();
        
        echo json_encode(['success' => true, 'message' => 'Service updated successfully']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error updating service: ' . $e->getMessage()]);
    }
}

// Delete a service
function deleteService($id) {
    global $pdo;
    
    if (!$id) {
        echo json_encode(['success' => false, 'message' => 'Missing service ID']);
        return;
    }
    
    try {
        $stmt = $pdo->prepare("DELETE FROM services WHERE service_id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        
        echo json_encode(['success' => true, 'message' => 'Service deleted successfully']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error deleting service: ' . $e->getMessage()]);
    }
}
?>
