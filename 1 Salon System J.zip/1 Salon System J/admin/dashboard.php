<?php
$page_title = "Dashboard - Salon Admin";
include 'components/header.php';
include 'components/sidebar.php';
include 'components/navbar.php';

// Include database connection
include 'includes/db_connection.php';
$conn = getAdminDatabaseConnection();

// Get current month and year
$month = isset($_GET['month']) ? intval($_GET['month']) : date('n');
$year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        // Update day status
        if ($_POST['action'] === 'update_day') {
            $date = $_POST['date'];
            $status = $_POST['status'];
            $notes = $_POST['notes'];
            
            // Check if day already exists in calendar_settings
            $stmt = $conn->prepare("SELECT id FROM calendar_settings WHERE date = ?");
            $stmt->bind_param("s", $date);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                // Update existing record
                $row = $result->fetch_assoc();
                $stmt = $conn->prepare("UPDATE calendar_settings SET status = ?, notes = ? WHERE id = ?");
                $stmt->bind_param("ssi", $status, $notes, $row['id']);
            } else {
                // Insert new record
                $stmt = $conn->prepare("INSERT INTO calendar_settings (date, status, notes) VALUES (?, ?, ?)");
                $stmt->bind_param("sss", $date, $status, $notes);
            }
            
            $stmt->execute();
            $stmt->close();
            
            $success_message = "Day status updated successfully!";
        }
    }
}

// Get calendar settings for the month
$calendar_settings = [];
$first_day = sprintf('%04d-%02d-01', $year, $month);
$last_day = date('Y-m-t', strtotime($first_day));

$stmt = $conn->prepare("SELECT date, status, notes FROM calendar_settings WHERE date BETWEEN ? AND ?");
$stmt->bind_param("ss", $first_day, $last_day);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $calendar_settings[$row['date']] = [
        'status' => $row['status'],
        'notes' => $row['notes']
    ];
}
$stmt->close();

// Get appointment counts for the month
$appointments = [];
$stmt = $conn->prepare("SELECT appointment_date, COUNT(*) as count, service_type FROM appointments WHERE appointment_date BETWEEN ? AND ? GROUP BY appointment_date, service_type");
$stmt->bind_param("ss", $first_day, $last_day);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $date = $row['appointment_date'];
    
    if (!isset($appointments[$date])) {
        $appointments[$date] = [
            'count' => 0,
            'type' => ''
        ];
    }
    
    $appointments[$date]['count'] += $row['count'];
    
    // Determine type based on majority
    if ($row['service_type'] === 'home') {
        $appointments[$date]['type'] = 'home-service';
    } else {
        $appointments[$date]['type'] = 'salon-service';
    }
}
$stmt->close();
$conn->close();

// Month names for display
$month_names = [
    1 => "JANUARY", 2 => "FEBRUARY", 3 => "MARCH", 4 => "APRIL",
    5 => "MAY", 6 => "JUNE", 7 => "JULY", 8 => "AUGUST",
    9 => "SEPTEMBER", 10 => "OCTOBER", 11 => "NOVEMBER", 12 => "DECEMBER"
];
?>

<div class="p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-uppercase" id="current-month"><?php echo $month_names[$month] . " " . $year; ?></h2>
        <div class="d-flex align-items-center">
            <a href="?month=<?php echo $month == 1 ? 12 : $month - 1; ?>&year=<?php echo $month == 1 ? $year - 1 : $year; ?>" class="btn btn-sm btn-outline-secondary me-2" id="prev-month">
                <i class="bi bi-chevron-left"></i>
            </a>
            <a href="?month=<?php echo date('n'); ?>&year=<?php echo date('Y'); ?>" class="btn btn-sm btn-outline-secondary me-2" id="today-btn">Today</a>
            <a href="?month=<?php echo $month == 12 ? 1 : $month + 1; ?>&year=<?php echo $month == 12 ? $year + 1 : $year; ?>" class="btn btn-sm btn-outline-secondary me-3" id="next-month">
                <i class="bi bi-chevron-right"></i>
            </a>
            <div class="form-check form-switch me-3">
                <input class="form-check-input" type="checkbox" id="edit-mode">
                <label class="form-check-label" for="edit-mode">Edit Mode</label>
            </div>
        </div>
    </div>

    <?php if (isset($success_message)): ?>
    <div class="alert alert-success" id="calendar-message"><?php echo $success_message; ?></div>
    <?php endif; ?>

    <div class="calendar-legend mb-3">
        <div class="d-flex align-items-center">
            <div class="legend-item me-3">
                <span class="legend-color home-service"></span>
                <span>HOME SERVICE</span>
            </div>
            <div class="legend-item me-3">
                <span class="legend-color salon-service"></span>
                <span>SALON SERVICE</span>
            </div>
            <div class="legend-item me-3">
                <span class="legend-color full-sched"></span>
                <span>FULL SCHED</span>
            </div>
            <div class="legend-item">
                <span class="legend-color blocked"></span>
                <span>BLOCKED</span>
            </div>
        </div>
    </div>

    <div class="calendar-container">
        <table class="table table-bordered calendar-table">
            <thead>
                <tr>
                    <th>Sun</th>
                    <th>Mon</th>
                    <th>Tue</th>
                    <th>Wed</th>
                    <th>Thu</th>
                    <th>Fri</th>
                    <th>Sat</th>
                </tr>
            </thead>
            <tbody id="calendar-body">
                <?php
                // Generate calendar
                $firstDay = new DateTime("$year-$month-01");
                $lastDay = new DateTime($firstDay->format('Y-m-t'));
                $daysInMonth = intval($lastDay->format('d'));
                $startingDay = intval($firstDay->format('w')); // 0 (Sunday) to 6 (Saturday)
                
                $date = 1;
                for ($i = 0; $i < 6; $i++) {
                    echo "<tr>";
                    
                    for ($j = 0; $j < 7; $j++) {
                        if ($i === 0 && $j < $startingDay) {
                            // Empty cells before the first day
                            echo "<td></td>";
                        } else if ($date > $daysInMonth) {
                            // Empty cells after the last day
                            echo "<td></td>";
                        } else {
                            // Create date cell
                            $dateStr = sprintf('%04d-%02d-%02d', $year, $month, $date);
                            $cellClass = '';
                            
                            // Check if this date has a special status
                            if (isset($calendar_settings[$dateStr])) {
                                if ($calendar_settings[$dateStr]['status'] === 'full') {
                                    $cellClass = 'full-sched';
                                } else if ($calendar_settings[$dateStr]['status'] === 'blocked') {
                                    $cellClass = 'blocked';
                                }
                            }
                            // Otherwise, check if it has appointments
                            else if (isset($appointments[$dateStr])) {
                                $cellClass = $appointments[$dateStr]['type'];
                            }
                            
                            echo "<td class=\"$cellClass\" data-date=\"$dateStr\">";
                            echo "<div class=\"calendar-date\">$date</div>";
                            
                            // Add appointment count if any
                            if (isset($appointments[$dateStr]) && $appointments[$dateStr]['count'] > 0) {
                                echo "<span class=\"appointment-count\">{$appointments[$dateStr]['count']}</span>";
                            }
                            
                            echo "</td>";
                            
                            $date++;
                        }
                    }
                    
                    echo "</tr>";
                    
                    // Stop if we've reached the end of the month
                    if ($date > $daysInMonth) {
                        break;
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'components/modals/day_edit_modal.php'; ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Day edit modal
        const dayEditModal = new bootstrap.Modal(document.getElementById('dayEditModal'));
        
        // Calendar cell click event
        document.querySelectorAll('.calendar-table td[data-date]').forEach(cell => {
            cell.addEventListener('click', function () {
                const dateStr = this.getAttribute('data-date');
                
                if (document.getElementById('edit-mode').checked) {
                    openDayEditModal(dateStr);
                } else {
                    viewDayAppointments(dateStr);
                }
            });
        });

        function openDayEditModal(dateStr) {
            document.getElementById('selected-date').value = dateStr;
            
            // Set current status
            let status = 'normal';
            const cell = document.querySelector(`.calendar-table td[data-date="${dateStr}"]`);
            
            if (cell.classList.contains('full-sched')) {
                status = 'full';
            } else if (cell.classList.contains('blocked')) {
                status = 'blocked';
            }
            
            document.querySelector(`input[name="dayStatus"][value="${status}"]`).checked = true;
            
            // Show modal
            dayEditModal.show();
        }
        
        // Save day status
        document.getElementById('saveDayStatus').addEventListener('click', function () {
            const dateStr = document.getElementById('selected-date').value;
            const status = document.querySelector('input[name="dayStatus"]:checked').value;
            const notes = document.getElementById('dayNotes').value;
            
            // Create form for submission
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const actionInput = document.createElement('input');
            actionInput.name = 'action';
            actionInput.value = 'update_day';
            form.appendChild(actionInput);
            
            const dateInput = document.createElement('input');
            dateInput.name = 'date';
            dateInput.value = dateStr;
            form.appendChild(dateInput);
            
            const statusInput = document.createElement('input');
            statusInput.name = 'status';
            statusInput.value = status;
            form.appendChild(statusInput);
            
            const notesInput = document.createElement('input');
            notesInput.name = 'notes';
            notesInput.value = notes;
            form.appendChild(notesInput);
            
            // Add current month and year to preserve after form submission
            const monthInput = document.createElement('input');
            monthInput.name = 'month';
            monthInput.value = <?php echo $month; ?>;
            form.appendChild(monthInput);
            
            const yearInput = document.createElement('input');
            yearInput.name = 'year';
            yearInput.value = <?php echo $year; ?>;
            form.appendChild(yearInput);
            
            document.body.appendChild(form);
            form.submit();
        });
        
        // View day appointments
        function viewDayAppointments(dateStr) {
            const cell = document.querySelector(`.calendar-table td[data-date="${dateStr}"]`);
            
            if (!cell.classList.contains('blocked')) {
                window.location.href = `appointments.php?date=${dateStr}`;
            }
        }
    });
</script>

<?php include 'components/footer.php'; ?>
