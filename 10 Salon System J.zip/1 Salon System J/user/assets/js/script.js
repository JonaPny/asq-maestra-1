document.addEventListener("DOMContentLoaded", () => {
  // DOM Elements
  const notificationIcon = document.getElementById("notification-icon")
  const notificationDropdown = document.getElementById("notification-dropdown")
  const profileIcon = document.getElementById("profile-icon")
  const profileDropdown = document.getElementById("profile-dropdown")
  const cartIcon = document.getElementById("cart-icon")
  const cartSidebar = document.getElementById("cart-sidebar")
  const closeCart = document.getElementById("close-cart")
  const overlay = document.getElementById("overlay")
  const navItems = document.querySelectorAll(".sidebar nav ul li")
  const pages = document.querySelectorAll(".page")
  const categoryTabs = document.querySelectorAll(".category-tab")
  const categoryContents = document.querySelectorAll(".category-content")
  const addToCartButtons = document.querySelectorAll(".add-to-cart-btn")
  const cartItems = document.getElementById("cart-items")
  const cartCount = document.getElementById("cart-count")
  const cartSubtotal = document.getElementById("cart-subtotal")
  const cartTax = document.getElementById("cart-tax")
  const cartTotal = document.getElementById("cart-total")
  const depositPayment = document.getElementById("deposit-payment")
  const fullPayment = document.getElementById("full-payment")
  const depositInfo = document.getElementById("deposit-info")
  const depositAmount = document.getElementById("deposit-amount")
  const balanceDue = document.getElementById("balance-due")
  const checkoutBtn = document.getElementById("checkout-btn")
  const checkoutModal = document.getElementById("checkout-modal")
  const closeModalButtons = document.querySelectorAll(".close-modal")
  const confirmBooking = document.getElementById("confirm-booking")
  const confirmationModal = document.getElementById("confirmation-modal")
  const closeConfirmation = document.getElementById("close-confirmation")
  const historyTabs = document.querySelectorAll(".tab")
  const historyContents = document.querySelectorAll(".tab-content")
  const calendarDays = document.getElementById("calendar-days")
  const currentMonthElement = document.getElementById("current-month")
  const prevMonthButton = document.getElementById("prev-month")
  const nextMonthButton = document.getElementById("next-month")
  const timeSlots = document.getElementById("time-slots")
  const selectedDateElement = document.getElementById("selected-date")
  const appointmentDate = document.getElementById("appointment-date")
  const appointmentTime = document.getElementById("appointment-time")
  const paymentCards = document.querySelectorAll(".payment-card")
  const profileLink = document.getElementById("profile-link")
  const appointmentsLink = document.getElementById("appointments-link")
  const historyLink = document.getElementById("history-link")

  // State
  let cart = []
  const currentDate = new Date()
  let selectedDate = null
  let selectedTimeSlot = null
  let calendarSettings = {} // Store calendar settings from admin
  let appointmentCounts = {} // Store appointment counts

  // Get active page from localStorage or default to "services"
  const savedActivePage = localStorage.getItem("activePage") || "services"

  // Initialize
  if (calendarDays) {
    fetchCalendarSettings(currentDate)
    setupCalendarRefresh() // Add this line to set up periodic refresh
  }

  // Set active page based on saved preference
  setActivePage(savedActivePage)

  // Event Listeners

  // Notification dropdown
  notificationIcon.addEventListener("click", () => {
    notificationDropdown.style.display = notificationDropdown.style.display === "block" ? "none" : "block"
    profileDropdown.style.display = "none"
  })

  // Profile dropdown
  profileIcon.addEventListener("click", () => {
    profileDropdown.style.display = profileDropdown.style.display === "block" ? "none" : "block"
    notificationDropdown.style.display = "none"
  })

  // Cart sidebar
  cartIcon.addEventListener("click", () => {
    cartSidebar.classList.add("open")
    overlay.style.display = "block"
  })

  closeCart.addEventListener("click", () => {
    cartSidebar.classList.remove("open")
    overlay.style.display = "none"
  })

  overlay.addEventListener("click", () => {
    cartSidebar.classList.remove("open")
    checkoutModal.style.display = "none"
    confirmationModal.style.display = "none"
    overlay.style.display = "none"
  })

  // Navigation
  navItems.forEach((item) => {
    item.addEventListener("click", function () {
      const pageId = this.getAttribute("data-page")
      setActivePage(pageId)
    })
  })

  // Category tabs
  categoryTabs.forEach((tab) => {
    tab.addEventListener("click", function () {
      const category = this.getAttribute("data-category")

      categoryTabs.forEach((categoryTab) => categoryTab.classList.remove("active"))
      categoryContents.forEach((content) => content.classList.remove("active"))

      this.classList.add("active")
      document.getElementById(`${category}-content`).classList.add("active")
    })
  })

  // Add to cart
  addToCartButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const serviceCard = this.closest(".service-card")
      const serviceId = serviceCard.getAttribute("data-id")
      const serviceName = serviceCard.getAttribute("data-name")
      const servicePrice = Number.parseFloat(serviceCard.getAttribute("data-price"))

      addToCart(serviceId, serviceName, servicePrice)
      updateCart()

      // Show cart
      cartSidebar.classList.add("open")
      overlay.style.display = "block"
    })
  })

  // Payment options
  if (depositPayment) {
    depositPayment.addEventListener("change", function () {
      if (this.checked) {
        depositInfo.style.display = "block"
        updateDepositInfo()
      }
    })
  }

  if (fullPayment) {
    fullPayment.addEventListener("change", function () {
      if (this.checked) {
        depositInfo.style.display = "none"
      }
    })
  }

  // Checkout
  if (checkoutBtn) {
    checkoutBtn.addEventListener("click", () => {
      if (cart.length === 0) return

      prepareCheckout()
      cartSidebar.classList.remove("open")
      checkoutModal.style.display = "block"
      overlay.style.display = "block"
    })
  }

  // Close modals
  closeModalButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const modal = this.closest(".modal")
      modal.style.display = "none"
      overlay.style.display = "none"
    })
  })

  // Confirm booking
  if (confirmBooking) {
    confirmBooking.addEventListener("click", () => {
      if (!appointmentDate.value || !appointmentTime.value) {
        alert("Please select a date and time for your appointment")
        return
      }

      checkoutModal.style.display = "none"
      confirmationModal.style.display = "block"

      // Set confirmation details
      document.getElementById("confirmed-date").textContent = formatDate(new Date(appointmentDate.value))
      document.getElementById("confirmed-time").textContent = appointmentTime.value
      document.getElementById("confirmed-services").textContent = cart.map((item) => item.name).join(", ")
      document.getElementById("confirmed-total").textContent = `$${calculateTotal().toFixed(2)}`
      document.getElementById("confirmed-payment").textContent = fullPayment.checked ? "Paid in Full" : "50% Deposit"
    })
  }

  // Close confirmation
  if (closeConfirmation) {
    closeConfirmation.addEventListener("click", () => {
      confirmationModal.style.display = "none"
      overlay.style.display = "none"

      // Reset cart
      cart = []
      updateCart()
    })
  }

  // History tabs
  historyTabs.forEach((tab) => {
    tab.addEventListener("click", function () {
      const tabId = this.getAttribute("data-tab")

      historyTabs.forEach((historyTab) => historyTab.classList.remove("active"))
      historyContents.forEach((content) => content.classList.remove("active"))

      this.classList.add("active")
      document.getElementById(`${tabId}-content`).classList.add("active")
    })
  })

  // Calendar navigation
  if (prevMonthButton) {
    prevMonthButton.addEventListener("click", () => {
      currentDate.setMonth(currentDate.getMonth() - 1)
      fetchCalendarSettings(currentDate)
    })
  }

  if (nextMonthButton) {
    nextMonthButton.addEventListener("click", () => {
      currentDate.setMonth(currentDate.getMonth() + 1)
      fetchCalendarSettings(currentDate)
    })
  }

  // Payment cards
  paymentCards.forEach((card) => {
    card.addEventListener("click", function () {
      paymentCards.forEach((c) => c.classList.remove("selected"))
      this.classList.add("selected")
    })
  })

  // Profile links
  if (profileLink) {
    profileLink.addEventListener("click", (e) => {
      e.preventDefault()
      setActivePage("profile")
      profileDropdown.style.display = "none"
    })
  }

  if (appointmentsLink) {
    appointmentsLink.addEventListener("click", (e) => {
      e.preventDefault()
      setActivePage("appointments")
      profileDropdown.style.display = "none"
    })
  }

  if (historyLink) {
    historyLink.addEventListener("click", (e) => {
      e.preventDefault()
      setActivePage("history")
      profileDropdown.style.display = "none"
    })
  }

  // Functions

  // Fetch calendar settings from the server
  function fetchCalendarSettings(date) {
    const year = date.getFullYear()
    const month = date.getMonth() + 1 // JavaScript months are 0-based

    // Show loading indicator if needed
    if (calendarDays) {
      calendarDays.innerHTML = '<div class="loading-indicator">Loading calendar...</div>'
    }

    fetch(`api/calendar_settings.php?month=${month}&year=${year}`)
      .then((response) => {
        if (!response.ok) {
          throw new Error("Network response was not ok")
        }
        return response.json()
      })
      .then((data) => {
        calendarSettings = data.calendar_settings || {}
        appointmentCounts = data.appointments || {}

        // Log the data for debugging
        console.log("Calendar settings loaded:", calendarSettings)

        // Generate calendar with the fetched data
        generateCalendar(date)
      })
      .catch((error) => {
        console.error("Error fetching calendar settings:", error)

        // Show error message in calendar
        if (calendarDays) {
          calendarDays.innerHTML = '<div class="error-message">Failed to load calendar data. Please try again.</div>'
        }

        // Generate calendar anyway, but without admin settings
        generateCalendar(date)
      })
  }

  // Add item to cart
  function addToCart(id, name, price) {
    const existingItem = cart.find((item) => item.id === id)

    if (existingItem) {
      existingItem.quantity++
    } else {
      cart.push({
        id: id,
        name: name,
        price: price,
        quantity: 1,
      })
    }
  }

  // Update cart display
  function updateCart() {
    if (!cartCount || !cartItems) return

    // Update cart count
    cartCount.textContent = cart.reduce((total, item) => total + item.quantity, 0)

    // Clear cart items
    cartItems.innerHTML = ""

    if (cart.length === 0) {
      cartItems.innerHTML = '<div class="empty-cart-message">Your cart is empty</div>'
      cartSubtotal.textContent = "$0.00"
      cartTax.textContent = "$0.00"
      cartTotal.textContent = "$0.00"
      depositAmount.textContent = "$0.00"
      balanceDue.textContent = "$0.00"
      return
    }

    // Add items to cart
    cart.forEach((item) => {
      const cartItem = document.createElement("div")
      cartItem.classList.add("cart-item")

      cartItem.innerHTML = `
                  <div class="cart-item-details">
                      <div class="cart-item-name">${item.name}</div>
                      <div class="cart-item-price">$${item.price.toFixed(2)}</div>
                  </div>
                  <div class="cart-item-quantity">
                      <button class="quantity-btn minus" data-id="${item.id}">-</button>
                      <span>${item.quantity}</span>
                      <button class="quantity-btn plus" data-id="${item.id}">+</button>
                      <span class="cart-item-remove" data-id="${item.id}"><i class="fas fa-trash"></i></span>
                  </div>
              `

      cartItems.appendChild(cartItem)
    })

    // Add event listeners to quantity buttons
    document.querySelectorAll(".quantity-btn.minus").forEach((button) => {
      button.addEventListener("click", function () {
        const id = this.getAttribute("data-id")
        decreaseQuantity(id)
        updateCart()
        updateDepositInfo()
      })
    })

    document.querySelectorAll(".quantity-btn.plus").forEach((button) => {
      button.addEventListener("click", function () {
        const id = this.getAttribute("data-id")
        increaseQuantity(id)
        updateCart()
        updateDepositInfo()
      })
    })

    document.querySelectorAll(".cart-item-remove").forEach((button) => {
      button.addEventListener("click", function () {
        const id = this.getAttribute("data-id")
        removeFromCart(id)
        updateCart()
        updateDepositInfo()
      })
    })

    // Update totals
    const subtotal = calculateSubtotal()
    const tax = subtotal * 0.08
    const total = subtotal + tax

    cartSubtotal.textContent = `$${subtotal.toFixed(2)}`
    cartTax.textContent = `$${tax.toFixed(2)}`
    cartTotal.textContent = `$${total.toFixed(2)}`

    updateDepositInfo()
  }

  // Calculate subtotal
  function calculateSubtotal() {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0)
  }

  // Calculate total
  function calculateTotal() {
    const subtotal = calculateSubtotal()
    const tax = subtotal * 0.08
    return subtotal + tax
  }

  // Update deposit info
  function updateDepositInfo() {
    if (!depositAmount || !balanceDue) return

    const total = calculateTotal()
    const deposit = total * 0.5

    depositAmount.textContent = `$${deposit.toFixed(2)}`
    balanceDue.textContent = `$${deposit.toFixed(2)}`
  }

  // Increase item quantity
  function increaseQuantity(id) {
    const item = cart.find((item) => item.id === id)
    if (item) {
      item.quantity++
    }
  }

  // Decrease item quantity
  function decreaseQuantity(id) {
    const item = cart.find((item) => item.id === id)
    if (item) {
      item.quantity--
      if (item.quantity === 0) {
        removeFromCart(id)
      }
    }
  }

  // Remove item from cart
  function removeFromCart(id) {
    cart = cart.filter((item) => item.id !== id)
  }

  // Prepare checkout
  function prepareCheckout() {
    const checkoutItems = document.getElementById("checkout-items")
    if (!checkoutItems) return

    checkoutItems.innerHTML = ""

    cart.forEach((item) => {
      const checkoutItem = document.createElement("div")
      checkoutItem.classList.add("checkout-item")

      checkoutItem.innerHTML = `
                  <div class="checkout-item-name">${item.name} x${item.quantity}</div>
                  <div class="checkout-item-price">$${(item.price * item.quantity).toFixed(2)}</div>
              `

      checkoutItems.appendChild(checkoutItem)
    })

    const subtotal = calculateSubtotal()
    const tax = subtotal * 0.08
    const total = subtotal + tax

    document.getElementById("checkout-subtotal").textContent = `$${subtotal.toFixed(2)}`
    document.getElementById("checkout-tax").textContent = `$${tax.toFixed(2)}`
    document.getElementById("checkout-total").textContent = `$${total.toFixed(2)}`

    const checkoutDepositInfo = document.getElementById("checkout-deposit-info")

    if (depositPayment.checked) {
      checkoutDepositInfo.classList.remove("hidden")
      const deposit = total * 0.5
      document.getElementById("checkout-deposit").textContent = `$${deposit.toFixed(2)}`
      document.getElementById("checkout-balance").textContent = `$${deposit.toFixed(2)}`
    } else {
      checkoutDepositInfo.classList.add("hidden")
    }

    // Set min date for appointment
    const today = new Date()
    const yyyy = today.getFullYear()
    const mm = String(today.getMonth() + 1).padStart(2, "0")
    const dd = String(today.getDate()).padStart(2, "0")
    appointmentDate.min = `${yyyy}-${mm}-${dd}`

    // Reset appointment time
    appointmentTime.innerHTML = '<option value="">Select a date first</option>'

    // Add event listener to appointment date
    appointmentDate.addEventListener("change", function () {
      if (this.value) {
        generateTimeSlots(new Date(this.value))
      }
    })
  }

  // Generate calendar
  function generateCalendar(date) {
    if (!calendarDays || !currentMonthElement) return

    const year = date.getFullYear()
    const month = date.getMonth()

    // Set current month text
    currentMonthElement.textContent = `${date.toLocaleString("default", { month: "long" })} ${year}`

    // Clear calendar days
    calendarDays.innerHTML = ""

    // Get first day of month
    const firstDay = new Date(year, month, 1)
    const lastDay = new Date(year, month + 1, 0)

    // Get day of week for first day (0 = Sunday, 6 = Saturday)
    const firstDayIndex = firstDay.getDay()

    // Get number of days in month
    const daysInMonth = lastDay.getDate()

    // Get number of days in previous month
    const prevLastDay = new Date(year, month, 0).getDate()

    // Get today's date
    const today = new Date()

    // Add days from previous month
    for (let i = firstDayIndex; i > 0; i--) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("calendar-day", "other-month")
      dayElement.textContent = prevLastDay - i + 1
      calendarDays.appendChild(dayElement)
    }

    // Add days for current month
    for (let i = 1; i <= daysInMonth; i++) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("calendar-day")
      dayElement.textContent = i

      // Format date string for comparison with calendar settings
      const dateStr = `${year}-${String(month + 1).padStart(2, "0")}-${String(i).padStart(2, "0")}`

      // Check if day is today
      if (year === today.getFullYear() && month === today.getMonth() && i === today.getDate()) {
        dayElement.classList.add("today")
      }

      // Check if day is in the past
      const currentDate = new Date(year, month, i)
      if (currentDate < new Date(today.getFullYear(), today.getMonth(), today.getDate())) {
        dayElement.classList.add("unavailable")
      }
      // Check if day has admin settings
      else if (calendarSettings[dateStr]) {
        const status = calendarSettings[dateStr].status

        if (status === "day-off") {
          dayElement.classList.add("unavailable", "day-off")
          dayElement.setAttribute("title", "Day Off")
        } else if (status === "full") {
          dayElement.classList.add("unavailable", "full-sched")
          dayElement.setAttribute("title", "Fully Booked")
        } else if (status === "salon") {
          // For salon service days
          dayElement.classList.add("available", "salon-service")
          dayElement.setAttribute("title", "Salon Service Only")
          dayElement.setAttribute("data-service-type", status)

          dayElement.addEventListener("click", function () {
            // Remove selected class from all days
            document.querySelectorAll(".calendar-day").forEach((day) => {
              day.classList.remove("selected")
            })

            // Add selected class to clicked day
            this.classList.add("selected")

            // Set selected date
            selectedDate = new Date(year, month, i)

            // Generate time slots
            generateTimeSlots(selectedDate, this.getAttribute("data-service-type"))
          })
        } else if (status === "home") {
          // For home service days
          dayElement.classList.add("available", "home-service")
          dayElement.setAttribute("title", "Home Service Only")
          dayElement.setAttribute("data-service-type", status)

          dayElement.addEventListener("click", function () {
            // Remove selected class from all days
            document.querySelectorAll(".calendar-day").forEach((day) => {
              day.classList.remove("selected")
            })

            // Add selected class to clicked day
            this.classList.add("selected")

            // Set selected date
            selectedDate = new Date(year, month, i)

            // Generate time slots
            generateTimeSlots(selectedDate, this.getAttribute("data-service-type"))
          })
        }
      }
      // Check if it's Sunday (day 0) and not explicitly set as available
      else if (currentDate.getDay() === 0) {
        dayElement.classList.add("unavailable")
        dayElement.setAttribute("title", "Day Off (Sunday)")
      }
      // Otherwise, it's available
      else {
        dayElement.classList.add("available")

        dayElement.addEventListener("click", function () {
          // Remove selected class from all days
          document.querySelectorAll(".calendar-day").forEach((day) => {
            day.classList.remove("selected")
          })

          // Add selected class to clicked day
          this.classList.add("selected")

          // Set selected date
          selectedDate = new Date(year, month, i)

          // Generate time slots
          generateTimeSlots(selectedDate)
        })
      }

      // Add appointment count indicator if there are appointments
      if (appointmentCounts[dateStr] && appointmentCounts[dateStr] > 0) {
        const countBadge = document.createElement("span")
        countBadge.classList.add("appointment-count")
        countBadge.textContent = appointmentCounts[dateStr]
        dayElement.appendChild(countBadge)
      }

      calendarDays.appendChild(dayElement)
    }

    // Add days from next month
    const daysAfterMonth = 42 - (firstDayIndex + daysInMonth)
    for (let i = 1; i <= daysAfterMonth; i++) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("calendar-day", "other-month")
      dayElement.textContent = i
      calendarDays.appendChild(dayElement)
    }
  }

  // Generate time slots
  // Update the generateTimeSlots function to respect admin settings

  function generateTimeSlots(date, serviceType) {
    if (!timeSlots || !selectedDateElement) return

    // Format date for display
    selectedDateElement.textContent = formatDate(date)

    // Clear time slots
    timeSlots.innerHTML = ""

    // Format date string for comparison with calendar settings
    const dateStr = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`

    // Check if this date has specific settings
    const dateSettings = calendarSettings[dateStr]

    // Add a note about service type if applicable
    if (serviceType) {
      const serviceNote = document.createElement("div")
      serviceNote.classList.add("service-type-note")
      serviceNote.textContent =
        serviceType === "salon"
          ? "Note: This day is for salon services only."
          : "Note: This day is for home services only."
      timeSlots.appendChild(serviceNote)
    }

    // If it's a day off or fully booked, show message
    if (dateSettings && (dateSettings.status === "day-off" || dateSettings.status === "full")) {
      const unavailableMessage = document.createElement("div")
      unavailableMessage.classList.add("unavailable-message")
      unavailableMessage.textContent =
        dateSettings.status === "day-off" ? "This day is not available for bookings." : "This day is fully booked."

      // Add notes from admin if available
      if (dateSettings.notes) {
        const notesElement = document.createElement("div")
        notesElement.classList.add("admin-notes")
        notesElement.textContent = `Note from salon: ${dateSettings.notes}`
        unavailableMessage.appendChild(notesElement)
      }

      timeSlots.appendChild(unavailableMessage)
      return
    }

    // Generate time slots from 9 AM to 5 PM
    const startHour = 9
    const endHour = 17

    // Get day of week (0 = Sunday, 6 = Saturday)
    const dayOfWeek = date.getDay()

    for (let hour = startHour; hour <= endHour; hour++) {
      for (let minute = 0; minute < 60; minute += 30) {
        if (hour === endHour && minute > 0) continue

        const timeSlot = document.createElement("div")
        timeSlot.classList.add("time-slot")

        const hourFormatted = hour % 12 === 0 ? 12 : hour % 12
        const amPm = hour < 12 ? "AM" : "PM"
        const minuteFormatted = minute === 0 ? "00" : minute

        const timeString = `${hourFormatted}:${minuteFormatted} ${amPm}`
        timeSlot.textContent = timeString

        // Randomly mark some time slots as unavailable (for demo purposes)
        // In a real app, you would check against booked appointments in the database
        if (Math.random() < 0.3) {
          timeSlot.classList.add("unavailable")
        } else {
          timeSlot.addEventListener("click", function () {
            // Remove selected class from all time slots
            document.querySelectorAll(".time-slot").forEach((slot) => {
              slot.classList.remove("selected")
            })

            // Add selected class to clicked time slot
            this.classList.add("selected")

            // Set selected time slot
            selectedTimeSlot = timeString

            // Update appointment time in checkout
            updateAppointmentTime(date, timeString)
          })
        }

        timeSlots.appendChild(timeSlot)
      }
    }

    // Also update the appointment date in checkout
    if (appointmentDate) {
      const yyyy = date.getFullYear()
      const mm = String(date.getMonth() + 1).padStart(2, "0")
      const dd = String(date.getDate()).padStart(2, "0")
      appointmentDate.value = `${yyyy}-${mm}-${dd}`

      // Generate time slots for checkout
      generateCheckoutTimeSlots(date, serviceType)
    }
  }

  // Generate time slots for checkout
  function generateCheckoutTimeSlots(date, serviceType) {
    if (!appointmentTime) return

    // Clear time slots
    appointmentTime.innerHTML = ""

    // Generate time slots from 9 AM to 5 PM
    const startHour = 9
    const endHour = 17

    // Add default option
    const defaultOption = document.createElement("option")
    defaultOption.value = ""
    defaultOption.textContent = "Select a time"
    appointmentTime.appendChild(defaultOption)

    // Format date string for comparison with calendar settings
    const dateStr = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`

    // Check if this date has specific settings
    const dateSettings = calendarSettings[dateStr]

    // If it's a day off or fully booked, don't add time slots
    if (dateSettings && (dateSettings.status === "day-off" || dateSettings.status === "full")) {
      return
    }

    for (let hour = startHour; hour <= endHour; hour++) {
      for (let minute = 0; minute < 60; minute += 30) {
        if (hour === endHour && minute > 0) continue

        const hourFormatted = hour % 12 === 0 ? 12 : hour % 12
        const amPm = hour < 12 ? "AM" : "PM"
        const minuteFormatted = minute === 0 ? "00" : minute

        const timeString = `${hourFormatted}:${minuteFormatted} ${amPm}`

        // Randomly mark some time slots as unavailable (for demo purposes)
        // In a real app, you would check against booked appointments in the database
        if (Math.random() < 0.3) continue

        const option = document.createElement("option")
        option.value = timeString
        option.textContent = timeString

        appointmentTime.appendChild(option)
      }
    }
  }

  // Update appointment time in checkout
  function updateAppointmentTime(date, timeString) {
    if (appointmentDate && appointmentTime) {
      const yyyy = date.getFullYear()
      const mm = String(date.getMonth() + 1).padStart(2, "0")
      const dd = String(date.getDate()).padStart(2, "0")
      appointmentDate.value = `${yyyy}-${mm}-${dd}`

      // Find or create option for time
      let option = Array.from(appointmentTime.options).find((opt) => opt.value === timeString)

      if (!option) {
        option = document.createElement("option")
        option.value = timeString
        option.textContent = timeString
        appointmentTime.appendChild(option)
      }

      appointmentTime.value = timeString
    }
  }

  // Format date for display
  function formatDate(date) {
    const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" }
    return date.toLocaleDateString("en-US", options)
  }

  // Close dropdowns when clicking outside
  document.addEventListener("click", (e) => {
    if (
      notificationIcon &&
      notificationDropdown &&
      !notificationIcon.contains(e.target) &&
      !notificationDropdown.contains(e.target)
    ) {
      notificationDropdown.style.display = "none"
    }

    if (profileIcon && profileDropdown && !profileIcon.contains(e.target) && !profileDropdown.contains(e.target)) {
      profileDropdown.style.display = "none"
    }
  })

  // Function to set active page
  function setActivePage(pageId) {
    // Skip if elements don't exist
    if (!document.querySelector(`[data-page="${pageId}"]`) || !document.getElementById(`${pageId}-page`)) {
      return
    }

    // Remove active class from all nav items and pages
    navItems.forEach((navItem) => navItem.classList.remove("active"))
    pages.forEach((page) => page.classList.remove("active"))

    // Add active class to selected nav item and page
    document.querySelector(`[data-page="${pageId}"]`).classList.add("active")
    document.getElementById(`${pageId}-page`).classList.add("active")

    // Save active page to localStorage
    localStorage.setItem("activePage", pageId)
  }

  // Add a function to refresh calendar data periodically
  function setupCalendarRefresh() {
    // Refresh calendar data every 5 minutes
    setInterval(
      () => {
        if (calendarDays && currentDate) {
          fetchCalendarSettings(currentDate)
        }
      },
      5 * 60 * 1000,
    ) // 5 minutes in milliseconds
  }
})

// Add this to your existing script.js file

document.addEventListener("DOMContentLoaded", () => {
  // Handle add to cart events
  document.addEventListener("addToCart", (e) => {
    const item = e.detail

    // Get current cart from localStorage or initialize empty array
    const cart = JSON.parse(localStorage.getItem("salonCart")) || []

    // Check if item already exists in cart
    const existingItemIndex = cart.findIndex((cartItem) => cartItem.id === item.id)

    if (existingItemIndex > -1) {
      // Update quantity if item exists
      cart[existingItemIndex].quantity += item.quantity
    } else {
      // Add new item to cart
      cart.push(item)
    }

    // Save updated cart to localStorage
    localStorage.setItem("salonCart", JSON.stringify(cart))

    // Update cart UI
    updateCartUI()

    // Show cart notification
    const cartCount = document.querySelector(".cart-count")
    if (cartCount) {
      cartCount.textContent = cart.length
      cartCount.classList.add("bounce")
      setTimeout(() => {
        cartCount.classList.remove("bounce")
      }, 300)
    }
  })

  // Function to update cart UI
  function updateCartUI() {
    const cart = JSON.parse(localStorage.getItem("salonCart")) || []
    const cartItemsContainer = document.querySelector(".cart-items")
    const cartTotal = document.querySelector(".cart-total-amount")

    if (cartItemsContainer) {
      // Clear current cart items
      cartItemsContainer.innerHTML = ""

      if (cart.length === 0) {
        cartItemsContainer.innerHTML = '<div class="empty-cart">Your cart is empty</div>'
        if (cartTotal) cartTotal.textContent = "₱0.00"
        return
      }

      // Calculate total
      let total = 0

      // Add each item to cart UI
      cart.forEach((item, index) => {
        const itemTotal = item.price * item.quantity
        total += itemTotal

        const cartItemElement = document.createElement("div")
        cartItemElement.className = "cart-item"
        cartItemElement.innerHTML = `
                    <div class="cart-item-details">
                        <h4>${item.name}</h4>
                        <div class="cart-item-price">₱${Number.parseFloat(item.price).toFixed(2)}</div>
                    </div>
                    <div class="cart-item-actions">
                        <button class="quantity-btn minus" data-index="${index}">-</button>
                        <span class="quantity">${item.quantity}</span>
                        <button class="quantity-btn plus" data-index="${index}">+</button>
                        <button class="remove-btn" data-index="${index}">×</div>
                    </div>
                `

        cartItemsContainer.appendChild(cartItemElement)
      })

      // Update total
      if (cartTotal) cartTotal.textContent = `₱${total.toFixed(2)}`

      // Add event listeners to quantity buttons
      document.querySelectorAll(".quantity-btn.minus").forEach((btn) => {
        btn.addEventListener("click", function () {
          const index = Number.parseInt(this.getAttribute("data-index"))
          decreaseQuantity(index)
        })
      })

      document.querySelectorAll(".quantity-btn.plus").forEach((btn) => {
        btn.addEventListener("click", function () {
          const index = Number.parseInt(this.getAttribute("data-index"))
          increaseQuantity(index)
        })
      })

      document.querySelectorAll(".remove-btn").forEach((btn) => {
        btn.addEventListener("click", function () {
          const index = Number.parseInt(this.getAttribute("data-index"))
          removeItem(index)
        })
      })
    }
  }

  // Function to decrease item quantity
  function decreaseQuantity(index) {
    const cart = JSON.parse(localStorage.getItem("salonCart")) || []

    if (cart[index].quantity > 1) {
      cart[index].quantity -= 1
      localStorage.setItem("salonCart", JSON.stringify(cart))
      updateCartUI()
    } else {
      removeItem(index)
    }
  }

  // Function to increase item quantity
  function increaseQuantity(index) {
    const cart = JSON.parse(localStorage.getItem("salonCart")) || []

    cart[index].quantity += 1
    localStorage.setItem("salonCart", JSON.stringify(cart))
    updateCartUI()
  }

  // Function to remove item from cart
  function removeItem(index) {
    const cart = JSON.parse(localStorage.getItem("salonCart")) || []

    cart.splice(index, 1)
    localStorage.setItem("salonCart", JSON.stringify(cart))

    // Update cart count
    const cartCount = document.querySelector(".cart-count")
    if (cartCount) {
      cartCount.textContent = cart.length
    }

    updateCartUI()
  }

  // Initialize cart UI on page load
  updateCartUI()
})
