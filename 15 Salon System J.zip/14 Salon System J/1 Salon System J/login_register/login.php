<?php 
date_default_timezone_set('Asia/Manila');
include('header1.php');

// Include the consolidated database connection
include "tools/salondb.php";
$dbConnection = getDatabaseConnection();

$email = $_GET['email'] ?? ''; // Autofill if redirected
$password = "";
$email_error = $password_error = "";
$error = false;

// Unified login processing for both customers and admins
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $email_error = "Invalid email format";
        $error = true;
    }

    if (empty($password)) {
        $password_error = "Password is required";
        $error = true;
    }

    if (!$error) {
        // Query to get user data including role
        $statement = $dbConnection->prepare("SELECT id, first_name, last_name, email, password, role, status FROM users WHERE email = ?");
        $statement->bind_param("s", $email);
        $statement->execute();
        $statement->store_result();

        if ($statement->num_rows == 1) {
            $statement->bind_result($user_id, $first_name, $last_name, $user_email, $hashed_password, $role, $status);
            $statement->fetch();

            // Check if account is active
            if ($status !== 'active') {
                $email_error = "Your account is inactive. Please contact support.";
            } else if (password_verify($password, $hashed_password)) {
                // Set common session variables
                $_SESSION['email'] = $user_email;
                $_SESSION['user_id'] = $user_id;
                $_SESSION['name'] = $first_name . ' ' . $last_name;
                $_SESSION['role'] = $role;
                
                // Redirect based on role
                if ($role === 'admin') {
                    // Set admin-specific session variables for backward compatibility
                    $_SESSION['admin_logged_in'] = true;
                    $_SESSION['admin_username'] = $first_name . ' ' . $last_name;
                    $_SESSION['admin_id'] = $user_id;
                    
                    // Redirect to admin dashboard
                    header("Location: ../admin/dashboard.php");
                    exit;
                } else {
                    // Redirect to customer page for 'client' or 'user' roles
                    header("Location: ../user/customer.php");
                    exit;
                }
            } else {
                $password_error = "Incorrect password";
            }
        } else {
            $email_error = "Email not found";
        }

        $statement->close();
    }
}
?>

<link rel="stylesheet" href="/CSS/login.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">


<!-- Unified Login Form -->
<div class="container">
    <div class="form-container single-form">
        <h2 class="form-title">Login</h2>
        <p class="form-subtitle">Welcome back! Please sign in to your account.</p>
        <hr class=horizontal-line></hr>

        <form method="post">
            <div class="form-row">
                <label class="form-label">Email</label>
                <div class="form-input-container">
                    <input class="form-input" name="email" type="email" value="<?= htmlspecialchars($email); ?>" placeholder="Enter your email address">
                    <span class="error-text"><?= $email_error ?></span>
                </div>
            </div>
            
            <div class="form-row">
                <label class="form-label">Password</label>
                    <div class="form-input-container">
                        <input id="password" class="form-input" name="password" type="password" placeholder="Enter your password">
                        <i class="fa-solid fa-eye-slash toggle-password" onclick="togglePassword()"></i>
                        <span class="error-text"><?= $password_error ?></span>
                    </div>
            </div>

            
            <div class="form-row button-row">
                <button type="submit" name="login" class="submit-btn">Login</button>
                <a href="/login_register/index.php" class="cancel-btn">Cancel</a>
            </div>
        </form>

        <p class="register-link">Don't have an account? <a href="register.php">Register here</a></p>
    </div>
</div>

<script>
  function togglePassword() {
    const passwordInput = document.getElementById("password");
    const toggleIcon = document.querySelector(".toggle-password");

    if (passwordInput.type === "password") {
      // Show password
      passwordInput.type = "text";
      toggleIcon.classList.remove("fa-eye-slash");
      toggleIcon.classList.add("fa-eye");
    } else {
      // Hide password
      passwordInput.type = "password";
      toggleIcon.classList.remove("fa-eye");
      toggleIcon.classList.add("fa-eye-slash");
    }
  }
</script>



<?php include('footer1.php'); ?>
