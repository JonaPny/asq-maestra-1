<?php
// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION["email"])) {
    header("location: /login_register/login.php");
    exit;
}

// Include database connection
include "../login_register/tools/salondb.php";
$dbConnection = getDatabaseConnection();

// Get user data
$user_id = $_SESSION['user_id'];
$statement = $dbConnection->prepare("SELECT first_name, last_name, email, phone, address FROM users WHERE id = ?");
$statement->bind_param("i", $user_id);
$statement->execute();
$statement->store_result();

if ($statement->num_rows == 1) {
    $statement->bind_result($first_name, $last_name, $email, $phone, $address);
    $statement->fetch();
} else {
    // If user not found, redirect to login
    header("Location: /login_register/login.php");
    exit;
}

$statement->close();

// Handle profile update
$updateMessage = "";
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {
    $new_first_name = $_POST['first_name'];
    $new_last_name = $_POST['last_name'];
    $new_phone = $_POST['phone'];
    $new_address = $_POST['address'];
    $new_preferences = $_POST['preferences'];
    
    // Update user data in database
    $updateStmt = $dbConnection->prepare("UPDATE users SET first_name = ?, last_name = ?, phone = ?, address = ? WHERE id = ?");
    $updateStmt->bind_param("ssssi", $new_first_name, $new_last_name, $new_phone, $new_address, $user_id);
    
    if ($updateStmt->execute()) {
        // Update session variables
        $_SESSION['first_name'] = $new_first_name;
        $_SESSION['last_name'] = $new_last_name;
        $_SESSION['phone'] = $new_phone;
        $_SESSION['address'] = $new_address;
        
        $first_name = $new_first_name;
        $last_name = $new_last_name;
        $phone = $new_phone;
        $address = $new_address;
        
        $updateMessage = "<div class='alert-success'>Profile updated successfully!</div>";
    } else {
        $updateMessage = "<div class='alert-error'>Error updating profile: " . $dbConnection->error . "</div>";
    }
    
    $updateStmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>A.S.Q - Customer Panel</title>
    <link rel="stylesheet" href="assets/css/customer.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body>
    <div class="app-container">
        <?php include 'components/header.php'; ?>

        <!-- Main Content -->
        <main>
            <?php include 'components/sidebar.php'; ?>

            <!-- Content Area -->
            <div class="content">
                <?php include 'components/services.php'; ?>
                <?php include 'components/appointments.php'; ?>
                <?php include 'components/profile.php'; ?>
                <?php include 'components/history.php'; ?>
            </div>
        </main>

        <?php include 'components/cart.php'; ?>
        <?php include 'components/modals.php'; ?>
    </div>

    <script src="assets/js/script.js"></script>
</body>

</html>
