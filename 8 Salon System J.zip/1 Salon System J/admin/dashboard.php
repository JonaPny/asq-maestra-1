<?php
$page_title = "Dashboard - Salon Admin";
include 'components/header.php';
include 'components/sidebar.php';
include 'components/navbar.php';

// Include database connection
include '../login_register/tools/salondb.php';
$conn = getAdminDatabaseConnection();

// Check if the database tables exist, if not create them
$result = $conn->query("SHOW TABLES LIKE 'calendar_settings'");
if ($result->num_rows == 0) {
    include 'includes/create_tables.php';
}

// Get current month and year
$month = isset($_GET['month']) ? intval($_GET['month']) : date('n');
$year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        // Update day status
        if ($_POST['action'] === 'update_day') {
            $date = $_POST['date'];
            $status = $_POST['status'];
            $notes = $_POST['notes'];
            
            // If status is 'default', delete any existing record for this date
            if ($status === 'default') {
                $stmt = $conn->prepare("DELETE FROM calendar_settings WHERE date = ?");
                $stmt->bind_param("s", $date);
                $success = $stmt->execute();
                $error_message = $stmt->error;
                $stmt->close();
            } else {
                // Check if a record already exists for this date
                $check_stmt = $conn->prepare("SELECT id FROM calendar_settings WHERE date = ?");
                $check_stmt->bind_param("s", $date);
                $check_stmt->execute();
                $check_result = $check_stmt->get_result();
                
                if ($check_result->num_rows > 0) {
                    // Update existing record
                    $row = $check_result->fetch_assoc();
                    $id = $row['id'];
                    $stmt = $conn->prepare("UPDATE calendar_settings SET status = ?, notes = ? WHERE id = ?");
                    $stmt->bind_param("ssi", $status, $notes, $id);
                } else {
                    // Insert new record
                    $stmt = $conn->prepare("INSERT INTO calendar_settings (date, status, notes) VALUES (?, ?, ?)");
                    $stmt->bind_param("sss", $date, $status, $notes);
                }
                
                $success = $stmt->execute();
                $error_message = $stmt->error;
                $stmt->close();
                $check_stmt->close();
            }
            
            // If it's an AJAX request, return JSON response
            if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
                header('Content-Type: application/json');
                if ($success) {
                    echo json_encode(['success' => true, 'message' => "Day status updated successfully!"]);
                } else {
                    echo json_encode(['success' => false, 'message' => "Error updating day status: " . $error_message]);
                }
                exit;
            } else if ($success) {
                $success_message = "Day status updated successfully!";
            } else {
                $error_message = "Error updating day status: " . $error_message;
            }
        }
    }
}

// Get calendar settings for the month
$calendar_settings = [];
$first_day = sprintf('%04d-%02d-01', $year, $month);
$last_day = date('Y-m-t', strtotime($first_day));

$stmt = $conn->prepare("SELECT date, status, notes FROM calendar_settings WHERE date BETWEEN ? AND ?");
$stmt->bind_param("ss", $first_day, $last_day);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $calendar_settings[$row['date']] = [
        'status' => $row['status'],
        'notes' => $row['notes']
    ];
}
$stmt->close();

// Get appointment counts for the month
$appointments = [];
$stmt = $conn->prepare("SELECT appointment_date, COUNT(*) as count, service_type FROM appointments WHERE appointment_date BETWEEN ? AND ? GROUP BY appointment_date, service_type");
$stmt->bind_param("ss", $first_day, $last_day);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $date = $row['appointment_date'];
    
    if (!isset($appointments[$date])) {
        $appointments[$date] = [
            'count' => 0,
            'type' => ''
        ];
    }
    
    $appointments[$date]['count'] += $row['count'];
    
    // Determine type based on majority
    if ($row['service_type'] === 'home') {
        $appointments[$date]['type'] = 'home-service';
    } else {
        $appointments[$date]['type'] = 'salon-service';
    }
}
$stmt->close();

// Month names for display
$month_names = [
    1 => "JANUARY", 2 => "FEBRUARY", 3 => "MARCH", 4 => "APRIL",
    5 => "MAY", 6 => "JUNE", 7 => "JULY", 8 => "AUGUST",
    9 => "SEPTEMBER", 10 => "OCTOBER", 11 => "NOVEMBER", 12 => "DECEMBER"
];

// Get today's date for highlighting
$today_date = date('Y-m-d');
?>

<div class="p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-uppercase" id="current-month"><?php echo $month_names[$month] . " " . $year; ?></h2>
        <div class="d-flex align-items-center">
            <a href="?month=<?php echo $month == 1 ? 12 : $month - 1; ?>&year=<?php echo $month == 1 ? $year - 1 : $year; ?>" class="btn btn-sm btn-outline-secondary me-2" id="prev-month">
                <i class="bi bi-chevron-left"></i>
            </a>
            <a href="?month=<?php echo date('n'); ?>&year=<?php echo date('Y'); ?>" class="btn btn-sm btn-outline-secondary me-2" id="today-btn">Today</a>
            <a href="?month=<?php echo $month == 12 ? 1 : $month + 1; ?>&year=<?php echo $month == 12 ? $year + 1 : $year; ?>" class="btn btn-sm btn-outline-secondary me-3" id="next-month">
                <i class="bi bi-chevron-right"></i>
            </a>
            <div class="form-check form-switch me-3">
                <input class="form-check-input" type="checkbox" id="edit-mode">
                <label class="form-check-label" for="edit-mode">Edit Mode</label>
            </div>
        </div>
    </div>

    <div class="alert alert-success d-none" id="calendar-message"></div>

    <div class="calendar-legend mb-3">
        <div class="d-flex align-items-center">
            <div class="legend-item me-3">
                <span class="legend-color day-off"></span>
                <span>DAY OFF</span>
            </div>
            <div class="legend-item me-3">
                <span class="legend-color home-service"></span>
                <span>HOME SERVICE</span>
            </div>
            <div class="legend-item me-3">
                <span class="legend-color salon-service"></span>
                <span>SALON SERVICE</span>
            </div>
            <div class="legend-item">
                <span class="legend-color full-sched"></span>
                <span>FULL SCHED</span>
            </div>
        </div>
    </div>

    <div class="calendar-container">
        <table class="table table-bordered calendar-table">
            <thead>
                <tr>
                    <th>Sun</th>
                    <th>Mon</th>
                    <th>Tue</th>
                    <th>Wed</th>
                    <th>Thu</th>
                    <th>Fri</th>
                    <th>Sat</th>
                </tr>
            </thead>
            <tbody id="calendar-body">
                <?php
                // Generate calendar
                $firstDay = new DateTime("$year-$month-01");
                $lastDay = new DateTime($firstDay->format('Y-m-t'));
                $daysInMonth = intval($lastDay->format('d'));
                $startingDay = intval($firstDay->format('w')); // 0 (Sunday) to 6 (Saturday)

                $date = 1;
                for ($i = 0; $i < 6; $i++) {
                    echo "<tr>";
                    
                    for ($j = 0; $j < 7; $j++) {
                        if ($i === 0 && $j < $startingDay) {
                            // Empty cells before the first day
                            echo "<td></td>";
                        } else if ($date > $daysInMonth) {
                            // Empty cells after the last day
                            echo "<td></td>";
                        } else {
                            // Create date cell
                            $dateStr = sprintf('%04d-%02d-%02d', $year, $month, $date);
                            $cellClass = '';
                            
                            // Check if this date has a special status in calendar_settings
                            if (isset($calendar_settings[$dateStr])) {
                                if ($calendar_settings[$dateStr]['status'] === 'full') {
                                    $cellClass = 'full-sched';
                                } else if ($calendar_settings[$dateStr]['status'] === 'salon') {
                                    $cellClass = 'salon-service';
                                } else if ($calendar_settings[$dateStr]['status'] === 'day-off') {
                                    $cellClass = 'day-off';
                                } else if ($calendar_settings[$dateStr]['status'] === 'home') {
                                    $cellClass = 'home-service';
                                }
                            }
                            // Otherwise, check if it has appointments
                            else if (isset($appointments[$dateStr])) {
                                $cellClass = $appointments[$dateStr]['type'];
                            }
                            // If it's Sunday and doesn't have a status yet, mark as day-off
                            else if ($j === 0) {
                                $cellClass = 'day-off';
                            }
                            
                            // Add today class if this is today's date
                            if ($dateStr === $today_date) {
                                $cellClass .= ' today';
                            }
                            
                            // Special case for May 4, 2025 (make it a day off)
                            if ($dateStr === '2025-05-04') {
                                $cellClass = 'day-off';
                            }
                            
                            echo "<td class=\"$cellClass\" data-date=\"$dateStr\" data-day=\"$j\">";
                            echo "<div class=\"calendar-date\">$date</div>";
                            
                            // Add appointment count if any
                            if (isset($appointments[$dateStr]) && $appointments[$dateStr]['count'] > 0) {
                                echo "<span class=\"appointment-count\">{$appointments[$dateStr]['count']}</span>";
                            }
                            
                            echo "</td>";
                            
                            $date++;
                        }
                    }
                    
                    echo "</tr>";
                    
                    // Stop if we've reached the end of the month
                    if ($date > $daysInMonth) {
                        break;
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'components/modals/day_edit_modal.php'; ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Day edit modal
        const dayEditModal = new bootstrap.Modal(document.getElementById('dayEditModal'));
        
        // Calendar cell click event
        document.querySelectorAll('.calendar-table td[data-date]').forEach(cell => {
            cell.addEventListener('click', function () {
                const dateStr = this.getAttribute('data-date');
                
                if (document.getElementById('edit-mode').checked) {
                    openDayEditModal(dateStr);
                } else {
                    viewDayAppointments(dateStr);
                }
            });
        });

        // Update the JavaScript function that handles the day status update (around line 250-290)
        // Add this function to store the original cell class when opening the modal
function openDayEditModal(dateStr) {
    document.getElementById('selected-date').value = dateStr;
    
    // Set current status
    let status = 'default'; // Default to default (no status)
    const cell = document.querySelector(`.calendar-table td[data-date="${dateStr}"]`);
    
    // Store the original cell class for cancellation
    cell.setAttribute('data-original-class', cell.className);

    if (cell.classList.contains('full-sched')) {
        status = 'full';
    } else if (cell.classList.contains('salon-service')) {
        status = 'salon';
    } else if (cell.classList.contains('day-off')) {
        // Check if it's Sunday (day 0)
        const dayOfWeek = parseInt(cell.getAttribute('data-day'));
        if (dayOfWeek !== 0) {
            // Only set as day-off if it's not Sunday (since Sundays are day-off by default)
            status = 'day-off';
        }
    } else if (cell.classList.contains('home-service')) {
        status = 'home';
    }
    
    // Find and check the appropriate radio button
    const radioButton = document.querySelector(`input[name="dayStatus"][value="${status}"]`);
    if (radioButton) {
        radioButton.checked = true;
    }
    
    // Show modal
    dayEditModal.show();
}

// Update the save day status function
document.getElementById('saveDayStatus').addEventListener('click', function () {
    const dateStr = document.getElementById('selected-date').value;
    const status = document.querySelector('input[name="dayStatus"]:checked').value;
    const notes = document.getElementById('dayNotes').value;
    
    // Update the cell appearance immediately
    const cell = document.querySelector(`.calendar-table td[data-date="${dateStr}"]`);
    
    // Remove all status classes but keep the today class if present
    const isToday = cell.classList.contains('today');
    cell.className = isToday ? 'today' : '';
    
    // Add the appropriate class based on the selected status
    if (status === 'default') {
        // For default, just leave it with no class (or just 'today' if it's today)
        // Check if it's Sunday and add day-off class if it is
        const dayOfWeek = parseInt(cell.getAttribute('data-day'));
        if (dayOfWeek === 0) {
            cell.classList.add('day-off');
        }
    } else if (status === 'full') {
        cell.classList.add('full-sched');
    } else if (status === 'salon') {
        cell.classList.add('salon-service');
    } else if (status === 'day-off') {
        cell.classList.add('day-off');
    } else if (status === 'home') {
        cell.classList.add('home-service');
    }
    
    // Create form data for AJAX submission
    const formData = new FormData();
    formData.append('action', 'update_day');
    formData.append('date', dateStr);
    formData.append('status', status);
    formData.append('notes', notes);
    
    // Send AJAX request to update the database
    fetch('dashboard.php', {
        method: 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        // Show success message
        const calendarMessage = document.getElementById('calendar-message');
        calendarMessage.textContent = data.message || "Day status updated successfully!";
        calendarMessage.classList.remove('d-none');
        calendarMessage.classList.remove('alert-danger');
        calendarMessage.classList.add('alert-success');
        
        // Hide the message after 3 seconds
        setTimeout(() => {
            calendarMessage.classList.add('d-none');
        }, 3000);
        
        // Log the status to console for debugging
        console.log('Updated status:', status);
    })
    .catch(error => {
        console.error('Error:', error);
        
        // Show error message in the UI
        const calendarMessage = document.getElementById('calendar-message');
        calendarMessage.textContent = "Error updating day status. Please try again.";
        calendarMessage.classList.remove('d-none');
        calendarMessage.classList.remove('alert-success');
        calendarMessage.classList.add('alert-danger');
        
        // Hide the message after 3 seconds
        setTimeout(() => {
            calendarMessage.classList.add('d-none');
        }, 3000);
    });
    
    // Close the modal
    dayEditModal.hide();
});

// Add cancel button functionality
document.getElementById('cancelDayEdit').addEventListener('click', function() {
    const dateStr = document.getElementById('selected-date').value;
    const cell = document.querySelector(`.calendar-table td[data-date="${dateStr}"]`);
    
    // Restore the original class if it was stored
    if (cell.hasAttribute('data-original-class')) {
        cell.className = cell.getAttribute('data-original-class');
    }
    
    // Close the modal
    dayEditModal.hide();
});
        
        // View day appointments
        function viewDayAppointments(dateStr) {
            window.location.href = `appointments.php?date=${dateStr}`;
        }
    });
</script>

<?php 
// Close the database connection
if ($conn && $conn->ping()) {
    $conn->close();
}
include 'components/footer.php'; ?>
