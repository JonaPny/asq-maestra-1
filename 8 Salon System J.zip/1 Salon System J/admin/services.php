<?php
session_start();

if (isset($_GET['status']) && $_GET['status'] === 'success') {
    $success_message = $_GET['message'] ?? "Operation completed successfully!";
}

$page_title = "Services Manager - Salon Admin";
include 'components/header.php';
include 'components/sidebar.php';
include 'components/navbar.php';

// Include database connection
include '../login_register/tools/salondb.php';
$conn = getDatabaseConnection();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        // Add new service
        if ($_POST['action'] === 'add') {
            $name = $_POST['name'];
            $description = $_POST['description'];
            $price = $_POST['price'];
            $duration = $_POST['duration'];
            $category = $_POST['category'];
            $subcategory = $_POST['subcategory'];
            $status = $_POST['status'];
            
            $stmt = $conn->prepare("INSERT INTO services (name, description, price, duration, category, subcategory, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssdissi", $name, $description, $price, $duration, $category, $subcategory, $status);
            $stmt->execute();
            $stmt->close();
            
            $success_message = "Service added successfully!";
        }
        
        // Update existing service
        else if ($_POST['action'] === 'update') {
            $id = $_POST['id'];
            $name = $_POST['name'];
            $description = $_POST['description'];
            $price = $_POST['price'];
            $duration = $_POST['duration'];
            $category = $_POST['category'];
            $subcategory = $_POST['subcategory'];
            $status = $_POST['status'];
            
            $stmt = $conn->prepare("UPDATE services SET name = ?, description = ?, price = ?, duration = ?, category = ?, subcategory = ?, status = ? WHERE id = ?");
            $stmt->bind_param("ssdissii", $name, $description, $price, $duration, $category, $subcategory, $status, $id);
            $stmt->execute();
            $stmt->close();
            
            $success_message = "Service updated successfully!";
        }
        
        // Delete service
        else if ($_POST['action'] === 'delete') {
            $id = $_POST['id'];
            
            $stmt = $conn->prepare("DELETE FROM services WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();
            
            $success_message = "Service deleted successfully!";
        }
        header("Location: services.php?status=success&message=" . urlencode($success_message));
        exit;
    }
}

// Get all services
$services = [];
$result = $conn->query("SELECT * FROM services ORDER BY category, subcategory, name");
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $services[] = $row;
    }
}
$conn->close();
?>

<div class="p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Services Manager</h2>
        <div>
            <button class="btn btn-sm btn-outline-pink" id="add-service-btn">
                <i class="bi bi-plus-circle me-1"></i> Add New Service
            </button>
        </div>
    </div>

    <?php if (isset($success_message)): ?>
    <div class="alert alert-success" id="service-message"><?php echo $success_message; ?></div>
    <?php else: ?>
    <div class="alert alert-success d-none" id="service-message"></div>
    <?php endif; ?>

    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-pink text-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Service Categories</h5>
                    <div class="btn-group" role="group">
                        <button type="button" class="btn btn-sm btn-outline-light active category-filter" data-category="all">All</button>
                        <button type="button" class="btn btn-sm btn-outline-light category-filter" data-category="haircuts">Haircuts</button>
                        <button type="button" class="btn btn-sm btn-outline-light category-filter" data-category="haircolor">Hair Color</button>
                        <button type="button" class="btn btn-sm btn-outline-light category-filter" data-category="rebonding">Rebonding</button>
                        <button type="button" class="btn btn-sm btn-outline-light category-filter" data-category="treatment">Hair Treatment</button>
                        <button type="button" class="btn btn-sm btn-outline-light category-filter" data-category="braiding">Braiding</button>
                        <button type="button" class="btn btn-sm btn-outline-light category-filter" data-category="nails">Nails</button>
                        <button type="button" class="btn btn-sm btn-outline-light category-filter" data-category="men">For Men</button>
                        <button type="button" class="btn btn-sm btn-outline-light category-filter" data-category="women">For Women</button>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table mb-0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Service Name</th>
                                    <th>Category</th>
                                    <th>Subcategory</th>
                                    <th>Price</th>
                                    <th>Duration</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="services-table">
                                <?php if (count($services) > 0): ?>
                                    <?php foreach ($services as $service): ?>
                                        <tr class="service-row" data-category="<?php echo $service['category']; ?>">
                                            <td><?php echo $service['id']; ?></td>
                                            <td><?php echo $service['name']; ?></td>
                                            <td><?php echo ucfirst($service['category']); ?></td>
                                            <td><?php echo $service['subcategory']; ?></td>
                                            <td>₱<?php echo number_format($service['price'], 2); ?></td>
                                            <td><?php echo $service['duration']; ?> mins</td>
                                            <td>
                                                <span class="badge <?php echo $service['status'] ? 'bg-success' : 'bg-danger'; ?>">
                                                    <?php echo $service['status'] ? 'Active' : 'Inactive'; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-outline-primary me-1 edit-service" 
                                                        data-id="<?php echo $service['id']; ?>"
                                                        data-name="<?php echo htmlspecialchars($service['name']); ?>"
                                                        data-description="<?php echo htmlspecialchars($service['description']); ?>"
                                                        data-price="<?php echo $service['price']; ?>"
                                                        data-duration="<?php echo $service['duration']; ?>"
                                                        data-category="<?php echo $service['category']; ?>"
                                                        data-subcategory="<?php echo htmlspecialchars($service['subcategory']); ?>"
                                                        data-status="<?php echo $service['status']; ?>">
                                                    <i class="bi bi-pencil"></i>
                                                </button>
                                                <button class="btn btn-sm btn-outline-danger delete-service" 
                                                        data-id="<?php echo $service['id']; ?>"
                                                        data-name="<?php echo htmlspecialchars($service['name']); ?>">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr id="no-services-row">
                                        <td colspan="8" class="text-center">No services found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Service Modal -->
<div class="modal fade" id="serviceModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-pink text-white">
                <h5 class="modal-title" id="serviceModalTitle">Add New Service</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="serviceForm" method="post">
                    <input type="hidden" id="serviceId" name="id">
                    <input type="hidden" id="serviceAction" name="action" value="add">
                    
                    <div class="mb-3">
                        <label for="serviceName" class="form-label">Service Name</label>
                        <input type="text" class="form-control" id="serviceName" name="name" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="serviceDescription" class="form-label">Description</label>
                        <textarea class="form-control" id="serviceDescription" name="description" rows="3"></textarea>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="serviceCategory" class="form-label">Category</label>
                            <select class="form-select" id="serviceCategory" name="category" required>
                                <option value="haircuts">Haircuts</option>
                                <option value="haircolor">Hair Color</option>
                                <option value="rebonding">Rebonding</option>
                                <option value="treatment">Hair Treatment</option>
                                <option value="braiding">Braiding Services</option>
                                <option value="nails">Nail Services</option>
                                <option value="men">For Men</option>
                                <option value="women">For Women</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="serviceSubcategory" class="form-label">Subcategory</label>
                            <input type="text" class="form-control" id="serviceSubcategory" name="subcategory" placeholder="e.g. Regular, Premium, etc.">
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="servicePrice" class="form-label">Price (₱)</label>
                            <input type="number" class="form-control" id="servicePrice" name="price" min="0" step="0.01" required>
                        </div>
                        <div class="col-md-6">
                            <label for="serviceDuration" class="form-label">Duration (minutes)</label>
                            <input type="number" class="form-control" id="serviceDuration" name="duration" min="15" step="15" required>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="serviceStatus" class="form-label">Status</label>
                        <select class="form-select" id="serviceStatus" name="status" required>
                            <option value="1">Active</option>
                            <option value="0">Inactive</option>
                        </select>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-pink" id="saveService">Save Service</button>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">Confirm Delete</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete the service: <span id="deleteServiceName"></span>?</p>
                <p class="text-danger">This action cannot be undone.</p>
                <form id="deleteForm" method="post">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" id="deleteServiceId" name="id">
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmDelete">Delete</button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize modals
    const serviceModal = new bootstrap.Modal(document.getElementById('serviceModal'));
    const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
    
    // Add New Service button
    document.getElementById('add-service-btn').addEventListener('click', function() {
        document.getElementById('serviceForm').reset();
        document.getElementById('serviceAction').value = 'add';
        document.getElementById('serviceModalTitle').textContent = 'Add New Service';
        document.getElementById('serviceId').value = '';
        serviceModal.show();
    });
    
    // Edit Service buttons
    document.querySelectorAll('.edit-service').forEach(button => {
        button.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            const name = this.getAttribute('data-name');
            const description = this.getAttribute('data-description');
            const price = this.getAttribute('data-price');
            const duration = this.getAttribute('data-duration');
            const category = this.getAttribute('data-category');
            const subcategory = this.getAttribute('data-subcategory');
            const status = this.getAttribute('data-status');
            
            document.getElementById('serviceId').value = id;
            document.getElementById('serviceName').value = name;
            document.getElementById('serviceDescription').value = description;
            document.getElementById('servicePrice').value = price;
            document.getElementById('serviceDuration').value = duration;
            document.getElementById('serviceCategory').value = category;
            document.getElementById('serviceSubcategory').value = subcategory;
            document.getElementById('serviceStatus').value = status;
            
            document.getElementById('serviceAction').value = 'update';
            document.getElementById('serviceModalTitle').textContent = 'Edit Service';
            
            serviceModal.show();
        });
    });
    
    // Delete Service buttons
    document.querySelectorAll('.delete-service').forEach(button => {
        button.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            const name = this.getAttribute('data-name');
            
            document.getElementById('deleteServiceId').value = id;
            document.getElementById('deleteServiceName').textContent = name;
            
            deleteModal.show();
        });
    });
    
    // Save Service button
    document.getElementById('saveService').addEventListener('click', function() {
        if (validateServiceForm()) {
            document.getElementById('serviceForm').submit();
        }
    });
    
    // Confirm Delete button
    document.getElementById('confirmDelete').addEventListener('click', function() {
        document.getElementById('deleteForm').submit();
    });
    
    // Category filter buttons
    document.querySelectorAll('.category-filter').forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            document.querySelectorAll('.category-filter').forEach(btn => {
                btn.classList.remove('active');
            });
            
            // Add active class to clicked button
            this.classList.add('active');
            
            const category = this.getAttribute('data-category');
            filterServices(category);
        });
    });
    
    // Form validation
    function validateServiceForm() {
        const form = document.getElementById('serviceForm');
        
        if (!form.checkValidity()) {
            form.reportValidity();
            return false;
        }
        
        return true;
    }
    
    // Filter services by category
    function filterServices(category) {
        const rows = document.querySelectorAll('.service-row');
        const noServicesRow = document.getElementById('no-services-row');
        let visibleCount = 0;
        
        rows.forEach(row => {
            if (category === 'all' || row.getAttribute('data-category') === category) {
                row.style.display = '';
                visibleCount++;
            } else {
                row.style.display = 'none';
            }
        });
        
        // Show "No services found" message if no services are visible
        if (noServicesRow) {
            if (visibleCount === 0) {
                noServicesRow.style.display = '';
            } else {
                noServicesRow.style.display = 'none';
            }
        }
    }
    
    // Auto-hide success message after 3 seconds
    const serviceMessage = document.getElementById('service-message');
    if (serviceMessage && !serviceMessage.classList.contains('d-none')) {
        setTimeout(() => {
            serviceMessage.classList.add('d-none');
        }, 3000);
    }
});
</script>

<?php include 'components/footer.php'; ?>
