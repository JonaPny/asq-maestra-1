document.addEventListener("DOMContentLoaded", () => {
  // DOM Elements
  const notificationIcon = document.getElementById("notification-icon")
  const notificationDropdown = document.getElementById("notification-dropdown")
  const profileIcon = document.getElementById("profile-icon")
  const profileDropdown = document.getElementById("profile-dropdown")
  const cartIcon = document.getElementById("cart-icon")
  const cartSidebar = document.getElementById("cart-sidebar")
  const closeCart = document.getElementById("close-cart")
  const overlay = document.getElementById("overlay")
  const navItems = document.querySelectorAll(".sidebar nav ul li")
  const pages = document.querySelectorAll(".page")
  const categoryTabs = document.querySelectorAll(".category-tab")
  const categoryContents = document.querySelectorAll(".category-content")
  const addToCartButtons = document.querySelectorAll(".add-to-cart-btn")
  const cartItems = document.getElementById("cart-items")
  const cartCount = document.getElementById("cart-count")
  const cartSubtotal = document.getElementById("cart-subtotal")
  const cartTax = document.getElementById("cart-tax")
  const cartTotal = document.getElementById("cart-total")
  const depositPayment = document.getElementById("deposit-payment")
  const fullPayment = document.getElementById("full-payment")
  const depositInfo = document.getElementById("deposit-info")
  const depositAmount = document.getElementById("deposit-amount")
  const balanceDue = document.getElementById("balance-due")
  const checkoutBtn = document.getElementById("checkout-btn")
  const checkoutModal = document.getElementById("checkout-modal")
  const closeModalButtons = document.querySelectorAll(".close-modal")
  const confirmBooking = document.getElementById("confirm-booking")
  const confirmationModal = document.getElementById("confirmation-modal")
  const closeConfirmation = document.getElementById("close-confirmation")
  const historyTabs = document.querySelectorAll(".tab")
  const historyContents = document.querySelectorAll(".tab-content")
  const calendarDays = document.getElementById("calendar-days")
  const currentMonthElement = document.getElementById("current-month")
  const prevMonthButton = document.getElementById("prev-month")
  const nextMonthButton = document.getElementById("next-month")
  const timeSlots = document.getElementById("time-slots")
  const selectedDateElement = document.getElementById("selected-date")
  const appointmentDate = document.getElementById("appointment-date")
  const appointmentTime = document.getElementById("appointment-time")
  const paymentCards = document.querySelectorAll(".payment-card")
  const profileLink = document.getElementById("profile-link")
  const appointmentsLink = document.getElementById("appointments-link")
  const historyLink = document.getElementById("history-link")

  // State
  let cart = []
  const currentDate = new Date()
  let selectedDate = null
  let selectedTimeSlot = null

  // Initialize
  generateCalendar(currentDate)

  // Event Listeners

  // Notification dropdown
  notificationIcon.addEventListener("click", () => {
    notificationDropdown.style.display = notificationDropdown.style.display === "block" ? "none" : "block"
    profileDropdown.style.display = "none"
  })

  // Profile dropdown
  profileIcon.addEventListener("click", () => {
    profileDropdown.style.display = profileDropdown.style.display === "block" ? "none" : "block"
    notificationDropdown.style.display = "none"
  })

  // Cart sidebar
  cartIcon.addEventListener("click", () => {
    cartSidebar.classList.add("open")
    overlay.style.display = "block"
  })

  closeCart.addEventListener("click", () => {
    cartSidebar.classList.remove("open")
    overlay.style.display = "none"
  })

  overlay.addEventListener("click", () => {
    cartSidebar.classList.remove("open")
    checkoutModal.style.display = "none"
    confirmationModal.style.display = "none"
    overlay.style.display = "none"
  })

  // Navigation
  navItems.forEach((item) => {
    item.addEventListener("click", function () {
      const pageId = this.getAttribute("data-page")

      navItems.forEach((navItem) => navItem.classList.remove("active"))
      pages.forEach((page) => page.classList.remove("active"))

      this.classList.add("active")
      document.getElementById(`${pageId}-page`).classList.add("active")
    })
  })

  // Category tabs
  categoryTabs.forEach((tab) => {
    tab.addEventListener("click", function () {
      const category = this.getAttribute("data-category")

      categoryTabs.forEach((categoryTab) => categoryTab.classList.remove("active"))
      categoryContents.forEach((content) => content.classList.remove("active"))

      this.classList.add("active")
      document.getElementById(`${category}-content`).classList.add("active")
    })
  })

  // Add to cart
  addToCartButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const serviceCard = this.closest(".service-card")
      const serviceId = serviceCard.getAttribute("data-id")
      const serviceName = serviceCard.getAttribute("data-name")
      const servicePrice = Number.parseFloat(serviceCard.getAttribute("data-price"))

      addToCart(serviceId, serviceName, servicePrice)
      updateCart()

      // Show cart
      cartSidebar.classList.add("open")
      overlay.style.display = "block"
    })
  })

  // Payment options
  depositPayment.addEventListener("change", function () {
    if (this.checked) {
      depositInfo.style.display = "block"
      updateDepositInfo()
    }
  })

  fullPayment.addEventListener("change", function () {
    if (this.checked) {
      depositInfo.style.display = "none"
    }
  })

  // Checkout
  checkoutBtn.addEventListener("click", () => {
    if (cart.length === 0) return

    prepareCheckout()
    cartSidebar.classList.remove("open")
    checkoutModal.style.display = "block"
    overlay.style.display = "block"
  })

  // Close modals
  closeModalButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const modal = this.closest(".modal")
      modal.style.display = "none"
      overlay.style.display = "none"
    })
  })

  // Confirm booking
  confirmBooking.addEventListener("click", () => {
    if (!appointmentDate.value || !appointmentTime.value) {
      alert("Please select a date and time for your appointment")
      return
    }

    checkoutModal.style.display = "none"
    confirmationModal.style.display = "block"

    // Set confirmation details
    document.getElementById("confirmed-date").textContent = formatDate(new Date(appointmentDate.value))
    document.getElementById("confirmed-time").textContent = appointmentTime.value
    document.getElementById("confirmed-services").textContent = cart.map((item) => item.name).join(", ")
    document.getElementById("confirmed-total").textContent = `$${calculateTotal().toFixed(2)}`
    document.getElementById("confirmed-payment").textContent = fullPayment.checked ? "Paid in Full" : "50% Deposit"
  })

  // Close confirmation
  closeConfirmation.addEventListener("click", () => {
    confirmationModal.style.display = "none"
    overlay.style.display = "none"

    // Reset cart
    cart = []
    updateCart()
  })

  // History tabs
  historyTabs.forEach((tab) => {
    tab.addEventListener("click", function () {
      const tabId = this.getAttribute("data-tab")

      historyTabs.forEach((historyTab) => historyTab.classList.remove("active"))
      historyContents.forEach((content) => content.classList.remove("active"))

      this.classList.add("active")
      document.getElementById(`${tabId}-content`).classList.add("active")
    })
  })

  // Calendar navigation
  prevMonthButton.addEventListener("click", () => {
    currentDate.setMonth(currentDate.getMonth() - 1)
    generateCalendar(currentDate)
  })

  nextMonthButton.addEventListener("click", () => {
    currentDate.setMonth(currentDate.getMonth() + 1)
    generateCalendar(currentDate)
  })

  // Payment cards
  paymentCards.forEach((card) => {
    card.addEventListener("click", function () {
      paymentCards.forEach((c) => c.classList.remove("selected"))
      this.classList.add("selected")
    })
  })

  // Profile links
  profileLink.addEventListener("click", (e) => {
    e.preventDefault()
    navItems.forEach((item) => item.classList.remove("active"))
    pages.forEach((page) => page.classList.remove("active"))

    document.querySelector('[data-page="profile"]').classList.add("active")
    document.getElementById("profile-page").classList.add("active")
    profileDropdown.style.display = "none"
  })

  appointmentsLink.addEventListener("click", (e) => {
    e.preventDefault()
    navItems.forEach((item) => item.classList.remove("active"))
    pages.forEach((page) => page.classList.remove("active"))

    document.querySelector('[data-page="appointments"]').classList.add("active")
    document.getElementById("appointments-page").classList.add("active")
    profileDropdown.style.display = "none"
  })

  historyLink.addEventListener("click", (e) => {
    e.preventDefault()
    navItems.forEach((item) => item.classList.remove("active"))
    pages.forEach((page) => page.classList.remove("active"))

    document.querySelector('[data-page="history"]').classList.add("active")
    document.getElementById("history-page").classList.add("active")
    profileDropdown.style.display = "none"
  })

  // Functions

  // Add item to cart
  function addToCart(id, name, price) {
    const existingItem = cart.find((item) => item.id === id)

    if (existingItem) {
      existingItem.quantity++
    } else {
      cart.push({
        id: id,
        name: name,
        price: price,
        quantity: 1,
      })
    }
  }

  // Update cart display
  function updateCart() {
    // Update cart count
    cartCount.textContent = cart.reduce((total, item) => total + item.quantity, 0)

    // Clear cart items
    cartItems.innerHTML = ""

    if (cart.length === 0) {
      cartItems.innerHTML = '<div class="empty-cart-message">Your cart is empty</div>'
      cartSubtotal.textContent = "$0.00"
      cartTax.textContent = "$0.00"
      cartTotal.textContent = "$0.00"
      depositAmount.textContent = "$0.00"
      balanceDue.textContent = "$0.00"
      return
    }

    // Add items to cart
    cart.forEach((item) => {
      const cartItem = document.createElement("div")
      cartItem.classList.add("cart-item")

      cartItem.innerHTML = `
                  <div class="cart-item-details">
                      <div class="cart-item-name">${item.name}</div>
                      <div class="cart-item-price">$${item.price.toFixed(2)}</div>
                  </div>
                  <div class="cart-item-quantity">
                      <button class="quantity-btn minus" data-id="${item.id}">-</button>
                      <span>${item.quantity}</span>
                      <button class="quantity-btn plus" data-id="${item.id}">+</button>
                      <span class="cart-item-remove" data-id="${item.id}"><i class="fas fa-trash"></i></span>
                  </div>
              `

      cartItems.appendChild(cartItem)
    })

    // Add event listeners to quantity buttons
    document.querySelectorAll(".quantity-btn.minus").forEach((button) => {
      button.addEventListener("click", function () {
        const id = this.getAttribute("data-id")
        decreaseQuantity(id)
        updateCart()
        updateDepositInfo()
      })
    })

    document.querySelectorAll(".quantity-btn.plus").forEach((button) => {
      button.addEventListener("click", function () {
        const id = this.getAttribute("data-id")
        increaseQuantity(id)
        updateCart()
        updateDepositInfo()
      })
    })

    document.querySelectorAll(".cart-item-remove").forEach((button) => {
      button.addEventListener("click", function () {
        const id = this.getAttribute("data-id")
        removeFromCart(id)
        updateCart()
        updateDepositInfo()
      })
    })

    // Update totals
    const subtotal = calculateSubtotal()
    const tax = subtotal * 0.08
    const total = subtotal + tax

    cartSubtotal.textContent = `$${subtotal.toFixed(2)}`
    cartTax.textContent = `$${tax.toFixed(2)}`
    cartTotal.textContent = `$${total.toFixed(2)}`

    updateDepositInfo()
  }

  // Calculate subtotal
  function calculateSubtotal() {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0)
  }

  // Calculate total
  function calculateTotal() {
    const subtotal = calculateSubtotal()
    const tax = subtotal * 0.08
    return subtotal + tax
  }

  // Update deposit info
  function updateDepositInfo() {
    const total = calculateTotal()
    const deposit = total * 0.5

    depositAmount.textContent = `$${deposit.toFixed(2)}`
    balanceDue.textContent = `$${deposit.toFixed(2)}`
  }

  // Increase item quantity
  function increaseQuantity(id) {
    const item = cart.find((item) => item.id === id)
    if (item) {
      item.quantity++
    }
  }

  // Decrease item quantity
  function decreaseQuantity(id) {
    const item = cart.find((item) => item.id === id)
    if (item) {
      item.quantity--
      if (item.quantity === 0) {
        removeFromCart(id)
      }
    }
  }

  // Remove item from cart
  function removeFromCart(id) {
    cart = cart.filter((item) => item.id !== id)
  }

  // Prepare checkout
  function prepareCheckout() {
    const checkoutItems = document.getElementById("checkout-items")
    checkoutItems.innerHTML = ""

    cart.forEach((item) => {
      const checkoutItem = document.createElement("div")
      checkoutItem.classList.add("checkout-item")

      checkoutItem.innerHTML = `
                  <div class="checkout-item-name">${item.name} x${item.quantity}</div>
                  <div class="checkout-item-price">$${(item.price * item.quantity).toFixed(2)}</div>
              `

      checkoutItems.appendChild(checkoutItem)
    })

    const subtotal = calculateSubtotal()
    const tax = subtotal * 0.08
    const total = subtotal + tax

    document.getElementById("checkout-subtotal").textContent = `$${subtotal.toFixed(2)}`
    document.getElementById("checkout-tax").textContent = `$${tax.toFixed(2)}`
    document.getElementById("checkout-total").textContent = `$${total.toFixed(2)}`

    const checkoutDepositInfo = document.getElementById("checkout-deposit-info")

    if (depositPayment.checked) {
      checkoutDepositInfo.classList.remove("hidden")
      const deposit = total * 0.5
      document.getElementById("checkout-deposit").textContent = `$${deposit.toFixed(2)}`
      document.getElementById("checkout-balance").textContent = `$${deposit.toFixed(2)}`
    } else {
      checkoutDepositInfo.classList.add("hidden")
    }

    // Set min date for appointment
    const today = new Date()
    const yyyy = today.getFullYear()
    const mm = String(today.getMonth() + 1).padStart(2, "0")
    const dd = String(today.getDate()).padStart(2, "0")
    appointmentDate.min = `${yyyy}-${mm}-${dd}`

    // Reset appointment time
    appointmentTime.innerHTML = '<option value="">Select a date first</option>'

    // Add event listener to appointment date
    appointmentDate.addEventListener("change", function () {
      if (this.value) {
        generateTimeSlots(new Date(this.value))
      }
    })
  }

  // Generate calendar
  function generateCalendar(date) {
    const year = date.getFullYear()
    const month = date.getMonth()

    // Set current month text
    currentMonthElement.textContent = `${date.toLocaleString("default", { month: "long" })} ${year}`

    // Clear calendar days
    calendarDays.innerHTML = ""

    // Get first day of month
    const firstDay = new Date(year, month, 1)
    const lastDay = new Date(year, month + 1, 0)

    // Get day of week for first day (0 = Sunday, 6 = Saturday)
    const firstDayIndex = firstDay.getDay()

    // Get number of days in month
    const daysInMonth = lastDay.getDate()

    // Get number of days in previous month
    const prevLastDay = new Date(year, month, 0).getDate()

    // Get today's date
    const today = new Date()

    // Add days from previous month
    for (let i = firstDayIndex; i > 0; i--) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("calendar-day", "other-month")
      dayElement.textContent = prevLastDay - i + 1
      calendarDays.appendChild(dayElement)
    }

    // Add days for current month
    for (let i = 1; i <= daysInMonth; i++) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("calendar-day")
      dayElement.textContent = i

      // Check if day is today
      if (year === today.getFullYear() && month === today.getMonth() && i === today.getDate()) {
        dayElement.classList.add("today")
      }

      // Check if day is in the past
      const currentDate = new Date(year, month, i)
      if (currentDate < new Date(today.getFullYear(), today.getMonth(), today.getDate())) {
        dayElement.classList.add("unavailable")
      } else {
        // Randomly mark some days as unavailable (for demo purposes)
        if (Math.random() < 0.2) {
          dayElement.classList.add("unavailable")
        } else {
          dayElement.addEventListener("click", function () {
            // Remove selected class from all days
            document.querySelectorAll(".calendar-day").forEach((day) => {
              day.classList.remove("selected")
            })

            // Add selected class to clicked day
            this.classList.add("selected")

            // Set selected date
            selectedDate = new Date(year, month, i)

            // Generate time slots
            generateTimeSlots(selectedDate)
          })
        }
      }

      calendarDays.appendChild(dayElement)
    }

    // Add days from next month
    const daysAfterMonth = 42 - (firstDayIndex + daysInMonth)
    for (let i = 1; i <= daysAfterMonth; i++) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("calendar-day", "other-month")
      dayElement.textContent = i
      calendarDays.appendChild(dayElement)
    }
  }

  // Generate time slots
  function generateTimeSlots(date) {
    // Format date for display
    selectedDateElement.textContent = formatDate(date)

    // Clear time slots
    timeSlots.innerHTML = ""

    // Generate time slots from 9 AM to 5 PM
    const startHour = 9
    const endHour = 17

    for (let hour = startHour; hour <= endHour; hour++) {
      for (let minute = 0; minute < 60; minute += 30) {
        if (hour === endHour && minute > 0) continue

        const timeSlot = document.createElement("div")
        timeSlot.classList.add("time-slot")

        const hourFormatted = hour % 12 === 0 ? 12 : hour % 12
        const amPm = hour < 12 ? "AM" : "PM"
        const minuteFormatted = minute === 0 ? "00" : minute

        const timeString = `${hourFormatted}:${minuteFormatted} ${amPm}`
        timeSlot.textContent = timeString

        // Randomly mark some time slots as unavailable (for demo purposes)
        if (Math.random() < 0.3) {
          timeSlot.classList.add("unavailable")
        } else {
          timeSlot.addEventListener("click", function () {
            // Remove selected class from all time slots
            document.querySelectorAll(".time-slot").forEach((slot) => {
              slot.classList.remove("selected")
            })

            // Add selected class to clicked time slot
            this.classList.add("selected")

            // Set selected time slot
            selectedTimeSlot = timeString

            // Update appointment time in checkout
            updateAppointmentTime(date, timeString)
          })
        }

        timeSlots.appendChild(timeSlot)
      }
    }

    // Also update the appointment date in checkout
    if (appointmentDate) {
      const yyyy = date.getFullYear()
      const mm = String(date.getMonth() + 1).padStart(2, "0")
      const dd = String(date.getDate()).padStart(2, "0")
      appointmentDate.value = `${yyyy}-${mm}-${dd}`

      // Generate time slots for checkout
      generateCheckoutTimeSlots(date)
    }
  }

  // Generate time slots for checkout
  function generateCheckoutTimeSlots(date) {
    // Clear time slots
    appointmentTime.innerHTML = ""

    // Generate time slots from 9 AM to 5 PM
    const startHour = 9
    const endHour = 17

    for (let hour = startHour; hour <= endHour; hour++) {
      for (let minute = 0; minute < 60; minute += 30) {
        if (hour === endHour && minute > 0) continue

        const hourFormatted = hour % 12 === 0 ? 12 : hour % 12
        const amPm = hour < 12 ? "AM" : "PM"
        const minuteFormatted = minute === 0 ? "00" : minute

        const timeString = `${hourFormatted}:${minuteFormatted} ${amPm}`

        // Randomly mark some time slots as unavailable (for demo purposes)
        if (Math.random() < 0.3) continue

        const option = document.createElement("option")
        option.value = timeString
        option.textContent = timeString

        appointmentTime.appendChild(option)
      }
    }
  }

  // Update appointment time in checkout
  function updateAppointmentTime(date, timeString) {
    if (appointmentDate && appointmentTime) {
      const yyyy = date.getFullYear()
      const mm = String(date.getMonth() + 1).padStart(2, "0")
      const dd = String(date.getDate()).padStart(2, "0")
      appointmentDate.value = `${yyyy}-${mm}-${dd}`

      // Find or create option for time
      let option = Array.from(appointmentTime.options).find((opt) => opt.value === timeString)

      if (!option) {
        option = document.createElement("option")
        option.value = timeString
        option.textContent = timeString
        appointmentTime.appendChild(option)
      }

      appointmentTime.value = timeString
    }
  }

  // Format date for display
  function formatDate(date) {
    const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" }
    return date.toLocaleDateString("en-US", options)
  }

  // Close dropdowns when clicking outside
  document.addEventListener("click", (e) => {
    if (!notificationIcon.contains(e.target) && !notificationDropdown.contains(e.target)) {
      notificationDropdown.style.display = "none"
    }

    if (!profileIcon.contains(e.target) && !profileDropdown.contains(e.target)) {
      profileDropdown.style.display = "none"
    }
  })
})
