<div class="page active" id="services-page">
    <h2>Our Services</h2>
    <div class="categories">
        <div class="category-tabs">
            <button class="category-tab active" data-category="haircut">Haircut</button>
            <button class="category-tab" data-category="color">Hair Color</button>
            <button class="category-tab" data-category="treatment">Hair Treatment</button>
            <button class="category-tab" data-category="rebonding">Rebonding</button>
        </div>

        <!-- Haircut Category -->
        <div class="category-content active" id="haircut-content">
            <div class="subcategory-grid">
                <div class="service-card" data-id="1" data-name="Women's Haircut" data-price="45">
                    <img src="/logo.png" alt="Women's Haircut">
                    <h3>Women's Haircut</h3>
                    <p>Professional haircut for women of all hair lengths.</p>
                    <div class="service-price">$45</div>
                    <button class="add-to-cart-btn">Add to Cart</button>
                </div>
                <div class="service-card" data-id="2" data-name="Men's Haircut" data-price="30">
                    <img src="/placeholder.svg?height=150&width=200" alt="Men's Haircut">
                    <h3>Men's Haircut</h3>
                    <p>Professional haircut for men including styling.</p>
                    <div class="service-price">$30</div>
                    <button class="add-to-cart-btn">Add to Cart</button>
                </div>
                <div class="service-card" data-id="3" data-name="Kids Haircut" data-price="25">
                    <img src="/placeholder.svg?height=150&width=200" alt="Kids Haircut">
                    <h3>Kids Haircut</h3>
                    <p>Gentle haircut for children under 12.</p>
                    <div class="service-price">$25</div>
                    <button class="add-to-cart-btn">Add to Cart</button>
                </div>
                <div class="service-card" data-id="4" data-name="Bangs Trim" data-price="15">
                    <img src="/placeholder.svg?height=150&width=200" alt="Bangs Trim">
                    <h3>Bangs Trim</h3>
                    <p>Quick trim for bangs only.</p>
                    <div class="service-price">$15</div>
                    <button class="add-to-cart-btn">Add to Cart</button>
                </div>
            </div>
        </div>

        <!-- Hair Color Category -->
        <div class="category-content" id="color-content">
            <div class="subcategory-grid">
                <div class="service-card" data-id="5" data-name="Root Touch-Up" data-price="65">
                    <img src="/placeholder.svg?height=150&width=200" alt="Root Touch-Up">
                    <h3>Root Touch-Up</h3>
                    <p>Color application to roots only.</p>
                    <div class="service-price">$65</div>
                    <button class="add-to-cart-btn">Add to Cart</button>
                </div>
                <div class="service-card" data-id="6" data-name="Full Color" data-price="95">
                    <img src="/placeholder.svg?height=150&width=200" alt="Full Color">
                    <h3>Full Color</h3>
                    <p>Complete hair color application.</p>
                    <div class="service-price">$95</div>
                    <button class="add-to-cart-btn">Add to Cart</button>
                </div>
                <div class="service-card" data-id="7" data-name="Highlights" data-price="120">
                    <img src="/placeholder.svg?height=150&width=200" alt="Highlights">
                    <h3>Highlights</h3>
                    <p>Partial or full highlights to add dimension.</p>
                    <div class="service-price">$120</div>
                    <button class="add-to-cart-btn">Add to Cart</button>
                </div>
                <div class="service-card" data-id="8" data-name="Balayage" data-price="150">
                    <img src="/placeholder.svg?height=150&width=200" alt="Balayage">
                    <h3>Balayage</h3>
                    <p>Hand-painted highlights for a natural look.</p>
                    <div class="service-price">$150</div>
                    <button class="add-to-cart-btn">Add to Cart</button>
                </div>
            </div>
        </div>

        <!-- Hair Treatment Category -->
        <div class="category-content" id="treatment-content">
            <div class="subcategory-grid">
                <div class="service-card" data-id="9" data-name="Deep Conditioning" data-price="40">
                    <img src="/placeholder.svg?height=150&width=200" alt="Deep Conditioning">
                    <h3>Deep Conditioning</h3>
                    <p>Intensive moisture treatment for dry hair.</p>
                    <div class="service-price">$40</div>
                    <button class="add-to-cart-btn">Add to Cart</button>
                </div>
                <div class="service-card" data-id="10" data-name="Keratin Treatment" data-price="180">
                    <img src="/placeholder.svg?height=150&width=200" alt="Keratin Treatment">
                    <h3>Keratin Treatment</h3>
                    <p>Smoothing treatment to reduce frizz.</p>
                    <div class="service-price">$180</div>
                    <button class="add-to-cart-btn">Add to Cart</button>
                </div>
                <div class="service-card" data-id="11" data-name="Scalp Treatment" data-price="55">
                    <img src="/placeholder.svg?height=150&width=200" alt="Scalp Treatment">
                    <h3>Scalp Treatment</h3>
                    <p>Therapeutic treatment for scalp health.</p>
                    <div class="service-price">$55</div>
                    <button class="add-to-cart-btn">Add to Cart</button>
                </div>
            </div>
        </div>

        <!-- Rebonding Category -->
        <div class="category-content" id="rebonding-content">
            <div class="subcategory-grid">
                <div class="service-card" data-id="12" data-name="Hair Rebonding" data-price="200">
                    <img src="/placeholder.svg?height=150&width=200" alt="Hair Rebonding">
                    <h3>Hair Rebonding</h3>
                    <p>Chemical straightening for curly or wavy hair.</p>
                    <div class="service-price">$200</div>
                    <button class="add-to-cart-btn">Add to Cart</button>
                </div>
                <div class="service-card" data-id="13" data-name="Japanese Straightening"
                    data-price="250">
                    <img src="/placeholder.svg?height=150&width=200" alt="Japanese Straightening">
                    <h3>Japanese Straightening</h3>
                    <p>Permanent straightening with thermal reconditioning.</p>
                    <div class="service-price">$250</div>
                    <button class="add-to-cart-btn">Add to Cart</button>
                </div>
            </div>
        </div>
    </div>
</div>
