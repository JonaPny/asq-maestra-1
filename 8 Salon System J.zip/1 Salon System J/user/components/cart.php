<!-- Cart Sidebar -->
<div class="cart-sidebar" id="cart-sidebar">
    <div class="cart-header">
        <h2>Your Cart</h2>
        <button id="close-cart"><i class="fas fa-times"></i></button>
    </div>
    <div class="cart-items" id="cart-items">
        <!-- Cart items will be added here dynamically -->
        <div class="empty-cart-message">Your cart is empty</div>
    </div>
    <div class="cart-summary">
        <div class="summary-row">
            <span>Subtotal:</span>
            <span id="cart-subtotal">$0.00</span>
        </div>
        <div class="summary-row">
            <span>Tax (8%):</span>
            <span id="cart-tax">$0.00</span>
        </div>
        <div class="summary-row total">
            <span>Total:</span>
            <span id="cart-total">$0.00</span>
        </div>
    </div>
    <div class="payment-options">
        <h3>Payment Options</h3>
        <div class="payment-option">
            <input type="radio" id="full-payment" name="payment-option" value="full" checked>
            <label for="full-payment">Pay in Full</label>
        </div>
        <div class="payment-option">
            <input type="radio" id="deposit-payment" name="payment-option" value="deposit">
            <label for="deposit-payment">50% Deposit</label>
            <div class="deposit-info" id="deposit-info">
                <div class="summary-row">
                    <span>Deposit Amount (50%):</span>
                    <span id="deposit-amount">$0.00</span>
                </div>
                <div class="summary-row">
                    <span>Balance Due at Appointment:</span>
                    <span id="balance-due">$0.00</span>
                </div>
            </div>
        </div>
    </div>
    <button class="checkout-btn" id="checkout-btn">Proceed to Checkout</button>
</div>

<!-- Overlay -->
<div class="overlay" id="overlay"></div>
