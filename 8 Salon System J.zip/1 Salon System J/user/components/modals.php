<!-- Checkout Modal -->
<div class="modal" id="checkout-modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Complete Your Booking</h2>
            <button class="close-modal">&times;</button>
        </div>
        <div class="modal-body">
            <div class="checkout-summary">
                <h3>Order Summary</h3>
                <div id="checkout-items">
                    <!-- Checkout items will be added here dynamically -->
                </div>
                <div class="summary-row">
                    <span>Subtotal:</span>
                    <span id="checkout-subtotal">$0.00</span>
                </div>
                <div class="summary-row">
                    <span>Tax (8%):</span>
                    <span id="checkout-tax">$0.00</span>
                </div>
                <div class="summary-row total">
                    <span>Total:</span>
                    <span id="checkout-total">$0.00</span>
                </div>
                <div id="checkout-deposit-info" class="hidden">
                    <div class="summary-row">
                        <span>Deposit Amount (50%):</span>
                        <span id="checkout-deposit">$0.00</span>
                    </div>
                    <div class="summary-row">
                        <span>Balance Due at Appointment:</span>
                        <span id="checkout-balance">$0.00</span>
                    </div>
                </div>
            </div>

            <div class="appointment-selection">
                <h3>Select Appointment Time</h3>
                <div class="form-group">
                    <label for="appointment-date">Date</label>
                    <input type="date" id="appointment-date" min="2025-05-06">
                </div>
                <div class="form-group">
                    <label for="appointment-time">Time</label>
                    <select id="appointment-time">
                        <option value="">Select a date first</option>
                    </select>
                </div>
            </div>

            <div class="payment-method">
                <h3>Payment Method</h3>
                <div class="payment-cards">
                    <div class="payment-card selected">
                        <i class="fab fa-cc-visa"></i>
                        <span>Credit Card</span>
                    </div>
                    <div class="payment-card">
                        <i class="fab fa-paypal"></i>
                        <span>PayPal</span>
                    </div>
                    <div class="payment-card">
                        <i class="fas fa-money-bill-wave"></i>
                        <span>Pay Later</span>
                    </div>
                </div>

                <div class="credit-card-form">
                    <div class="form-group">
                        <label for="card-number">Card Number</label>
                        <input type="text" id="card-number" placeholder="1234 5678 9012 3456">
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="expiry-date">Expiry Date</label>
                            <input type="text" id="expiry-date" placeholder="MM/YY">
                        </div>
                        <div class="form-group">
                            <label for="cvv">CVV</label>
                            <input type="text" id="cvv" placeholder="123">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="card-name">Name on Card</label>
                        <input type="text" id="card-name" placeholder="John Doe">
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="cancel-btn">Cancel</button>
            <button class="confirm-btn" id="confirm-booking">Confirm Booking</button>
        </div>
    </div>
</div>

<!-- Booking Confirmation Modal -->
<div class="modal" id="confirmation-modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Booking Confirmed!</h2>
            <button class="close-modal">&times;</button>
        </div>
        <div class="modal-body">
            <div class="confirmation-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h3>Thank you for your booking</h3>
            <p>Your appointment has been confirmed for:</p>
            <div class="confirmation-details">
                <p><strong>Date:</strong> <span id="confirmed-date">May 10, 2025</span></p>
                <p><strong>Time:</strong> <span id="confirmed-time">2:00 PM</span></p>
                <p><strong>Services:</strong> <span id="confirmed-services">Hair Coloring, Women's
                        Haircut</span></p>
                <p><strong>Total:</strong> <span id="confirmed-total">$140.00</span></p>
                <p><strong>Payment:</strong> <span id="confirmed-payment">Paid in Full</span></p>
            </div>
            <p>A confirmation email has been sent to your registered email address.</p>
            <p>You will receive a reminder notification 24 hours before your appointment.</p>
        </div>
        <div class="modal-footer">
            <button class="confirm-btn" id="close-confirmation">Done</button>
        </div>
    </div>
</div>
