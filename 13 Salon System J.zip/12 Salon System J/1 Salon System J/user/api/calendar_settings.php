<?php
// Include database connection
include '../../login_register/tools/salondb.php';
$conn = getDatabaseConnection();

// Set headers for JSON response
header('Content-Type: application/json');

// Get current month and year from request or use current date
$month = isset($_GET['month']) ? intval($_GET['month']) : date('n');
$year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');

// Get calendar settings for the month
$calendar_settings = [];
$first_day = sprintf('%04d-%02d-01', $year, $month);
$last_day = date('Y-m-t', strtotime($first_day));

// Get calendar settings
$stmt = $conn->prepare("SELECT date, status, notes FROM calendar_settings WHERE date BETWEEN ? AND ?");
$stmt->bind_param("ss", $first_day, $last_day);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $calendar_settings[$row['date']] = [
        'status' => $row['status'],
        'notes' => $row['notes']
    ];
}
$stmt->close();

// Get appointment counts for the month
$appointments = [];
$stmt = $conn->prepare("SELECT appointment_date, COUNT(*) as count, service_type FROM appointments WHERE appointment_date BETWEEN ? AND ? GROUP BY appointment_date");
$stmt->bind_param("ss", $first_day, $last_day);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $date = $row['appointment_date'];
    
    if (!isset($appointments[$date])) {
        $appointments[$date] = [
            'count' => 0,
            'type' => ''
        ];
    }
    
    $appointments[$date]['count'] += $row['count'];
}
$stmt->close();

// Return the data as JSON
echo json_encode([
    'calendar_settings' => $calendar_settings,
    'appointments' => $appointments,
    'month' => $month,
    'year' => $year
]);

// Close the database connection
if ($conn && $conn->ping()) {
    $conn->close();
}
?>
