document.addEventListener("DOMContentLoaded", () => {
  // DOM Elements
  const notificationIcon = document.getElementById("notification-icon")
  const notificationDropdown = document.getElementById("notification-dropdown")
  const profileIcon = document.getElementById("profile-icon")
  const profileDropdown = document.getElementById("profile-dropdown")
  const cartIcon = document.getElementById("cart-icon")
  const cartSidebar = document.getElementById("cart-sidebar")
  const closeCart = document.getElementById("close-cart")
  const overlay = document.getElementById("overlay")
  const navItems = document.querySelectorAll(".sidebar nav ul li")
  const pages = document.querySelectorAll(".page")
  const categoryTabs = document.querySelectorAll(".category-tab")
  const categoryContents = document.querySelectorAll(".category-content")
  const addToCartButtons = document.querySelectorAll(".add-to-cart-btn")
  const cartItems = document.getElementById("cart-items")
  const cartCount = document.getElementById("cart-count")
  const cartSubtotal = document.getElementById("cart-subtotal")
  const cartTotal = document.getElementById("cart-total")
  const depositPayment = document.getElementById("deposit-payment")
  const fullPayment = document.getElementById("full-payment") // Declare fullPayment here
  const depositInfo = document.getElementById("deposit-info")
  const depositAmount = document.getElementById("deposit-amount")
  const balanceDue = document.getElementById("balance-due")
  const checkoutBtn = document.getElementById("checkout-btn")
  const checkoutModal = document.getElementById("checkout-modal")
  const closeModalButtons = document.querySelectorAll(".close-modal")
  const confirmBooking = document.getElementById("confirm-booking")
  const confirmationModal = document.getElementById("confirmation-modal")
  const closeConfirmation = document.getElementById("close-confirmation")
  const historyTabs = document.querySelectorAll(".tab")
  const historyContents = document.querySelectorAll(".tab-content")
  const calendarDays = document.getElementById("calendar-days")
  const currentMonthElement = document.getElementById("current-month")
  const prevMonthButton = document.getElementById("prev-month")
  const nextMonthButton = document.getElementById("next-month")
  const timeSlots = document.getElementById("time-slots")
  const selectedDateElement = document.getElementById("selected-date")
  const appointmentDate = document.getElementById("appointment-date")
  const appointmentTime = document.getElementById("appointment-time")
  const paymentCards = document.querySelectorAll(".payment-card")
  const profileLink = document.getElementById("profile-link")
  const appointmentsLink = document.getElementById("appointments-link")
  const historyLink = document.getElementById("history-link")
  const transportationFeeContainer = document.getElementById("transportation-fee-container")
  const serviceTypeSelect = document.getElementById("service-type")
  const locationDetails = document.getElementById("location-details")

  // State
  let cart = []
  const currentDate = new Date()
  let selectedDate = null
  let selectedTimeSlot = null
  let calendarSettings = {} // Store calendar settings from admin
  let appointmentCounts = {} // Store appointment counts

  // Get active page from localStorage or default to "services"
  const savedActivePage = localStorage.getItem("activePage") || "services"

  // Initialize
  if (calendarDays) {
    fetchCalendarSettings(currentDate)
    setupCalendarRefresh() // Add this line to set up periodic refresh
  }

  // Set active page based on saved preference
  setActivePage(savedActivePage)

  // Event Listeners

  // Notification dropdown
  if (notificationIcon) {
    notificationIcon.addEventListener("click", () => {
      notificationDropdown.style.display = notificationDropdown.style.display === "block" ? "none" : "block"
      profileDropdown.style.display = "none"
    })
  }

  // Profile dropdown
  if (profileIcon) {
    profileIcon.addEventListener("click", () => {
      profileDropdown.style.display = profileDropdown.style.display === "block" ? "none" : "block"
      notificationDropdown.style.display = "none"
    })
  }

  // Cart sidebar
  if (cartIcon) {
    cartIcon.addEventListener("click", () => {
      cartSidebar.classList.add("open")
      overlay.style.display = "block"
    })
  }

  if (closeCart) {
    closeCart.addEventListener("click", () => {
      cartSidebar.classList.remove("open")
      overlay.style.display = "none"
    })
  }

  if (overlay) {
    overlay.addEventListener("click", () => {
      cartSidebar.classList.remove("open")
      if (checkoutModal) checkoutModal.style.display = "none"
      if (confirmationModal) confirmationModal.style.display = "none"
      overlay.style.display = "none"
    })
  }

  // Navigation
  navItems.forEach((item) => {
    item.addEventListener("click", function () {
      const pageId = this.getAttribute("data-page")
      setActivePage(pageId)
    })
  })

  // Category tabs
  categoryTabs.forEach((tab) => {
    tab.addEventListener("click", function () {
      const category = this.getAttribute("data-category")

      categoryTabs.forEach((categoryTab) => categoryTab.classList.remove("active"))
      categoryContents.forEach((content) => content.classList.remove("active"))

      this.classList.add("active")
      document.getElementById(`${category}-content`).classList.add("active")
    })
  })

  // Add to cart
  addToCartButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const serviceCard = this.closest(".service-card")
      const serviceId = serviceCard.getAttribute("data-id")
      const serviceName = serviceCard.getAttribute("data-name")
      const servicePrice = Number.parseFloat(serviceCard.getAttribute("data-price"))

      addToCart(serviceId, serviceName, servicePrice)
      updateCart()

      // Show cart
      cartSidebar.classList.add("open")
      overlay.style.display = "block"
    })
  })

  // Payment options
  if (depositPayment) {
    depositPayment.addEventListener("change", function () {
      if (this.checked) {
        depositInfo.style.display = "block"
        updateDepositInfo()
      }
    })
  }

  if (fullPayment) {
    fullPayment.addEventListener("change", function () {
      if (this.checked) {
        depositInfo.style.display = "none"
      }
    })
  }

  // Checkout
  if (checkoutBtn) {
    checkoutBtn.addEventListener("click", () => {
      if (cart.length === 0) return

      prepareCheckout()
      cartSidebar.classList.remove("open")
      checkoutModal.style.display = "block"
      overlay.style.display = "block"
    })
  }

  // Close modals
  closeModalButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const modal = this.closest(".modal")
      modal.style.display = "none"
      overlay.style.display = "none"
    })
  })

  // Confirm booking
  if (confirmBooking) {
    confirmBooking.addEventListener("click", () => {
      if (!appointmentDate.value || !appointmentTime.value) {
        alert("Please select a date and time for your appointment")
        return
      }

      // Check if home service is selected but address is empty
      const serviceType = document.getElementById("checkout-service-type").value
      if (serviceType === "home") {
        const address = document.getElementById("checkout-address").value.trim()
        if (!address) {
          alert("Please enter your complete address for home service")
          return
        }
      }

      // Prepare form data for submission
      const checkoutForm = document.getElementById("checkout-form")

      // Set payment method and status
      const selectedPaymentCard = document.querySelector(".payment-card.selected")
      const paymentMethod = selectedPaymentCard.getAttribute("data-method")
      document.getElementById("payment-method").value = paymentMethod

      // Set payment status (full or deposit)
      const paymentStatus = document.getElementById("full-payment").checked ? "full" : "deposit"
      document.getElementById("payment-status").value = paymentStatus

      // Set services JSON
      document.getElementById("services-json").value = JSON.stringify(cart)

      // Set amounts
      const subtotal = calculateSubtotal()
      const transportationFee = calculateTransportationFee()
      const total = calculateTotal()

      document.getElementById("subtotal-amount").value = subtotal
      document.getElementById("transportation-amount").value = transportationFee
      document.getElementById("total-amount").value = total

      // Submit the form via AJAX
      const formData = new FormData(checkoutForm)

      fetch("api/appointments.php", {
        method: "POST",
        body: formData,
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            // Show confirmation modal
            checkoutModal.style.display = "none"
            confirmationModal.style.display = "block"

            // Set confirmation details
            document.getElementById("confirmed-date").textContent = formatDate(new Date(appointmentDate.value))
            document.getElementById("confirmed-time").textContent = appointmentTime.value
            document.getElementById("confirmed-services").textContent = cart.map((item) => item.name).join(", ")

            // Set service type
            const serviceTypeText = serviceType === "home" ? "Home Service" : "Salon Service"
            document.getElementById("confirmed-service-type").textContent = serviceTypeText

            // Show/hide location details
            const confirmedLocationContainer = document.getElementById("confirmed-location-container")
            if (serviceType === "home") {
              confirmedLocationContainer.style.display = "block"

              // Set location area
              const locationArea = document.getElementById("checkout-location-area").value
              let locationText = ""

              switch (locationArea) {
                case "canlubang":
                  locationText = "Within Canlubang"
                  break
                case "calamba":
                  locationText = "Within Calamba (outside Canlubang)"
                  break
                case "outside":
                  locationText = "Outside Calamba"
                  break
              }

              document.getElementById("confirmed-location").textContent = locationText

              // Set address
              const address = document.getElementById("checkout-address").value
              document.getElementById("confirmed-address").textContent = address

              // Set transportation fee
              document.getElementById("confirmed-transportation").textContent = `₱${transportationFee.toFixed(2)}`
            } else {
              confirmedLocationContainer.style.display = "none"
            }

            // Set total
            document.getElementById("confirmed-total").textContent = `₱${total.toFixed(2)}`

            // Set payment method
            const paymentMethodText = selectedPaymentCard.querySelector("span").textContent
            document.getElementById("confirmed-payment-method").textContent = paymentMethodText

            // Set payment status
            document.getElementById("confirmed-payment").textContent =
              paymentStatus === "full" ? "Paid in Full" : "50% Deposit"

            // Reset cart
            cart = []
            updateCart()
          } else {
            alert("Error creating appointment: " + data.message)
          }
        })
        .catch((error) => {
          console.error("Error:", error)
          alert("An error occurred while creating your appointment. Please try again.")
        })
    })
  }

  // Close confirmation button
  const closeConfirmationBtn = document.getElementById("close-confirmation-btn")
  if (closeConfirmationBtn) {
    closeConfirmationBtn.addEventListener("click", () => {
      confirmationModal.style.display = "none"
      overlay.style.display = "none"
    })
  }

  // Close confirmation
  if (closeConfirmation) {
    closeConfirmation.addEventListener("click", () => {
      confirmationModal.style.display = "none"
      overlay.style.display = "none"

      // Reset cart
      cart = []
      updateCart()
    })
  }

  // History tabs
  historyTabs.forEach((tab) => {
    tab.addEventListener("click", function () {
      const tabId = this.getAttribute("data-tab")

      historyTabs.forEach((historyTab) => historyTab.classList.remove("active"))
      historyContents.forEach((content) => content.classList.remove("active"))

      this.classList.add("active")
      document.getElementById(`${tabId}-content`).classList.add("active")
    })
  })

  // Calendar navigation
  if (prevMonthButton) {
    prevMonthButton.addEventListener("click", () => {
      currentDate.setMonth(currentDate.getMonth() - 1)
      fetchCalendarSettings(currentDate)
    })
  }

  if (nextMonthButton) {
    nextMonthButton.addEventListener("click", () => {
      currentDate.setMonth(currentDate.getMonth() + 1)
      fetchCalendarSettings(currentDate)
    })
  }

  // Payment cards
  paymentCards.forEach((card) => {
    card.addEventListener("click", function () {
      paymentCards.forEach((c) => c.classList.remove("selected"))
      this.classList.add("selected")
    })
  })

  // Profile links
  if (profileLink) {
    profileLink.addEventListener("click", (e) => {
      e.preventDefault()
      setActivePage("profile")
      profileDropdown.style.display = "none"
    })
  }

  if (appointmentsLink) {
    appointmentsLink.addEventListener("click", (e) => {
      e.preventDefault()
      setActivePage("appointments")
      profileDropdown.style.display = "none"
    })
  }

  if (historyLink) {
    historyLink.addEventListener("click", (e) => {
      e.preventDefault()
      setActivePage("history")
      profileDropdown.style.display = "none"
    })
  }

  // Service type change
  if (serviceTypeSelect) {
    serviceTypeSelect.addEventListener("change", function () {
      if (this.value === "home") {
        locationDetails.style.display = "block"
      } else {
        locationDetails.style.display = "none"
      }

      updateCartTotals()
    })
  }

  // Location area change
  const locationAreaSelect = document.getElementById("location-area")
  if (locationAreaSelect) {
    locationAreaSelect.addEventListener("change", function () {
      const customFeeContainer = document.getElementById("custom-fee-container")

      if (this.value === "outside") {
        customFeeContainer.style.display = "block"
      } else {
        customFeeContainer.style.display = "none"
      }

      updateCartTotals()
    })
  }

  // Custom fee change
  const customFeeInput = document.getElementById("custom-fee")
  if (customFeeInput) {
    customFeeInput.addEventListener("input", () => {
      updateCartTotals()
    })
  }

  // Checkout service type change
  const checkoutServiceType = document.getElementById("checkout-service-type")
  if (checkoutServiceType) {
    checkoutServiceType.addEventListener("change", function () {
      const locationDetails = document.getElementById("checkout-location-details")

      if (this.value === "home") {
        locationDetails.style.display = "block"
      } else {
        locationDetails.style.display = "none"
      }

      // Update service type in cart as well
      if (serviceTypeSelect) {
        serviceTypeSelect.value = this.value

        // Trigger change event on cart service type
        const event = new Event("change")
        serviceTypeSelect.dispatchEvent(event)
      }
    })
  }

  // Checkout location area change
  const checkoutLocationArea = document.getElementById("checkout-location-area")
  if (checkoutLocationArea) {
    checkoutLocationArea.addEventListener("change", function () {
      const customFeeContainer = document.getElementById("checkout-custom-fee-container")

      if (this.value === "outside") {
        customFeeContainer.style.display = "block"
      } else {
        customFeeContainer.style.display = "none"
      }

      // Update location area in cart as well
      if (locationAreaSelect) {
        locationAreaSelect.value = this.value

        // Trigger change event on cart location area
        const event = new Event("change")
        locationAreaSelect.dispatchEvent(event)
      }
    })
  }

  // Checkout custom fee change
  const checkoutCustomFee = document.getElementById("checkout-custom-fee")
  if (checkoutCustomFee) {
    checkoutCustomFee.addEventListener("input", function () {
      // Update custom fee in cart as well
      if (customFeeInput) {
        customFeeInput.value = this.value

        // Trigger input event on cart custom fee
        const event = new Event("input")
        customFeeInput.dispatchEvent(event)
      }
    })
  }

  // Payment method selection
  document.querySelectorAll(".payment-card").forEach((card) => {
    card.addEventListener("click", function () {
      // Remove selected class from all cards
      document.querySelectorAll(".payment-card").forEach((c) => {
        c.classList.remove("selected")
      })

      // Add selected class to clicked card
      this.classList.add("selected")

      // Hide all payment forms
      document.querySelectorAll(".payment-form").forEach((form) => {
        form.style.display = "none"
      })

      // Show selected payment form
      const paymentMethod = this.querySelector("span").textContent.toLowerCase()
      if (paymentMethod.includes("credit")) {
        document.getElementById("credit-card-form").style.display = "block"
      } else if (paymentMethod.includes("gcash")) {
        document.getElementById("gcash-form").style.display = "block"
      } else if (paymentMethod.includes("maya")) {
        document.getElementById("maya-form").style.display = "block"
      }
    })
  })

  // Functions

  // Fetch calendar settings from the server
  function fetchCalendarSettings(date) {
    const year = date.getFullYear()
    const month = date.getMonth() + 1 // JavaScript months are 0-based

    // Show loading indicator if needed
    if (calendarDays) {
      calendarDays.innerHTML = '<div class="loading-indicator">Loading calendar...</div>'
    }

    fetch(`api/calendar_settings.php?month=${month}&year=${year}`)
      .then((response) => {
        if (!response.ok) {
          throw new Error("Network response was not ok")
        }
        return response.json()
      })
      .then((data) => {
        calendarSettings = data.calendar_settings || {}
        appointmentCounts = data.appointments || {}

        // Log the data for debugging
        console.log("Calendar settings loaded:", calendarSettings)

        // Generate calendar with the fetched data
        generateCalendar(date)
      })
      .catch((error) => {
        console.error("Error fetching calendar settings:", error)

        // Show error message in calendar
        if (calendarDays) {
          calendarDays.innerHTML = '<div class="error-message">Failed to load calendar data. Please try again.</div>'
        }

        // Generate calendar anyway, but without admin settings
        generateCalendar(date)
      })
  }

  // Add item to cart
  function addToCart(id, name, price) {
    const existingItem = cart.find((item) => item.id === id)

    if (existingItem) {
      existingItem.quantity++
    } else {
      cart.push({
        id: id,
        name: name,
        price: price,
        quantity: 1,
      })
    }
  }

  // Update cart display
  function updateCart() {
    if (!cartCount || !cartItems) return

    // Update cart count
    cartCount.textContent = cart.reduce((total, item) => total + item.quantity, 0)

    // Clear cart items
    cartItems.innerHTML = ""

    if (cart.length === 0) {
      cartItems.innerHTML = '<div class="empty-cart-message">Your cart is empty</div>'
      if (cartSubtotal) cartSubtotal.textContent = "₱0.00"
      if (document.getElementById("transportation-fee"))
        document.getElementById("transportation-fee").textContent = "₱0.00"
      if (cartTotal) cartTotal.textContent = "₱0.00"
      if (depositAmount) depositAmount.textContent = "₱0.00"
      if (balanceDue) balanceDue.textContent = "₱0.00"

      // Hide service location container when cart is empty
      const serviceLocationContainer = document.getElementById("service-location-container")
      if (serviceLocationContainer) {
        serviceLocationContainer.style.display = "none"
      }
      return
    }

    // Show service location container when cart has items
    const serviceLocationContainer = document.getElementById("service-location-container")
    if (serviceLocationContainer) {
      serviceLocationContainer.style.display = "block"
    }

    // Add items to cart
    cart.forEach((item) => {
      const cartItem = document.createElement("div")
      cartItem.classList.add("cart-item")

      cartItem.innerHTML = `
            <div class="cart-item-details">
                <div class="cart-item-name">${item.name}</div>
                <div class="cart-item-price">₱${item.price.toFixed(2)}</div>
            </div>
            <div class="cart-item-quantity">
                <button class="quantity-btn minus" data-id="${item.id}">-</button>
                <span>${item.quantity}</span>
                <button class="quantity-btn plus" data-id="${item.id}">+</button>
                <span class="cart-item-remove" data-id="${item.id}"><i class="fas fa-trash"></i></span>
            </div>
        `

      cartItems.appendChild(cartItem)
    })

    // Add event listeners to quantity buttons
    document.querySelectorAll(".quantity-btn.minus").forEach((button) => {
      button.addEventListener("click", function () {
        const id = this.getAttribute("data-id")
        decreaseQuantity(id)
        updateCart()
      })
    })

    document.querySelectorAll(".quantity-btn.plus").forEach((button) => {
      button.addEventListener("click", function () {
        const id = this.getAttribute("data-id")
        increaseQuantity(id)
        updateCart()
      })
    })

    document.querySelectorAll(".cart-item-remove").forEach((button) => {
      button.addEventListener("click", function () {
        const id = this.getAttribute("data-id")
        removeFromCart(id)
        updateCart()
      })
    })

    // Update totals
    updateCartTotals()
  }

  // Calculate subtotal
  function calculateSubtotal() {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0)
  }

  // Calculate transportation fee
  function calculateTransportationFee() {
    const serviceTypeElement = document.getElementById("service-type")
    if (!serviceTypeElement) return 0

    const serviceType = serviceTypeElement.value
    if (serviceType !== "home") {
      return 0
    }

    const locationAreaElement = document.getElementById("location-area")
    if (!locationAreaElement) return 0

    const locationArea = locationAreaElement.value

    switch (locationArea) {
      case "canlubang":
        return 0
      case "calamba":
        return 500
      case "outside":
        const customFeeElement = document.getElementById("custom-fee")
        if (!customFeeElement) return 1000
        const customFee = Number.parseFloat(customFeeElement.value) || 1000
        return customFee
      default:
        return 0
    }
  }

  // Calculate total
  function calculateTotal() {
    const subtotal = calculateSubtotal()
    const transportationFee = calculateTransportationFee()
    return subtotal + transportationFee
  }

  // Update deposit info
  function updateDepositInfo() {
    if (!depositAmount || !balanceDue) return

    const total = calculateTotal()
    const deposit = total * 0.5

    depositAmount.textContent = `₱${deposit.toFixed(2)}`
    balanceDue.textContent = `₱${deposit.toFixed(2)}`
  }

  // Add this function to update cart totals
  function updateCartTotals() {
    if (!cartSubtotal || !cartTotal) return

    const subtotal = calculateSubtotal()
    const transportationFee = calculateTransportationFee()
    const total = subtotal + transportationFee

    cartSubtotal.textContent = `₱${subtotal.toFixed(2)}`

    // Show/hide transportation fee
    const transportationFeeContainer = document.getElementById("transportation-fee-container")
    const transportationFeeElement = document.getElementById("transportation-fee")

    if (transportationFeeContainer && transportationFeeElement) {
      if (transportationFee > 0) {
        transportationFeeContainer.style.display = "flex"
        transportationFeeElement.textContent = `₱${transportationFee.toFixed(2)}`
      } else {
        transportationFeeContainer.style.display = "none"
      }
    }

    cartTotal.textContent = `₱${total.toFixed(2)}`

    updateDepositInfo()
  }

  // Increase item quantity
  function increaseQuantity(id) {
    const item = cart.find((item) => item.id === id)
    if (item) {
      item.quantity++
    }
  }

  // Decrease item quantity
  function decreaseQuantity(id) {
    const item = cart.find((item) => item.id === id)
    if (item) {
      item.quantity--
      if (item.quantity === 0) {
        removeFromCart(id)
      }
    }
  }

  // Remove item from cart
  function removeFromCart(id) {
    cart = cart.filter((item) => item.id !== id)
  }

  // Prepare checkout
  function prepareCheckout() {
    const checkoutItems = document.getElementById("checkout-items")
    if (!checkoutItems) return

    checkoutItems.innerHTML = ""

    cart.forEach((item) => {
      const checkoutItem = document.createElement("div")
      checkoutItem.classList.add("checkout-item")

      checkoutItem.innerHTML = `
            <div class="checkout-item-name">${item.name} x${item.quantity}</div>
            <div class="checkout-item-price">₱${(item.price * item.quantity).toFixed(2)}</div>
        `

      checkoutItems.appendChild(checkoutItem)
    })

    const subtotal = calculateSubtotal()
    const transportationFee = calculateTransportationFee()
    const total = subtotal + transportationFee

    document.getElementById("checkout-subtotal").textContent = `₱${subtotal.toFixed(2)}`

    // Show/hide transportation fee in checkout
    const checkoutTransportationContainer = document.getElementById("checkout-transportation-container")
    const checkoutTransportation = document.getElementById("checkout-transportation")

    if (checkoutTransportationContainer && checkoutTransportation) {
      if (transportationFee > 0) {
        checkoutTransportationContainer.style.display = "flex"
        checkoutTransportation.textContent = `₱${transportationFee.toFixed(2)}`
      } else {
        checkoutTransportationContainer.style.display = "none"
      }
    }

    document.getElementById("checkout-total").textContent = `₱${total.toFixed(2)}`

    const checkoutDepositInfo = document.getElementById("checkout-deposit-info")

    if (depositPayment && depositPayment.checked) {
      checkoutDepositInfo.classList.remove("hidden")
      const deposit = total * 0.5
      document.getElementById("checkout-deposit").textContent = `₱${deposit.toFixed(2)}`
      document.getElementById("checkout-balance").textContent = `₱${deposit.toFixed(2)}`
    } else {
      checkoutDepositInfo.classList.add("hidden")
    }

    // Set min date for appointment
    const today = new Date()
    const yyyy = today.getFullYear()
    const mm = String(today.getMonth() + 1).padStart(2, "0")
    const dd = String(today.getDate()).padStart(2, "0")
    appointmentDate.min = `${yyyy}-${mm}-${dd}`

    // Reset appointment time
    appointmentTime.innerHTML = '<option value="">Select a date first</option>'

    // Add event listener to appointment date
    appointmentDate.addEventListener("change", function () {
      if (this.value) {
        generateTimeSlots(new Date(this.value))
      }
    })

    // Copy service location details to checkout
    const serviceType = document.getElementById("service-type").value
    document.getElementById("checkout-service-type").value = serviceType

    // Show/hide location details in checkout
    const checkoutLocationContainer = document.getElementById("checkout-location-container")
    checkoutLocationContainer.style.display = "block"

    const checkoutLocationDetails = document.getElementById("checkout-location-details")
    if (serviceType === "home") {
      checkoutLocationDetails.style.display = "block"

      // Copy location area
      const locationArea = document.getElementById("location-area").value
      document.getElementById("checkout-location-area").value = locationArea

      // Show/hide custom fee input
      const checkoutCustomFeeContainer = document.getElementById("checkout-custom-fee-container")
      if (locationArea === "outside") {
        checkoutCustomFeeContainer.style.display = "block"
        // Copy custom fee value
        const customFee = document.getElementById("custom-fee").value
        document.getElementById("checkout-custom-fee").value = customFee
      } else {
        checkoutCustomFeeContainer.style.display = "none"
      }
    } else {
      checkoutLocationDetails.style.display = "none"
    }
  }

  // Generate calendar
  function generateCalendar(date) {
    if (!calendarDays || !currentMonthElement) return

    const year = date.getFullYear()
    const month = date.getMonth()

    // Set current month text
    currentMonthElement.textContent = `${date.toLocaleString("default", { month: "long" })} ${year}`

    // Clear calendar days
    calendarDays.innerHTML = ""

    // Get first day of month
    const firstDay = new Date(year, month, 1)
    const lastDay = new Date(year, month + 1, 0)

    // Get day of week for first day (0 = Sunday, 6 = Saturday)
    const firstDayIndex = firstDay.getDay()

    // Get number of days in month
    const daysInMonth = lastDay.getDate()

    // Get number of days in previous month
    const prevLastDay = new Date(year, month, 0).getDate()

    // Get today's date
    const today = new Date()

    // Add days from previous month
    for (let i = firstDayIndex; i > 0; i--) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("calendar-day", "other-month")
      dayElement.textContent = prevLastDay - i + 1
      calendarDays.appendChild(dayElement)
    }

    // Add days for current month
    for (let i = 1; i <= daysInMonth; i++) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("calendar-day")
      dayElement.textContent = i

      // Format date string for comparison with calendar settings
      const dateStr = `${year}-${String(month + 1).padStart(2, "0")}-${String(i).padStart(2, "0")}`

      // Check if day is today
      if (year === today.getFullYear() && month === today.getMonth() && i === today.getDate()) {
        dayElement.classList.add("today")
      }

      // Check if day is in the past
      const currentDate = new Date(year, month, i)
      if (currentDate < new Date(today.getFullYear(), today.getMonth(), today.getDate())) {
        dayElement.classList.add("unavailable")
      }
      // Check if day has admin settings
      else if (calendarSettings[dateStr]) {
        const status = calendarSettings[dateStr].status

        if (status === "day-off") {
          dayElement.classList.add("unavailable", "day-off")
          dayElement.setAttribute("title", "Day Off")
        } else if (status === "full") {
          dayElement.classList.add("unavailable", "full-sched")
          dayElement.setAttribute("title", "Fully Booked")
        } else if (status === "salon") {
          // For salon service days
          dayElement.classList.add("available", "salon-service")
          dayElement.setAttribute("title", "Salon Service Only")
          dayElement.setAttribute("data-service-type", status)

          dayElement.addEventListener("click", function () {
            // Remove selected class from all days
            document.querySelectorAll(".calendar-day").forEach((day) => {
              day.classList.remove("selected")
            })

            // Add selected class to clicked day
            this.classList.add("selected")

            // Set selected date
            selectedDate = new Date(year, month, i)

            // Generate time slots
            generateTimeSlots(selectedDate, this.getAttribute("data-service-type"))
          })
        } else if (status === "home") {
          // For home service days
          dayElement.classList.add("available", "home-service")
          dayElement.setAttribute("title", "Home Service Only")
          dayElement.setAttribute("data-service-type", status)

          dayElement.addEventListener("click", function () {
            // Remove selected class from all days
            document.querySelectorAll(".calendar-day").forEach((day) => {
              day.classList.remove("selected")
            })

            // Add selected class to clicked day
            this.classList.add("selected")

            // Set selected date
            selectedDate = new Date(year, month, i)

            // Generate time slots
            generateTimeSlots(selectedDate, this.getAttribute("data-service-type"))
          })
        }
      }
      // Check if it's Sunday (day 0) and not explicitly set as available
      else if (currentDate.getDay() === 0) {
        dayElement.classList.add("unavailable")
        dayElement.setAttribute("title", "Day Off (Sunday)")
      }
      // Otherwise, it's available
      else {
        dayElement.classList.add("available")

        dayElement.addEventListener("click", function () {
          // Remove selected class from all days
          document.querySelectorAll(".calendar-day").forEach((day) => {
            day.classList.remove("selected")
          })

          // Add selected class to clicked day
          this.classList.add("selected")

          // Set selected date
          selectedDate = new Date(year, month, i)

          // Generate time slots
          generateTimeSlots(selectedDate)
        })
      }

      // Add appointment count indicator if there are appointments
      if (appointmentCounts[dateStr] && appointmentCounts[dateStr] > 0) {
        const countBadge = document.createElement("span")
        countBadge.classList.add("appointment-count")
        countBadge.textContent = appointmentCounts[dateStr]
        dayElement.appendChild(countBadge)
      }

      calendarDays.appendChild(dayElement)
    }

    // Add days from next month
    const daysAfterMonth = 42 - (firstDayIndex + daysInMonth)
    for (let i = 1; i <= daysAfterMonth; i++) {
      const dayElement = document.createElement("div")
      dayElement.classList.add("calendar-day", "other-month")
      dayElement.textContent = i
      calendarDays.appendChild(dayElement)
    }
  }

  // Generate time slots
  // Update the generateTimeSlots function to respect admin settings

  function generateTimeSlots(date, serviceType) {
    if (!timeSlots || !selectedDateElement) return

    // Format date for display
    selectedDateElement.textContent = formatDate(date)

    // Clear time slots
    timeSlots.innerHTML = ""

    // Format date string for comparison with calendar settings
    const dateStr = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`

    // Check if this date has specific settings
    const dateSettings = calendarSettings[dateStr]

    // Add a note about service type if applicable
    if (serviceType) {
      const serviceNote = document.createElement("div")
      serviceNote.classList.add("service-type-note")
      serviceNote.textContent =
        serviceType === "salon"
          ? "Note: This day is for salon services only."
          : "Note: This day is for home services only."
      timeSlots.appendChild(serviceNote)
    }

    // If it's a day off or fully booked, show message
    if (dateSettings && (dateSettings.status === "day-off" || dateSettings.status === "full")) {
      const unavailableMessage = document.createElement("div")
      unavailableMessage.classList.add("unavailable-message")
      unavailableMessage.textContent =
        dateSettings.status === "day-off" ? "This day is not available for bookings." : "This day is fully booked."

      // Add notes from admin if available
      if (dateSettings.notes) {
        const notesElement = document.createElement("div")
        notesElement.classList.add("admin-notes")
        notesElement.textContent = `Note from salon: ${dateSettings.notes}`
        unavailableMessage.appendChild(notesElement)
      }

      timeSlots.appendChild(unavailableMessage)
      return
    }

    // Generate time slots from 9 AM to 5 PM
    const startHour = 9
    const endHour = 17

    // Get day of week (0 = Sunday, 6 = Saturday)
    const dayOfWeek = date.getDay()

    for (let hour = startHour; hour <= endHour; hour++) {
      for (let minute = 0; minute < 60; minute += 30) {
        if (hour === endHour && minute > 0) continue

        const timeSlot = document.createElement("div")
        timeSlot.classList.add("time-slot")

        const hourFormatted = hour % 12 === 0 ? 12 : hour % 12
        const amPm = hour < 12 ? "AM" : "PM"
        const minuteFormatted = minute === 0 ? "00" : minute

        const timeString = `${hourFormatted}:${minuteFormatted} ${amPm}`
        timeSlot.textContent = timeString

        // Randomly mark some time slots as unavailable (for demo purposes)
        // In a real app, you would check against booked appointments in the database
        if (Math.random() < 0.3) {
          timeSlot.classList.add("unavailable")
        } else {
          timeSlot.addEventListener("click", function () {
            // Remove selected class from all time slots
            document.querySelectorAll(".time-slot").forEach((slot) => {
              slot.classList.remove("selected")
            })

            // Add selected class to clicked time slot
            this.classList.add("selected")

            // Set selected time slot
            selectedTimeSlot = timeString

            // Update appointment time in checkout
            updateAppointmentTime(date, timeString)
          })
        }

        timeSlots.appendChild(timeSlot)
      }
    }

    // Also update the appointment date in checkout
    if (appointmentDate) {
      const yyyy = date.getFullYear()
      const mm = String(date.getMonth() + 1).padStart(2, "0")
      const dd = String(date.getDate()).padStart(2, "0")
      appointmentDate.value = `${yyyy}-${mm}-${dd}`

      // Generate time slots for checkout
      generateCheckoutTimeSlots(date, serviceType)
    }
  }

  // Generate time slots for checkout
  function generateCheckoutTimeSlots(date, serviceType) {
    if (!appointmentTime) return

    // Clear time slots
    appointmentTime.innerHTML = ""

    // Generate time slots from 9 AM to 5 PM
    const startHour = 9
    const endHour = 17

    // Add default option
    const defaultOption = document.createElement("option")
    defaultOption.value = ""
    defaultOption.textContent = "Select a time"
    appointmentTime.appendChild(defaultOption)

    // Format date string for comparison with calendar settings
    const dateStr = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`

    // Check if this date has specific settings
    const dateSettings = calendarSettings[dateStr]

    // If it's a day off or fully booked, don't add time slots
    if (dateSettings && (dateSettings.status === "day-off" || dateSettings.status === "full")) {
      return
    }

    for (let hour = startHour; hour <= endHour; hour++) {
      for (let minute = 0; minute < 60; minute += 30) {
        if (hour === endHour && minute > 0) continue

        const hourFormatted = hour % 12 === 0 ? 12 : hour % 12
        const amPm = hour < 12 ? "AM" : "PM"
        const minuteFormatted = minute === 0 ? "00" : minute

        const timeString = `${hourFormatted}:${minuteFormatted} ${amPm}`

        // Randomly mark some time slots as unavailable (for demo purposes)
        // In a real app, you would check against booked appointments in the database
        if (Math.random() < 0.3) continue

        const option = document.createElement("option")
        option.value = timeString
        option.textContent = timeString

        appointmentTime.appendChild(option)
      }
    }
  }

  // Update appointment time in checkout
  function updateAppointmentTime(date, timeString) {
    if (appointmentDate && appointmentTime) {
      const yyyy = date.getFullYear()
      const mm = String(date.getMonth() + 1).padStart(2, "0")
      const dd = String(date.getDate()).padStart(2, "0")
      appointmentDate.value = `${yyyy}-${mm}-${dd}`

      // Find or create option for time
      let option = Array.from(appointmentTime.options).find((opt) => opt.value === timeString)

      if (!option) {
        option = document.createElement("option")
        option.value = timeString
        option.textContent = timeString
        appointmentTime.appendChild(option)
      }

      appointmentTime.value = timeString
    }
  }

  // Format date for display
  function formatDate(date) {
    const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" }
    return date.toLocaleDateString("en-US", options)
  }

  // Close dropdowns when clicking outside
  document.addEventListener("click", (e) => {
    if (
      notificationIcon &&
      notificationDropdown &&
      !notificationIcon.contains(e.target) &&
      !notificationDropdown.contains(e.target)
    ) {
      notificationDropdown.style.display = "none"
    }

    if (profileIcon && profileDropdown && !profileIcon.contains(e.target) && !profileIcon.contains(e.target)) {
      profileDropdown.style.display = "none"
    }
  })

  // Function to set active page
  function setActivePage(pageId) {
    // Skip if elements don't exist
    if (!document.querySelector(`[data-page="${pageId}"]`) || !document.getElementById(`${pageId}-page`)) {
      return
    }

    // Remove active class from all nav items and pages
    navItems.forEach((navItem) => navItem.classList.remove("active"))
    pages.forEach((page) => page.classList.remove("active"))

    // Add active class to selected nav item and page
    document.querySelector(`[data-page="${pageId}"]`).classList.add("active")
    document.getElementById(`${pageId}-page`).classList.add("active")

    // Save active page to localStorage
    localStorage.setItem("activePage", pageId)
  }

  // Add a function to refresh calendar data periodically
  function setupCalendarRefresh() {
    // Refresh calendar data every 5 minutes
    setInterval(
      () => {
        if (calendarDays && currentDate) {
          fetchCalendarSettings(currentDate)
        }
      },
      5 * 60 * 1000,
    ) // 5 minutes in milliseconds
  }
})

document.addEventListener("DOMContentLoaded", () => {
  // Initialize service type and location area event listeners
  const serviceTypeSelect = document.getElementById("service-type")
  const locationDetails = document.getElementById("location-details")
  const locationAreaSelect = document.getElementById("location-area")
  const customFeeContainer = document.getElementById("custom-fee-container")
  const customFeeInput = document.getElementById("custom-fee")
  const transportationFeeContainer = document.getElementById("transportation-fee-container")

  // Initialize checkout elements
  const checkoutServiceType = document.getElementById("checkout-service-type")
  const checkoutLocationDetails = document.getElementById("checkout-location-details")
  const checkoutLocationArea = document.getElementById("checkout-location-area")
  const checkoutCustomFeeContainer = document.getElementById("checkout-custom-fee-container")
  const checkoutCustomFee = document.getElementById("checkout-custom-fee")

  // Service type change
  if (serviceTypeSelect) {
    serviceTypeSelect.addEventListener("change", function () {
      if (this.value === "home") {
        if (locationDetails) locationDetails.style.display = "block"
        if (transportationFeeContainer) {
          // Only show transportation fee if location area is not Canlubang
          const locationArea = locationAreaSelect ? locationAreaSelect.value : "canlubang"
          if (locationArea === "canlubang") {
            transportationFeeContainer.style.display = "none"
          } else {
            transportationFeeContainer.style.display = "flex"
          }
        }
      } else {
        if (locationDetails) locationDetails.style.display = "none"
        if (transportationFeeContainer) transportationFeeContainer.style.display = "none"
      }

      // Update cart totals
      if (typeof updateCartTotals === "function") {
        updateCartTotals()
      }
    })
  }

  // Location area change
  if (locationAreaSelect) {
    locationAreaSelect.addEventListener("change", function () {
      if (customFeeContainer) {
        if (this.value === "outside") {
          customFeeContainer.style.display = "block"
        } else {
          customFeeContainer.style.display = "none"
        }
      }

      // Show/hide transportation fee based on location
      if (transportationFeeContainer && serviceTypeSelect && serviceTypeSelect.value === "home") {
        if (this.value === "canlubang") {
          transportationFeeContainer.style.display = "none"
        } else {
          transportationFeeContainer.style.display = "flex"
        }
      }

      // Update cart totals
      if (typeof updateCartTotals === "function") {
        updateCartTotals()
      }
    })
  }

  // Custom fee change
  if (customFeeInput) {
    customFeeInput.addEventListener("input", () => {
      // Update cart totals
      if (typeof updateCartTotals === "function") {
        updateCartTotals()
      }
    })
  }

  // Checkout service type change
  if (checkoutServiceType) {
    checkoutServiceType.addEventListener("change", function () {
      if (checkoutLocationDetails) {
        if (this.value === "home") {
          checkoutLocationDetails.style.display = "block"
        } else {
          checkoutLocationDetails.style.display = "none"
        }
      }

      // Update service type in cart as well
      if (serviceTypeSelect) {
        serviceTypeSelect.value = this.value

        // Trigger change event on cart service type
        const event = new Event("change")
        serviceTypeSelect.dispatchEvent(event)
      }
    })
  }

  // Checkout location area change
  if (checkoutLocationArea) {
    checkoutLocationArea.addEventListener("change", function () {
      if (checkoutCustomFeeContainer) {
        if (this.value === "outside") {
          checkoutCustomFeeContainer.style.display = "block"
        } else {
          checkoutCustomFeeContainer.style.display = "none"
        }
      }

      // Update location area in cart as well
      if (locationAreaSelect) {
        locationAreaSelect.value = this.value

        // Trigger change event on cart location area
        const event = new Event("change")
        locationAreaSelect.dispatchEvent(event)
      }
    })
  }

  // Checkout custom fee change
  if (checkoutCustomFee) {
    checkoutCustomFee.addEventListener("input", function () {
      // Update custom fee in cart as well
      if (customFeeInput) {
        customFeeInput.value = this.value

        // Trigger input event on cart custom fee
        const event = new Event("input")
        customFeeInput.dispatchEvent(event)
      }
    })
  }

  // Handle add to cart events
  document.addEventListener("addToCart", (e) => {
    const item = e.detail

    // Get current cart from localStorage or initialize empty array
    const cart = JSON.parse(localStorage.getItem("salonCart")) || []

    // Check if item already exists in cart
    const existingItemIndex = cart.findIndex((cartItem) => cartItem.id === item.id)

    if (existingItemIndex > -1) {
      // Update quantity if item exists
      cart[existingItemIndex].quantity += item.quantity
    } else {
      // Add new item to cart
      cart.push(item)
    }

    // Save updated cart to localStorage
    localStorage.setItem("salonCart", JSON.stringify(cart))

    // Update cart UI
    updateCartUI()

    // Show cart notification
    const cartCount = document.querySelector(".cart-count")
    if (cartCount) {
      cartCount.textContent = cart.length
      cartCount.classList.add("bounce")
      setTimeout(() => {
        cartCount.classList.remove("bounce")
      }, 300)
    }
  })

  // Function to update cart UI
  function updateCartUI() {
    const cart = JSON.parse(localStorage.getItem("salonCart")) || []
    const cartItemsContainer = document.querySelector(".cart-items")
    const cartTotal = document.querySelector(".cart-total-amount")

    if (cartItemsContainer) {
      // Clear current cart items
      cartItemsContainer.innerHTML = ""

      if (cart.length === 0) {
        cartItemsContainer.innerHTML = '<div class="empty-cart">Your cart is empty</div>'
        if (cartTotal) cartTotal.textContent = "₱0.00"
        return
      }

      // Calculate total
      let total = 0

      // Add each item to cart UI
      cart.forEach((item, index) => {
        const itemTotal = item.price * item.quantity
        total += itemTotal

        const cartItemElement = document.createElement("div")
        cartItemElement.className = "cart-item"
        cartItemElement.innerHTML = `
                    <div class="cart-item-details">
                        <h4>${item.name}</h4>
                        <div class="cart-item-price">₱${Number.parseFloat(item.price).toFixed(2)}</div>
                    </div>
                    <div class="cart-item-actions">
                        <button class="quantity-btn minus" data-index="${index}">-</button>
                        <span class="quantity">${item.quantity}</span>
                        <button class="quantity-btn plus" data-index="${index}">+</button>
                        <button class="remove-btn" data-index="${index}">×</div>
                    </div>
                `

        cartItemsContainer.appendChild(cartItemElement)
      })

      // Update total
      if (cartTotal) cartTotal.textContent = `₱${total.toFixed(2)}`

      // Add event listeners to quantity buttons
      document.querySelectorAll(".quantity-btn.minus").forEach((btn) => {
        btn.addEventListener("click", function () {
          const index = Number.parseInt(this.getAttribute("data-index"))
          decreaseQuantity(index)
        })
      })

      document.querySelectorAll(".quantity-btn.plus").forEach((btn) => {
        btn.addEventListener("click", function () {
          const index = Number.parseInt(this.getAttribute("data-index"))
          increaseQuantity(index)
        })
      })

      document.querySelectorAll(".remove-btn").forEach((btn) => {
        btn.addEventListener("click", function () {
          const index = Number.parseInt(this.getAttribute("data-index"))
          removeItem(index)
        })
      })
    }
  }

  // Function to decrease item quantity
  function decreaseQuantity(index) {
    const cart = JSON.parse(localStorage.getItem("salonCart")) || []

    if (cart[index].quantity > 1) {
      cart[index].quantity -= 1
      localStorage.setItem("salonCart", JSON.stringify(cart))
      updateCartUI()
    } else {
      removeItem(index)
    }
  }

  // Function to increase item quantity
  function increaseQuantity(index) {
    const cart = JSON.parse(localStorage.getItem("salonCart")) || []

    cart[index].quantity += 1
    localStorage.setItem("salonCart", JSON.stringify(cart))
    updateCartUI()
  }

  // Function to remove item from cart
  function removeItem(index) {
    const cart = JSON.parse(localStorage.getItem("salonCart")) || []

    cart.splice(index, 1)
    localStorage.setItem("salonCart", JSON.stringify(cart))

    // Update cart count
    const cartCount = document.querySelector(".cart-count")
    if (cartCount) {
      cartCount.textContent = cart.length
    }

    updateCartUI()
  }

  // Initialize cart UI on page load
  updateCartUI()

  // Initialize service type on page load
  if (serviceTypeSelect) {
    // Trigger change event to set initial state
    const event = new Event("change")
    serviceTypeSelect.dispatchEvent(event)
  }
})

// Function to calculate transportation fee
function calculateTransportationFee() {
  const serviceTypeElement = document.getElementById("service-type")
  if (!serviceTypeElement) return 0

  const serviceType = serviceTypeElement.value
  if (serviceType !== "home") {
    return 0
  }

  const locationAreaElement = document.getElementById("location-area")
  if (!locationAreaElement) return 0

  const locationArea = locationAreaElement.value

  switch (locationArea) {
    case "canlubang":
      return 0
    case "calamba":
      return 500
    case "outside":
      const customFeeElement = document.getElementById("custom-fee")
      if (!customFeeElement) return 1000
      const customFee = Number.parseFloat(customFeeElement.value) || 1000
      return customFee
    default:
      return 0
  }
}

// Function to update cart totals
function updateCartTotals() {
  const cartSubtotal = document.getElementById("cart-subtotal")
  const cartTotal = document.getElementById("cart-total")
  const transportationFeeContainer = document.getElementById("transportation-fee-container")
  const transportationFeeElement = document.getElementById("transportation-fee")
  const depositAmount = document.getElementById("deposit-amount")
  const balanceDue = document.getElementById("balance-due")

  if (!cartSubtotal || !cartTotal) return

  // Calculate subtotal from cart items
  let subtotal = 0
  const cartItems = document.querySelectorAll(".cart-item")
  cartItems.forEach((item) => {
    const priceText = item.querySelector(".cart-item-price").textContent
    const price = Number.parseFloat(priceText.replace("₱", ""))
    const quantity = Number.parseInt(item.querySelector(".cart-item-quantity span").textContent)
    subtotal += price * quantity
  })

  // If no items found, try to get subtotal from displayed value
  if (subtotal === 0 && cartSubtotal) {
    const subtotalText = cartSubtotal.textContent
    subtotal = Number.parseFloat(subtotalText.replace("₱", "")) || 0
  }

  const transportationFee = calculateTransportationFee()
  const total = subtotal + transportationFee

  if (cartSubtotal) cartSubtotal.textContent = `₱${subtotal.toFixed(2)}`

  // Show/hide transportation fee
  if (transportationFeeContainer && transportationFeeElement) {
    if (transportationFee > 0) {
      transportationFeeContainer.style.display = "flex"
      transportationFeeElement.textContent = `₱${transportationFee.toFixed(2)}`
    } else {
      transportationFeeContainer.style.display = "none"
    }
  }

  if (cartTotal) cartTotal.textContent = `₱${total.toFixed(2)}`

  // Update deposit info
  if (depositAmount && balanceDue) {
    const deposit = total * 0.5
    depositAmount.textContent = `₱${deposit.toFixed(2)}`
    balanceDue.textContent = `₱${deposit.toFixed(2)}`
  }

  // Update checkout totals if checkout is open
  updateCheckoutTotals(subtotal, transportationFee, total)
}

// Function to update checkout totals
function updateCheckoutTotals(subtotal, transportationFee, total) {
  const checkoutSubtotal = document.getElementById("checkout-subtotal")
  const checkoutTransportationContainer = document.getElementById("checkout-transportation-container")
  const checkoutTransportation = document.getElementById("checkout-transportation")
  const checkoutTotal = document.getElementById("checkout-total")
  const checkoutDeposit = document.getElementById("checkout-deposit")
  const checkoutBalance = document.getElementById("checkout-balance")

  if (checkoutSubtotal) checkoutSubtotal.textContent = `₱${subtotal.toFixed(2)}`

  if (checkoutTransportationContainer && checkoutTransportation) {
    if (transportationFee > 0) {
      checkoutTransportationContainer.style.display = "flex"
      checkoutTransportation.textContent = `₱${transportationFee.toFixed(2)}`
    } else {
      checkoutTransportationContainer.style.display = "none"
    }
  }

  if (checkoutTotal) checkoutTotal.textContent = `₱${total.toFixed(2)}`

  if (checkoutDeposit && checkoutBalance) {
    const deposit = total * 0.5
    checkoutDeposit.textContent = `₱${deposit.toFixed(2)}`
    checkoutBalance.textContent = `₱${deposit.toFixed(2)}`
  }
}

// Initialize on page load
document.addEventListener("DOMContentLoaded", () => {
  const serviceTypeSelect = document.getElementById("service-type")
  if (serviceTypeSelect) {
    // Set initial state
    const event = new Event("change")
    serviceTypeSelect.dispatchEvent(event)
  }

  // Update cart totals
  updateCartTotals()
})
