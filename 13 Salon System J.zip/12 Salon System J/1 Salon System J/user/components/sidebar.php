<!-- Sidebar -->
<aside class="sidebar">
    <nav>
        <ul>
            <li class="active" data-page="services"><i class="fas fa-cut"></i> Services</li>
            <li data-page="appointments"><i class="fas fa-calendar-alt"></i> Appointments</li>
            <li data-page="profile"><i class="fas fa-user"></i> Profile</li>
            <li data-page="history"><i class="fas fa-history"></i> History</li>
            <li data-page="queue"><i class="fas fa-list-ol"></i> My Queue</li>
        </ul>
    </nav>
</aside>
