<!-- Header -->
<header>
    <div class="logo">
        <h1>Jose Maestra Barbera Salon</h1>
    </div>
    <div class="header-actions">
        <div class="clock" id="clock"></div>
       
       <script>
    function updateClock() {
        const clock = document.getElementById("clock");
        const now = new Date();
        let hours = now.getHours();
        const minutes = now.getMinutes().toString().padStart(2, '0');
        const seconds = now.getSeconds().toString().padStart(2, '0');
        const ampm = hours >= 12 ? 'PM' : 'AM';

        hours = hours % 12;
        hours = hours ? hours : 12; // hour '0' should be '12'

        const formattedTime = `${hours.toString().padStart(2, '0')}:${minutes}:${seconds} ${ampm}`;
        clock.textContent = formattedTime;
    }

    setInterval(updateClock, 1000); // Update every second
    updateClock(); // Initial call
</script>


        <div class="notification-icon" id="notification-icon">
            <i class="fas fa-bell"></i>
            <span class="badge" id="notification-count">3</span>
            <div class="notification-dropdown" id="notification-dropdown">
                <h3>Notifications</h3>
                <div class="notification-item">
                    <p>Your appointment for Hair Coloring is in 2 hours.</p>
                    <span class="notification-time">Just now</span>
                </div>
                <div class="notification-item">
                    <p>Your turn is coming up next! Please be ready.</p>
                    <span class="notification-time">5 min ago</span>
                </div>
                <div class="notification-item">
                    <p>Your appointment for tomorrow has been confirmed.</p>
                    <span class="notification-time">Yesterday</span>
                </div>
            </div>
        </div>
        <div class="cart-icon" id="cart-icon">
            <i class="fas fa-shopping-cart"></i>
            <span class="badge" id="cart-count">0</span>
        </div>
        <div class="profile-icon" id="profile-icon">
            <img src="/placeholder.svg?height=40&width=40" alt="Profile">
            <div class="profile-dropdown" id="profile-dropdown">
                <a href="#" id="profile-link">Edit Profile</a>
                <a href="#" id="appointments-link">My Appointments</a>
                <a href="#" id="history-link">Booking History</a>
                <a href="/login_register/logout.php" id="logout-link">Logout</a>
            </div>
        </div>
    </div>
</header>
