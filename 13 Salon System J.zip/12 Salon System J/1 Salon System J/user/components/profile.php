<div class="page" id="profile-page">
    <h2>My Profile</h2>
    <?php echo $updateMessage ?? ''; ?>
    <div class="profile-container">
        <div class="profile-image">
            <img src="/placeholder.svg?height=150&width=150" alt="Profile Picture">
            <button class="change-photo-btn">Change Photo</button>
        </div>
        <div class="profile-form">
            <form method="POST" action="">
                <div class="form-group">
                    <label for="first_name">First Name</label>
                    <input type="text" id="first_name" name="first_name"
                        value="<?php echo htmlspecialchars($first_name); ?>">
                </div>
                <div class="form-group">
                    <label for="last_name">Last Name</label>
                    <input type="text" id="last_name" name="last_name"
                        value="<?php echo htmlspecialchars($last_name); ?>">
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" value="<?php echo htmlspecialchars($email); ?>"
                        readonly>
                    <small>Email cannot be changed</small>
                </div>
                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="tel" id="phone" name="phone"
                        value="<?php echo htmlspecialchars($phone ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label for="address">Address</label>
                    <textarea id="address"
                        name="address"><?php echo htmlspecialchars($address ?? ''); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="preferences">Service Preferences</label>
                    <textarea id="preferences"
                        name="preferences"><?php echo htmlspecialchars($_SESSION['preferences'] ?? ''); ?></textarea>
                </div>
                <button type="submit" name="update_profile" class="save-profile-btn">Save
                    Changes</button>
            </form>
        </div>
    </div>
</div>
