document.addEventListener("DOMContentLoaded", () => {
  const toggleSidebarBtn = document.querySelector(".toggle-sidebar-btn")
  const sidebar = document.querySelector(".sidebar")

  if (toggleSidebarBtn && sidebar) {
    toggleSidebarBtn.addEventListener("click", () => {
      sidebar.classList.toggle("show")
    })
  }

  // Optional: close sidebar when clicking outside (for mobile)
  document.addEventListener("click", (event) => {
    if (
      sidebar &&
      sidebar.classList.contains("show") &&
      !sidebar.contains(event.target) &&
      toggleSidebarBtn &&
      !toggleSidebarBtn.contains(event.target)
    ) {
      sidebar.classList.remove("show")
    }
  })
})
