<?php
// This file will be included in your homepage to fetch services from the database

// Include database connection
include_once 'tools/salondb.php';

/**
 * Get all services from the database, grouped by category
 * 
 * @return array Services grouped by category
 */
function getServicesGroupedByCategory() {
    $conn = getDatabaseConnection();
    $services = [];
    
    // Get all active services
    $query = "SELECT * FROM services WHERE status = 1 ORDER BY category, subcategory, name";
    $result = $conn->query($query);
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Convert database category names to match the frontend category IDs
            $categoryMap = [
                'haircuts' => 'haircut',
                'haircolor' => 'haircolor',
                'rebonding' => 'rebonding',
                'treatment' => 'hairtreatment',
                'nails' => 'nails',
                'braiding' => 'braiding',
                'men' => 'formen',
                'women' => 'forwomen'
            ];
            
            $category = $categoryMap[$row['category']] ?? $row['category'];
            
            // Group services by category
            if (!isset($services[$category])) {
                $services[$category] = [];
            }
            
            $services[$category][] = $row;
        }
    }
    
    $conn->close();
    return $services;
}

/**
 * Get category display name
 * 
 * @param string $categoryId The category ID
 * @return string The display name
 */
function getCategoryDisplayName($categoryId) {
    $displayNames = [
        'haircut' => 'Hair Cut',
        'haircolor' => 'Hair Color',
        'rebonding' => 'Rebonding',
        'hairtreatment' => 'Hair Treatment',
        'nails' => 'Nails',
        'braiding' => 'Braiding',
        'formen' => 'For Men',
        'forwomen' => 'For Women'
    ];
    
    return $displayNames[$categoryId] ?? ucfirst($categoryId);
}

/**
 * Get category icon
 * 
 * @param string $categoryId The category ID
 * @return string The icon class
 */
function getCategoryIcon($categoryId) {
    $icons = [
        'haircut' => 'fas fa-cut',
        'haircolor' => 'fas fa-palette',
        'rebonding' => 'fas fa-magic',
        'hairtreatment' => 'fas fa-pump-soap',
        'nails' => 'fas fa-hand-sparkles',
        'braiding' => 'fas fa-stream',
        'formen' => 'fas fa-male',
        'forwomen' => 'fas fa-female'
    ];
    
    return $icons[$categoryId] ?? 'fas fa-spa';
}
?>
