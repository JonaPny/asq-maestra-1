<?php

if (isset($_GET['status']) && $_GET['status'] === 'success') {
    $success_message = $_GET['message'] ?? "Operation completed successfully!";
}

$page_title = "Services Manager - Salon Admin";
include 'components/header.php';
include 'components/sidebar.php';
include 'components/navbar.php';

// Include database connection
include 'includes/db_connection.php';
$conn = getAdminDatabaseConnection();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        // Add new service
        if ($_POST['action'] === 'add') {
            $name = $_POST['name'];
            $description = $_POST['description'];
            $price = $_POST['price'];
            $duration = $_POST['duration'];
            $category = $_POST['category'];
            $status = $_POST['status'];
            
            $stmt = $conn->prepare("INSERT INTO services (name, description, price, duration, category, status) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssdiis", $name, $description, $price, $duration, $category, $status);
            $stmt->execute();
            $stmt->close();
            
            $success_message = "Service added successfully!";
        }
        
        // Update existing service
        else if ($_POST['action'] === 'update') {
            $id = $_POST['id'];
            $name = $_POST['name'];
            $description = $_POST['description'];
            $price = $_POST['price'];
            $duration = $_POST['duration'];
            $category = $_POST['category'];
            $status = $_POST['status'];
            
            $stmt = $conn->prepare("UPDATE services SET name = ?, description = ?, price = ?, duration = ?, category = ?, status = ? WHERE id = ?");
            $stmt->bind_param("ssdisii", $name, $description, $price, $duration, $category, $status, $id);
            $stmt->execute();
            $stmt->close();
            
            $success_message = "Service updated successfully!";
        }
        
        // Delete service
        else if ($_POST['action'] === 'delete') {
            $id = $_POST['id'];
            
            $stmt = $conn->prepare("DELETE FROM services WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();
            
            $success_message = "Service deleted successfully!";
        }
        header("Location: services.php?status=success&message=" . urlencode($success_message));
        exit;
    }
}

// Get all services
$services = [];
$result = $conn->query("SELECT * FROM services ORDER BY category, name");
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $services[] = $row;
    }
}
$conn->close();
?>

<div class="p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Services Manager</h2>
        <div>
            <button class="btn btn-sm btn-outline-pink" id="add-service-btn">
                <i class="bi bi-plus-circle me-1"></i> Add New Service
            </button>
        </div>
    </div>

    <?php if (isset($success_message)): ?>
    <div class="alert alert-success" id="service-message"><?php echo $success_message; ?></div>
    <?php else: ?>
    <div class="alert alert-success d-none" id="service-message"></div>
    <?php endif; ?>

    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-pink text-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Service Categories</h5>
                    <div class="btn-group" role="group">
                        <button type="button" class="btn btn-sm btn-outline-light active category-filter"
                            data-category="all">All</button>
                        <button type="button" class="btn btn-sm btn-outline-light category-filter"
                            data-category="hair">Hair</button>
                        <button type="button" class="btn btn-sm btn-outline-light category-filter"
                            data-category="makeup">Makeup</button>
                        <button type="button" class="btn btn-sm btn-outline-light category-filter"
                            data-category="spa">Spa</button>
                        <button type="button" class="btn btn-sm btn-outline-light category-filter"
                            data-category="nails">Nails</button>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table mb-0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Service Name</th>
                                    <th>Category</th>
                                    <th>Price</th>
                                    <th>Duration</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="services-table">
                                <!-- Services will be loaded by JavaScript -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'components/modals/service_modal.php'; ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Load services from PHP data
        let servicesData = <?php echo json_encode($services); ?>;
        
        // If no services in database yet, use sample data
        if (servicesData.length === 0) {
            servicesData = [
                {
                    id: 1,
                    name: 'Hair Cut & Style',
                    description: 'Professional haircut and styling by our expert stylists',
                    price: 350.00,
                    duration: 60,
                    category: 'hair',
                    status: 1
                },
                {
                    id: 2,
                    name: 'Hair Color',
                    description: 'Full hair coloring service with premium products',
                    price: 1500.00,
                    duration: 120,
                    category: 'hair',
                    status: 1
                },
                {
                    id: 3,
                    name: 'Manicure & Pedicure',
                    description: 'Complete nail care for hands and feet',
                    price: 500.00,
                    duration: 90,
                    category: 'nails',
                    status: 1
                },
                {
                    id: 4,
                    name: 'Facial Treatment',
                    description: 'Rejuvenating facial treatment for glowing skin',
                    price: 800.00,
                    duration: 60,
                    category: 'spa',
                    status: 1
                },
                {
                    id: 5,
                    name: 'Hot Oil Treatment',
                    description: 'Deep conditioning treatment for healthy hair',
                    price: 600.00,
                    duration: 45,
                    category: 'hair',
                    status: 1
                }
            ];
        }

        // Load services
        function loadServices(category = 'all') {
            const servicesTable = document.getElementById('services-table');
            servicesTable.innerHTML = '';

            const filteredServices = category === 'all'
                ? servicesData
                : servicesData.filter(service => service.category === category);

            filteredServices.forEach(service => {
                const row = document.createElement('tr');

                // Format price
                const formattedPrice = new Intl.NumberFormat('en-PH', {
                    style: 'currency',
                    currency: 'PHP'
                }).format(service.price);

                // Create status badge
                const statusBadge = service.status == 1
                    ? '<span class="badge bg-success">Active</span>'
                    : '<span class="badge bg-secondary">Inactive</span>';

                row.innerHTML = `
                    <td>#${service.id}</td>
                    <td>${service.name}</td>
                    <td>${service.category.charAt(0).toUpperCase() + service.category.slice(1)}</td>
                    <td>${formattedPrice}</td>
                    <td>${service.duration} mins</td>
                    <td>${statusBadge}</td>
                    <td>
                        <button class="btn btn-sm btn-outline-secondary me-1 edit-service" data-service-id="${service.id}">
                            <i class="bi bi-pencil"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger delete-service" data-service-id="${service.id}">
                            <i class="bi bi-trash"></i>
                        </button>
                    </td>
                `;

                servicesTable.appendChild(row);
            });

            // Add event listeners
            document.querySelectorAll('.edit-service').forEach(button => {
                button.addEventListener('click', function () {
                    const serviceId = this.getAttribute('data-service-id');
                    openServiceModal(serviceId);
                });
            });

            document.querySelectorAll('.delete-service').forEach(button => {
                button.addEventListener('click', function () {
                    const serviceId = this.getAttribute('data-service-id');
                    deleteService(serviceId);
                });
            });
        }

        // Initial load
        loadServices();

        // Category filter
        document.querySelectorAll('.category-filter').forEach(button => {
            button.addEventListener('click', function () {
                // Remove active class from all buttons
                document.querySelectorAll('.category-filter').forEach(btn => {
                    btn.classList.remove('active');
                });

                // Add active class to clicked button
                this.classList.add('active');

                // Load services for selected category
                const category = this.getAttribute('data-category');
                loadServices(category);
            });
        });

        // Service modal
        const serviceModal = new bootstrap.Modal(document.getElementById('serviceModal'));

        // Add service button
        document.getElementById('add-service-btn').addEventListener('click', function () {
            openServiceModal();
        });

        function openServiceModal(serviceId = null) {
            // Reset form
            document.getElementById('serviceForm').reset();

            // Set modal title
            document.getElementById('serviceModalTitle').textContent = serviceId ? 'Edit Service' : 'Add New Service';

            if (serviceId) {
                // Find service
                const service = servicesData.find(s => s.id == serviceId);
                if (!service) return;

                // Populate form
                document.getElementById('serviceId').value = service.id;
                document.getElementById('serviceName').value = service.name;
                document.getElementById('serviceDescription').value = service.description;
                document.getElementById('servicePrice').value = service.price;
                document.getElementById('serviceDuration').value = service.duration;
                document.getElementById('serviceCategory').value = service.category;
                document.getElementById('serviceStatus').value = service.status;
                
                // Set form action
                document.getElementById('serviceAction').value = 'update';
            } else {
                // Clear service ID
                document.getElementById('serviceId').value = '';
                
                // Set form action
                document.getElementById('serviceAction').value = 'add';
            }

            // Show modal
            serviceModal.show();
        }

        // Save service
        document.getElementById('saveService').addEventListener('click', function () {
            // Get form values
            const serviceId = document.getElementById('serviceId').value;
            const serviceName = document.getElementById('serviceName').value;
            const serviceDescription = document.getElementById('serviceDescription').value;
            const servicePrice = parseFloat(document.getElementById('servicePrice').value);
            const serviceDuration = parseInt(document.getElementById('serviceDuration').value);
            const serviceCategory = document.getElementById('serviceCategory').value;
            const serviceStatus = parseInt(document.getElementById('serviceStatus').value);
            const serviceAction = document.getElementById('serviceAction').value;

            // Validate form
            if (!serviceName || isNaN(servicePrice) || isNaN(serviceDuration)) {
                alert('Please fill in all required fields');
                return;
            }

            // Create form data for submission
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const actionInput = document.createElement('input');
            actionInput.name = 'action';
            actionInput.value = serviceAction;
            form.appendChild(actionInput);
            
            if (serviceId) {
                const idInput = document.createElement('input');
                idInput.name = 'id';
                idInput.value = serviceId;
                form.appendChild(idInput);
            }
            
            const nameInput = document.createElement('input');
            nameInput.name = 'name';
            nameInput.value = serviceName;
            form.appendChild(nameInput);
            
            const descInput = document.createElement('input');
            descInput.name = 'description';
            descInput.value = serviceDescription;
            form.appendChild(descInput);
            
            const priceInput = document.createElement('input');
            priceInput.name = 'price';
            priceInput.value = servicePrice;
            form.appendChild(priceInput);
            
            const durationInput = document.createElement('input');
            durationInput.name = 'duration';
            durationInput.value = serviceDuration;
            form.appendChild(durationInput);
            
            const categoryInput = document.createElement('input');
            categoryInput.name = 'category';
            categoryInput.value = serviceCategory;
            form.appendChild(categoryInput);
            
            const statusInput = document.createElement('input');
            statusInput.name = 'status';
            statusInput.value = serviceStatus;
            form.appendChild(statusInput);
            
            document.body.appendChild(form);
            form.submit();
        });

        // Delete service
        function deleteService(serviceId) {
            // Find service
            const service = servicesData.find(s => s.id == serviceId);
            if (!service) return;

            // Confirm deletion
            if (!confirm(`Are you sure you want to delete "${service.name}"?`)) {
                return;
            }

            // Create form for submission
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const actionInput = document.createElement('input');
            actionInput.name = 'action';
            actionInput.value = 'delete';
            form.appendChild(actionInput);
            
            const idInput = document.createElement('input');
            idInput.name = 'id';
            idInput.value = serviceId;
            form.appendChild(idInput);
            
            document.body.appendChild(form);
            form.submit();
        }

        // Show service message
        const serviceMessage = document.getElementById('service-message');
        if (!serviceMessage.classList.contains('d-none')) {
            // Hide after 3 seconds
            setTimeout(() => {
                serviceMessage.classList.add('d-none');
            }, 3000);
        }
    });
</script>

<?php include 'components/footer.php'; ?>
